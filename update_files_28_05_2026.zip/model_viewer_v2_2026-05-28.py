# ui/model_viewer_v2.py
"""
3D Viewer 2.0 — KModelViewerV2Dialog

New-generation 3D model viewer for LS-DYNA .k files.

Design references:
  - Open Step Viewer 27.3: fixed per-tab toolbars, industrial/sober style,
    expandable model tree panel.
  - Autodesk Viewer: clean layout, right-side properties panel, splitter flexibility.

Layout:
  ┌──────────────────────────────────────────────────────────────┐
  │  [File] [View] [Tools]  tabs                                 │
  │  ───────── Contextual toolbar for active tab ────────────────│
  ├──────────────┬──────────────────────────┬────────────────────┤
  │ Left Panel   │   3D Viewport            │  Properties Panel  │
  │  Tab: Files  │   (QtInteractor)         │  (selected item)   │
  │  Tab: Model  │                          │                    │
  │  Navigator   │                          │                    │
  ├──────────────┴──────────────────────────┴────────────────────┤
  │  Status Bar                                                  │
  └──────────────────────────────────────────────────────────────┘

Panels are separated by QSplitter for user-adjustable sizing.
The classic viewer (KModelViewerDialog) is preserved and unaffected.

Phase 1 — Base structure:
  - Window chrome, QTabWidget ribbon, contextual toolbars (placeholders),
    three-panel splitter layout, status bar.
  - No VTK rendering yet; viewport shows a placeholder until Phase 2.

Changelog (recent):
  2026-05-21
  - Cut Plane caps: insert vtkCleanPolyData before the stripper so coincident
    intersection points merge — closes loops that previously stayed open
    (e.g. tube cross-sections). JoinContiguousSegments left OFF so open
    features (notches/slots) are not bridged/over-filled.
  - Config — "Highlight cut profile": paint cross-section caps in a distinct
    gold instead of the part colour so the cut profile reads clearly.
  2026-05-19
  - Tools tab — Measure combo button: icons per mode (length_ruler / radius /
    angle_alpha). Button icon updates when mode is changed from the dropdown.
  - Tools tab — Cut Plane combo button: icons per mode (ZY / ZX / XY /
    free / 3P cut-plane). Button icon updates when mode is changed from the
    dropdown. Default icon is ZY (X-normal).
  - Cut Plane menu labels: ZY / ZX / XY (replacing X-normal / Y-normal /
    Z-normal), Free, 3P (replacing "3 Points").
  - Cut Plane menu: "Slice only" moved above "Flip normal" separator.
  - Cut Plane menu: "Slice only" has slice_cut_plane.ico icon.
  - Tools tab combo buttons (Measure, Cut Plane): setIconSize(32×32) and
    _large_icon_menu_style applied — icons now match View tab size.
"""
from __future__ import annotations

import colorsys
import logging
import numbers
import os
from pathlib import Path

from PySide6.QtCore import Qt, QSize, QTimer, QObject, QEvent
from PySide6.QtGui import QAction, QActionGroup, QColor, QFont, QIcon, QKeySequence, QPainter, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMenu,
    QMessageBox,
    QProgressBar,
    QProxyStyle,
    QScrollArea,
    QSizePolicy,
    QSpinBox,
    QSplitter,
    QStatusBar,
    QStyle,
    QTabWidget,
    QToolBar,
    QToolButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
    QWidget,
)
from ui.styles import get_app_theme as _get_app_theme

logger = logging.getLogger(__name__)


def _intensify_rgb(rgb) -> tuple[float, float, float]:
    """Boost saturation/value of an RGB triple so it reads as 'highlighted'
    while preserving the original hue (each part keeps its identity color).
    """
    try:
        r, g, b = float(rgb[0]), float(rgb[1]), float(rgb[2])
    except Exception:
        return (1.0, 0.55, 0.0)
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    # Push saturation hard so the part really pops; clamp value so very dark
    # base colors still read distinctly above the unhighlighted neighbours.
    s = min(1.0, s * 2.2 + 0.55)
    v = min(1.0, max(0.6, v * 1.15))
    nr, ng, nb = colorsys.hsv_to_rgb(h, s, v)
    return (nr, ng, nb)


def _icon_from_text(text: str, size: int = 20, fg: str = "#333",
                    bg: str = "transparent") -> QIcon:
    """Create a tiny QIcon with *text* rendered in the centre."""
    px = QPixmap(QSize(size, size))
    px.fill(QColor(bg) if bg != "transparent" else QColor(0, 0, 0, 0))
    p = QPainter(px)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QColor(fg))
    p.setFont(QFont("Segoe UI", int(size * 0.48), QFont.Weight.Bold))
    p.drawText(px.rect(), Qt.AlignmentFlag.AlignCenter, text)
    p.end()
    return QIcon(px)


class _LargeIconMenuStyle(QProxyStyle):
    """Force 32 px icons inside QMenu."""
    def pixelMetric(self, metric, option=None, widget=None):
        if metric == QStyle.PixelMetric.PM_SmallIconSize:
            return 32
        return super().pixelMetric(metric, option, widget)

_large_icon_menu_style = _LargeIconMenuStyle()

# Icons directory (shared with other MV components)
_ICONS_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "resources", "icons",
)

# ---------------------------------------------------------------------------
#  Visual constants — light palette (matches main_window / Modern Header theme)
#  These drive the ID-scoped rules in _STYLESHEET.
#  The overall app theme (QGroupBox, QTabWidget, etc.) is applied via
#  get_app_theme() in __init__ and can be changed at runtime via _apply_theme().
# ---------------------------------------------------------------------------
_CLR_BG_WINDOW       = "#f5f5f5"   # window background
_CLR_BG_PANEL        = "#ffffff"   # panel backgrounds
_CLR_BG_TOOLBAR      = "#e8e8e8"   # toolbar band (matches main_window)
_CLR_BG_TAB_ACTIVE   = "#e8e8e8"   # selected tab
_CLR_BG_TAB_INACTIVE = "#d8d8d8"   # idle tab
_CLR_BORDER          = "#cccccc"   # borders / dividers
_CLR_ACCENT          = "#003366"   # ITP Blue (Modern Header)
_CLR_TEXT            = "#333333"   # primary text
_CLR_TEXT_DIM        = "#888888"   # secondary / dim text
_CLR_HEADER          = "#003366"   # panel header bg (ITP Blue)

_FONT_UI    = "Segoe UI"
_FONT_SIZE  = 9             # pt

# Splitter initial proportions (left : center : right)
_SPLIT_LEFT    = 220
_SPLIT_CENTER  = 700
_SPLIT_RIGHT   = 240

# ---------------------------------------------------------------------------
#  Global stylesheet — light theme, flat toolbar buttons (Open Step Viewer style)
#  ID-scoped selectors ensure ribbon/side-tabs survive any applied app theme.
# ---------------------------------------------------------------------------
_STYLESHEET = f"""
/* ── Window ─────────────────────────────────────────────── */
KModelViewerV2Dialog {{
    background-color: {_CLR_BG_WINDOW};
    color: {_CLR_TEXT};
    font-family: {_FONT_UI};
    font-size: {_FONT_SIZE}pt;
}}

/* ── Tab ribbon ─────────────────────────────────────────── */
QTabWidget#ribbon_tabs::pane {{
    border: none;
    background: {_CLR_BG_TOOLBAR};
    margin-top: 0px;
    padding: 0px;
}}
QTabWidget#ribbon_tabs > QTabBar::tab {{
    background: {_CLR_BG_TAB_INACTIVE};
    color: {_CLR_TEXT};
    font-family: {_FONT_UI};
    font-size: {_FONT_SIZE}pt;
    font-weight: bold;
    padding: 6px 18px;
    border: 1px solid #b8b8b8;
    border-bottom: none;
    min-width: 80px;
}}
QTabWidget#ribbon_tabs > QTabBar::tab:selected {{
    background: {_CLR_BG_TAB_ACTIVE};
    color: {_CLR_ACCENT};
    border-bottom: 2px solid {_CLR_ACCENT};
}}
QTabWidget#ribbon_tabs > QTabBar::tab:hover:!selected {{
    background: #e0e0e0;
    color: {_CLR_TEXT};
}}

/* ── Contextual toolbar band — flat buttons, no borders ─── */
QToolBar#ribbon_tb {{
    background: {_CLR_BG_TOOLBAR};
    border: none;
    border-bottom: 1px solid {_CLR_BORDER};
    spacing: 2px;
    padding: 3px 6px;
}}
QToolBar#ribbon_tb QToolButton {{
    background: transparent;
    border: none;
    border-radius: 4px;
    color: {_CLR_TEXT};
    font-size: {_FONT_SIZE}pt;
    padding: 2px 6px;
    min-width: 40px;
    min-height: 54px;
}}
QToolBar#ribbon_tb QToolButton:hover {{
    background: #d0d8e8;
}}
QToolBar#ribbon_tb QToolButton:pressed,
QToolBar#ribbon_tb QToolButton:checked {{
    background: #b8c8e0;
    border: 1px solid #8898b8;
}}
QToolBar#ribbon_tb QLabel {{
    color: {_CLR_TEXT_DIM};
    font-size: 8pt;
    padding: 0 4px;
}}
/* combo-button popup arrow stays clean */
QToolBar#ribbon_tb QToolButton::menu-indicator {{
    subcontrol-position: right center;
    subcontrol-origin: padding;
    width: 10px;
    left: -2px;
}}
QToolBar#ribbon_tb QToolButton[popupMode="1"] {{
    padding-right: 14px;
}}

/* ── Splitter handles ───────────────────────────────────── */
QSplitter::handle {{
    background: {_CLR_BORDER};
    width: 3px;
    height: 3px;
}}
QSplitter::handle:hover {{
    background: {_CLR_ACCENT};
}}

/* ── Side panels ────────────────────────────────────────── */
QTabWidget#side_tabs::pane {{
    border: 1px solid {_CLR_ACCENT};
    background: {_CLR_BG_PANEL};
}}
QTabWidget#side_tabs > QTabBar::tab {{
    background: #e0e0e0;
    color: {_CLR_TEXT};
    font-size: 8pt;
    padding: 4px 10px;
    border: 1px solid {_CLR_ACCENT};
    border-bottom: none;
}}
QTabWidget#side_tabs > QTabBar::tab:selected {{
    background: {_CLR_ACCENT};
    color: #ffffff;
    font-weight: bold;
}}
QTabWidget#side_tabs > QTabBar::tab:hover:!selected {{
    background: #b0c4de;
}}

/* ── Lists and Trees ────────────────────────────────────── */
QListWidget, QTreeWidget {{
    background: {_CLR_BG_PANEL};
    color: {_CLR_TEXT};
    border: 1px solid {_CLR_ACCENT};
    font-size: {_FONT_SIZE}pt;
    font-family: {_FONT_UI};
}}
QListWidget::item:hover, QTreeWidget::item:hover {{
    background: #e5f3ff;
}}
QListWidget::item:selected {{
    background: #0078d4;
    color: #ffffff;
}}
QTreeView, QTreeWidget {{
    show-decoration-selected: 0;
    selection-background-color: #0078d4;
    selection-color: #ffffff;
}}

/* ── Properties panel ───────────────────────────────────── */
QFrame#props_panel {{
    background: {_CLR_BG_PANEL};
    border-left: 1px solid {_CLR_BORDER};
}}
QLabel#props_content {{
    color: {_CLR_TEXT};
    font-size: {_FONT_SIZE}pt;
    padding: 8px;
}}

/* ── Viewport placeholder ───────────────────────────────── */
QLabel#viewport_placeholder {{
    background: #ececec;
    color: {_CLR_TEXT_DIM};
    font-size: 13pt;
    font-family: {_FONT_UI};
}}

/* ── Status bar ─────────────────────────────────────────── */
QStatusBar {{
    background: {_CLR_BG_TOOLBAR};
    color: {_CLR_TEXT_DIM};
    font-size: 8pt;
    border-top: 1px solid {_CLR_BORDER};
}}

/* ── Loading overlay ─────────────────────────────────────── */
QWidget#loading_overlay {{
    background: #f0f0f0;
}}
QLabel#loading_label {{
    color: {_CLR_TEXT};
    font-size: 14px;
    background: transparent;
}}
QProgressBar {{
    background: #e0e0e0;
    border: 1px solid {_CLR_BORDER};
    border-radius: 4px;
    text-align: center;
    color: {_CLR_TEXT};
}}
QProgressBar::chunk {{
    background: qlineargradient(
        x1:0, y1:0.5, x2:1, y2:0.5,
        stop:0    rgba(0, 51, 102, 0),
        stop:0.5  {_CLR_ACCENT},
        stop:1    rgba(0, 51, 102, 0)
    );
    border-radius: 3px;
}}

/* ── Panel header (ITP Blue matching Modern Header) ──────── */
QLabel#panel_header {{
    background: {_CLR_HEADER};
    color: #ffffff;
    font-weight: bold;
    font-size: {_FONT_SIZE}pt;
    padding: 5px 8px;
    border-bottom: 1px solid #002244;
}}

/* ── Toolbar combo boxes ─────────────────────────────────── */
QToolBar#ribbon_tb QComboBox {{
    background: white;
    color: {_CLR_TEXT};
    border: 1px solid #bbbbbb;
    border-radius: 3px;
    padding: 2px 6px;
    min-width: 80px;
}}
QToolBar#ribbon_tb QComboBox::drop-down {{
    border: none;
}}

/* ── Activity bar (left vertical strip) ─────────────────── */
QWidget#activity_bar {{
    background: {_CLR_ACCENT};
    border-right: 1px solid #002244;
    min-width: 34px;
    max-width: 34px;
}}
QWidget#activity_bar QToolButton {{
    background: transparent;
    color: #ffffff;
    border: none;
    border-radius: 3px;
    padding: 6px 3px;
    min-width: 28px;
    min-height: 28px;
    font-size: 11pt;
    font-weight: bold;
}}
QWidget#activity_bar QToolButton:hover {{
    background: rgba(255,255,255,0.18);
}}
QWidget#activity_bar QToolButton:checked {{
    background: rgba(255,255,255,0.28);
    border-left: 3px solid #ffffff;
}}
QWidget#activity_bar QFrame#act_sep {{
    background: rgba(255,255,255,0.25);
    max-height: 1px;
    margin: 2px 4px;
}}
"""

# ---------------------------------------------------------------------------
#  Dark stylesheet — original industrial/sober palette (selectable via Theme)
# ---------------------------------------------------------------------------
_STYLESHEET_DARK = """
/* ── Window ─────────────────────────────────────────────── */
KModelViewerV2Dialog {
    background-color: #2b2b2b;
    color: #e0e0e0;
    font-family: Segoe UI;
    font-size: 9pt;
}
/* ── Tab ribbon ─────────────────────────────────────────── */
QTabWidget#ribbon_tabs::pane {
    border: none;
    background: #3a3a3a;
    margin-top: 0px;
    padding: 0px;
}
QTabWidget#ribbon_tabs > QTabBar::tab {
    background: #383838; color: #e0e0e0;
    font-family: Segoe UI; font-size: 9pt; font-weight: bold;
    padding: 6px 18px; border: 1px solid #555555;
    border-bottom: none; min-width: 80px;
}
QTabWidget#ribbon_tabs > QTabBar::tab:selected {
    background: #4a4a4a; color: #5b9bd5;
    border-bottom: 2px solid #5b9bd5;
}
QTabWidget#ribbon_tabs > QTabBar::tab:hover:!selected { background: #424242; }
/* ── Contextual toolbar band — flat buttons ────────────── */
QToolBar#ribbon_tb {
    background: #3a3a3a; border: none;
    border-bottom: 1px solid #555555; spacing: 2px; padding: 2px 6px;
}
QToolBar#ribbon_tb QToolButton {
    background: transparent; border: none; border-radius: 4px;
    color: #e0e0e0; font-size: 9pt;
    padding: 2px 6px; min-width: 40px; min-height: 54px;
}
QToolBar#ribbon_tb QToolButton:hover { background: #505050; }
QToolBar#ribbon_tb QToolButton:pressed,
QToolBar#ribbon_tb QToolButton:checked { background: #3d6a96; border: 1px solid #5b9bd5; }
QToolBar#ribbon_tb QLabel { color: #888888; font-size: 8pt; padding: 0 4px; }
QToolBar#ribbon_tb QToolButton::menu-indicator {
    subcontrol-position: right center; subcontrol-origin: padding;
    width: 10px; left: -2px;
}
QToolBar#ribbon_tb QToolButton[popupMode="1"] { padding-right: 14px; }
/* ── Splitter ─────────────────────────────────────────── */
QSplitter::handle { background: #555555; width: 3px; height: 3px; }
QSplitter::handle:hover { background: #5b9bd5; }
/* ── Side panels ─────────────────────────────────────── */
QTabWidget#side_tabs::pane { border: none; background: #313131; }
QTabWidget#side_tabs > QTabBar::tab {
    background: #383838; color: #e0e0e0; font-size: 8pt;
    padding: 4px 10px; border: 1px solid #555555; border-bottom: none;
}
QTabWidget#side_tabs > QTabBar::tab:selected {
    background: #313131; color: #5b9bd5; font-weight: bold;
}
/* ── Lists and Trees ─────────────────────────────────── */
QListWidget, QTreeWidget {
    background: #313131; color: #e0e0e0; border: none;
    font-size: 9pt; font-family: Segoe UI;
}
QListWidget::item:hover, QTreeWidget::item:hover { background: #404040; }
QListWidget::item:selected { background: #5b9bd5; color: #fff; }
QTreeView, QTreeWidget {
    show-decoration-selected: 0;
    selection-background-color: #5b9bd5;
    selection-color: #ffffff;
}
/* ── Properties panel ────────────────────────────────── */
QFrame#props_panel { background: #313131; border-left: 1px solid #555555; }
QLabel#props_content { color: #e0e0e0; font-size: 9pt; padding: 8px; }
/* ── Viewport placeholder ────────────────────────────── */
QLabel#viewport_placeholder {
    background: #1e1e1e; color: #888888; font-size: 13pt; font-family: Segoe UI;
}
/* ── Status bar ──────────────────────────────────────── */
QStatusBar { background: #3a3a3a; color: #888888; font-size: 8pt; border-top: 1px solid #555555; }
/* ── Loading overlay ─────────────────────────────────── */
QWidget#loading_overlay { background: #1a1a1a; }
QLabel#loading_label { color: #e0e0e0; font-size: 14px; background: transparent; }
QProgressBar {
    background: #404040; border: 1px solid #555555;
    border-radius: 4px; text-align: center; color: #e0e0e0;
}
QProgressBar::chunk {
    background: qlineargradient(
        x1:0, y1:0.5, x2:1, y2:0.5,
        stop:0    rgba(91, 155, 213, 0),
        stop:0.5  rgba(91, 155, 213, 255),
        stop:1    rgba(91, 155, 213, 0)
    );
    border-radius: 3px;
}
/* ── Panel header ────────────────────────────────────── */
QLabel#panel_header {
    background: #3c3c3c; color: #5b9bd5; font-weight: bold;
    font-size: 9pt; padding: 5px 8px; border-bottom: 1px solid #555555;
}
/* ── Toolbar combo boxes ─────────────────────────────── */
QToolBar#ribbon_tb QComboBox {
    background: #404040; color: #e0e0e0; border: 1px solid #555555;
    border-radius: 3px; padding: 2px 6px; min-width: 80px;
}
QToolBar#ribbon_tb QComboBox::drop-down { border: none; }
/* ── Activity bar (left vertical strip) ─────────────────── */
QWidget#activity_bar {
    background: #1a1a2e;
    border-right: 1px solid #444444;
    min-width: 34px;
    max-width: 34px;
}
QWidget#activity_bar QToolButton {
    background: transparent;
    color: #cccccc;
    border: none;
    border-radius: 3px;
    padding: 6px 3px;
    min-width: 28px;
    min-height: 28px;
    font-size: 11pt;
    font-weight: bold;
}
QWidget#activity_bar QToolButton:hover { background: rgba(255,255,255,0.12); }
QWidget#activity_bar QToolButton:checked {
    background: rgba(255,255,255,0.18);
    border-left: 3px solid #5b9bd5;
}
QWidget#activity_bar QFrame#act_sep {
    background: rgba(255,255,255,0.18);
    max-height: 1px;
    margin: 2px 4px;
}
/* ── Config tab (left panel) — light text on dark ────────── */
QWidget#cfg_panel QLabel,
QWidget#cfg_panel QCheckBox,
QWidget#cfg_panel QSpinBox { color: #e0e0e0; }
"""

# ---------------------------------------------------------------------------
#  Per-theme visual overrides for the viewer
#  These are appended on top of _STYLESHEET so they override specific rules
#  and make each theme visually distinct inside the viewer dialog.
# ---------------------------------------------------------------------------
_VIEWER_THEMES = {
    # ── Classic: raised / bevelled toolbar buttons (matches _base_stylesheet) ─
    "Classic": """
QToolBar#ribbon_tb QToolButton {
    background-color: #f0f0f0;
    border-top: 1px solid #ffffff;
    border-left: 1px solid #ffffff;
    border-bottom: 1px solid #909090;
    border-right: 1px solid #909090;
    border-radius: 2px;
    color: #333333;
    padding: 2px 6px;
    min-width: 40px;
    min-height: 54px;
}
QToolBar#ribbon_tb QToolButton:hover {
    background-color: #e0e8f8;
    border-top: 1px solid #ffffff;
    border-left: 1px solid #ffffff;
    border-bottom: 1px solid #8888aa;
    border-right: 1px solid #8888aa;
}
QToolBar#ribbon_tb QToolButton:pressed,
QToolBar#ribbon_tb QToolButton:checked {
    background-color: #c8c8c8;
    border-top: 1px solid #909090;
    border-left: 1px solid #909090;
    border-bottom: 1px solid #ffffff;
    border-right: 1px solid #ffffff;
}
QToolBar#ribbon_tb { background: #e8e8e8; }
QLabel#panel_header {
    background: #d8d8d8;
    color: #333333;
    border-bottom: 1px solid #aaaaaa;
}
QTabWidget#side_tabs > QTabBar::tab:selected {
    background: #e8e8e8;
    color: #333333;
    font-weight: bold;
}
""",

    # ── Modern: ITP Blue accent, flat buttons, white panels ──────────────
    "Modern": """
QToolBar#ribbon_tb { background: #f0f4f8; }
QToolBar#ribbon_tb QToolButton { color: #003366; }
QToolBar#ribbon_tb QToolButton:hover { background: #cfdce8; }
QToolBar#ribbon_tb QToolButton:pressed,
QToolBar#ribbon_tb QToolButton:checked {
    background: #003366;
    color: #ffffff;
    border: 1px solid #002244;
}
QLabel#panel_header {
    background: #003366;
    color: #ffffff;
    border-bottom: 1px solid #002244;
}
QTabWidget#side_tabs > QTabBar::tab:selected {
    background: #003366;
    color: #ffffff;
    font-weight: bold;
}
QTabWidget#ribbon_tabs > QTabBar::tab:selected {
    color: #003366;
    border-bottom: 2px solid #003366;
}
""",

    # ── Modern Header: same as _STYLESHEET defaults (ITP Blue, white bg) ─
    "Modern Header": "",

    # ── Dark: handled separately via _STYLESHEET_DARK ────────────────────
    "Dark (Viewer)": "",
}


def _panel_header(text: str, parent: QWidget | None = None) -> QLabel:
    lbl = QLabel(text, parent)
    lbl.setObjectName("panel_header")
    lbl.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
    return lbl


class _ViewerClickFilter(QObject):
    """Qt event filter on the VTK interactor widget for click-to-select.

    We sit *above* VTK in the event stack: a Qt MousePress arrives here
    before being translated into a VTK ``LeftButtonPressEvent``. We track
    press → release positions; if the cursor barely moved we treat it as a
    click and call the dialog's pick / deselect routines.

    Left-click events are NEVER consumed so PyVista's trackball style still
    rotates on drag. Ctrl+Right-Click events ARE consumed (press + release)
    to suppress VTK's default right-button dolly while we use the gesture
    for individual-part deselection; plain right-button drag still works
    for dolly because we only intercept when Control is held at press time.
    """

    def __init__(self, dialog: "KModelViewerV2Dialog") -> None:
        super().__init__(dialog)
        self._dlg = dialog
        self._press_pos: tuple[int, int] | None = None
        self._rmb_press_pos: tuple[int, int] | None = None
        self._rmb_ctrl: bool = False
        # Plain RMB on a selected part → context popup (Isolate/Hide/Restore)
        self._rmb_popup_press_pos: tuple[int, int] | None = None
        self._rmb_popup_pid: int | None = None
        # Plain RMB on empty background → "Restore all" popup (when parts hidden)
        self._rmb_empty_press_pos: tuple[int, int] | None = None

    def eventFilter(self, obj, event) -> bool:
        et = event.type()
        if et == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.LeftButton:
            p = event.position() if hasattr(event, "position") else event.pos()
            self._press_pos = (int(p.x()), int(p.y()))
        elif et == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.LeftButton:
            if self._press_pos is not None:
                p = event.position() if hasattr(event, "position") else event.pos()
                rx, ry = int(p.x()), int(p.y())
                px, py = self._press_pos
                self._press_pos = None
                if abs(rx - px) <= 3 and abs(ry - py) <= 3:
                    additive = bool(event.modifiers() & Qt.KeyboardModifier.ShiftModifier)
                    try:
                        self._dlg._do_viewport_pick(rx, ry, additive=additive)
                    except Exception as exc:
                        logger.debug("viewport click handler failed: %s", exc)
        elif et == QEvent.Type.MouseButtonPress and event.button() == Qt.MouseButton.RightButton:
            ctrl = bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)
            if ctrl:
                p = event.position() if hasattr(event, "position") else event.pos()
                self._rmb_press_pos = (int(p.x()), int(p.y()))
                self._rmb_ctrl = True
                return True  # block VTK's right-button dolly start
            self._rmb_press_pos = None
            self._rmb_ctrl = False
            # Plain RMB: if the click lands on a part that is currently
            # selected in the navigator, block VTK dolly and prepare a
            # context popup that will fire on release. Otherwise let VTK
            # handle normal right-button dolly.
            p = event.position() if hasattr(event, "position") else event.pos()
            qx, qy = int(p.x()), int(p.y())
            try:
                pid_under = self._dlg._pick_pid_at(qx, qy)
            except Exception:
                pid_under = None
            if pid_under is not None and self._dlg._is_pid_in_selection(int(pid_under)):
                self._rmb_popup_press_pos = (qx, qy)
                self._rmb_popup_pid = int(pid_under)
                self._rmb_empty_press_pos = None
                return True  # block dolly while the user holds RMB on the part
            self._rmb_popup_press_pos = None
            self._rmb_popup_pid = None
            # Truly empty background → remember the press for a possible
            # "Restore all" tap on release. Do NOT block: VTK right-drag dolly
            # must keep working.
            self._rmb_empty_press_pos = (qx, qy) if pid_under is None else None
        elif et == QEvent.Type.MouseButtonRelease and event.button() == Qt.MouseButton.RightButton:
            if self._rmb_ctrl and self._rmb_press_pos is not None:
                p = event.position() if hasattr(event, "position") else event.pos()
                rx, ry = int(p.x()), int(p.y())
                px, py = self._rmb_press_pos
                self._rmb_press_pos = None
                self._rmb_ctrl = False
                if abs(rx - px) <= 3 and abs(ry - py) <= 3:
                    try:
                        self._dlg._do_viewport_deselect(rx, ry)
                    except Exception as exc:
                        logger.debug("viewport deselect handler failed: %s", exc)
                return True  # consume so VTK never sees the right-button release
            if self._rmb_popup_press_pos is not None and self._rmb_popup_pid is not None:
                p = event.position() if hasattr(event, "position") else event.pos()
                rx, ry = int(p.x()), int(p.y())
                px, py = self._rmb_popup_press_pos
                pid = self._rmb_popup_pid
                self._rmb_popup_press_pos = None
                self._rmb_popup_pid = None
                if abs(rx - px) <= 3 and abs(ry - py) <= 3:
                    try:
                        from PySide6.QtGui import QCursor
                        self._dlg._show_part_popup_menu(pid, QCursor.pos())
                    except Exception as exc:
                        logger.debug("part popup menu failed: %s", exc)
                return True  # consume; VTK never saw the press either
            if self._rmb_empty_press_pos is not None:
                p = event.position() if hasattr(event, "position") else event.pos()
                rx, ry = int(p.x()), int(p.y())
                px, py = self._rmb_empty_press_pos
                self._rmb_empty_press_pos = None
                if abs(rx - px) <= 3 and abs(ry - py) <= 3:
                    try:
                        from PySide6.QtGui import QCursor
                        pos = QCursor.pos()
                        # Defer until VTK has finished ending its dolly, so the
                        # modal menu doesn't open mid-interaction.
                        QTimer.singleShot(
                            0, lambda: self._dlg._show_background_popup_menu(pos)
                        )
                    except Exception as exc:
                        logger.debug("background popup menu failed: %s", exc)
                # Do NOT consume — let VTK end its right-button dolly normally.
        return False  # never consume — VTK still receives the event


# ===========================================================================
#  KModelViewerV2Dialog — Phase 2 (full VTK rendering)
# ===========================================================================

class KModelViewerV2Dialog(QDialog):
    """3D Model Viewer 2.0 — industrial ribbon + three-panel layout + full VTK.

    Ribbon tabs: File | View
    Body:  [Left: Files + Navigator] | [Viewport: QtInteractor] | [Properties]

    Background .k parsing runs in viewer_v2_loader.LoadWorker (independent).
    All render/mesh/entity/tree logic is self-contained in this module.
    """

    def __init__(self, file_path: Path | None = None,
                 parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle(
            f"3D Viewer 2.0  —  {file_path.name}" if file_path else "3D Viewer 2.0"
        )
        self.resize(1280, 760)
        self.setMinimumSize(900, 560)
        self.setWindowFlags(
            Qt.WindowType.Window
            | Qt.WindowType.WindowMinMaxButtonsHint
            | Qt.WindowType.WindowCloseButtonHint
        )
        # Apply combined stylesheet: ribbon/panel overrides + per-theme overrides
        self._current_theme = "Modern Header"
        self.setStyleSheet(_STYLESHEET + _VIEWER_THEMES.get(self._current_theme, ""))

        # ── VTK state ──────────────────────────────────────────────────────
        self._file_path         = file_path
        self._polydata          = None
        self._part_names:  dict = {}
        self._keyword_entities: dict = {}
        self._actors:      list = []
        self._part_actors: dict = {}
        self._part_polydata: dict = {}
        self._part_topology: dict = {}  # pid -> {"elements": int, "nodes": int} (real deck counts)
        self._entity_actors: dict = {}
        self._highlight_fe_actors: dict = {}
        self._highlighted_pids: set = set()
        self._per_part_style: dict = {}
        self._per_part_fx: dict = {}
        self._per_part_mesh: dict = {}
        # Material highlighting state
        self._materials: dict = {}            # mid -> {"title": str, "parts": set[pid]}
        self._part_to_mid: dict = {}          # pid -> mid
        self._part_base_color: dict = {}      # pid -> (r,g,b) base color (0..1)
        self._material_selected_mids: set = set()  # transient preview
        self._material_checked_mids: set = set()   # permanent (checkbox)
        self._part_user_visible: dict = {}    # pid -> bool (FEM Parts intent)
        self._pre_dim_opacity: dict = {}      # pid -> float (opacity snapshot before navigator-selection dim)
        self._pre_dim_color: dict = {}        # pid -> (r,g,b) color snapshot before phantom-color override
        self._phantom_enabled: bool = True    # Config: dim non-selected parts on selection
        self._phantom_opacity: float = 0.05   # Config: opacity applied to non-selected parts
        self._phantom_custom_color: tuple | None = None  # (r,g,b) 0..1 override applied to dimmed parts; None = keep each part's own color
        self._icon_text_enabled: bool = True  # Config: show icon + text vs icons-only in ribbons
        self._zoom_item_enabled: bool = True  # Config: auto-fit camera to selection (keeps orientation)
        self._custom_edge_color: tuple | None = None  # (r,g,b) floats 0..1, None = auto (white on dark / black on light)
        self._custom_bg_color: str | None = None      # hex like "#aabbcc" if user picked a custom background
        self._ribbon_toolbars: list = []      # collected for icon/text style toggles
        self._ribbon_combo_buttons: list = []  # custom QToolButtons added via addWidget
        self._material_fe_actors: dict = {}   # pid -> vtkActor (orange feature edges)
        self._style_fe_actors: dict = {}      # pid -> vtkActor (per-part Wireframe boundary edges)
        self._wire_overlay_actor = None       # single combined Wireframe edge actor (global mode)
        # Optional second PyDyna polydata kept around for legacy code paths
        # (feature-edge experiments). Geometry already comes from PyDyna via
        # viewer_v2_loader, so this is normally unused.
        self._pydyna_polydata = None
        self._pydyna_polydata_failed = False
        self._has_parts      = False
        self._n_parts        = 0
        self._edges_visible  = True
        self._mesh_visible   = True
        self._axes_visible   = True
        self._bounds_visible = False
        self._parallel       = False
        self._current_bg     = "white"
        self._prev_bg        = "white"
        self._theme_is_dark  = False
        self._current_style  = "Surface+Edges"
        self._left_panel_open = True
        self._left_panel_size = _SPLIT_LEFT
        self._silhouette_actor     = None
        self._load_worker          = None
        self.plotter               = None   # QtInteractor (lazy)
        # Tools tab — Pick Node state
        self._pick_node_picker      = None  # vtk.vtkPointPicker (lazy)
        self._pick_node_observer_id = None  # interactor observer tag while pick mode is active
        self._pick_node_marker_actor = None  # vtkActor for the last-picked node (red sphere)
        self._pick_node_label_actor  = None  # vtkActor for the floating xyz label
        # Tools tab — Measure state (combo: Distance / Radius / Angle)
        self._measure_mode = "DIST"         # "DIST" (2 pts) | "RAD" (3 pts) | "ANG" (3 pts, p2 = vertex)
        self._measure_observer_id = None    # interactor observer tag while measure mode is active
        self._measure_pts: list = []        # list of {"xyz": (x,y,z), "nid": int|None, "marker": actor}
        self._measure_line_actor = None     # vtkActor for the connecting line (Distance)
        self._measure_label_actor = None    # vtkActor for the main label (Distance value)
        self._measure_extra_actors: list = []  # ancillary actors (Radius circle, Angle arms, labels)
        # Tools tab — Cut Plane state (interactive clipping)
        self._cut_widget = None             # vtkImplicitPlaneWidget2
        self._cut_plane = None              # vtkPlane shared by widget and mapper clipping
        self._cut_mode = "FREE"             # "X" | "Y" | "Z" | "FREE"
        self._cut_locked_normal = None      # (nx,ny,nz) when mode is orthogonal, else None
        self._cut_edge_snapshot: dict = {}  # pid -> bool prior edge visibility (per-part EdgeVisibility)
        self._cut_aux_visibility: list = [] # [(actor, prior_visible_bool), ...] for wire/FE actors
        self._hide_cut_edges = True         # Config: hide wireframe edges while cut is active
        self._close_cut_caps = False        # Config: regenerate closed cross-section caps on release
        self._highlight_cut_caps = False    # Config: paint caps in highlight colour to show cut profile
        self._cut_cap_actors: dict = {}     # pid -> cap vtkActor (one per part)
        self._slice_view_enabled = False    # Cut Plane menu: hide model, show only caps
        self._slice_hidden_actors: list = [] # [(actor, prior_visible_bool), ...] while slice view is on
        self._cut_widget_visible = True     # Config: show/hide the cut plane widget visuals
        self._cut_initial_origin = None     # plane origin at activation; reference for displacement
        self._cut_step_value = 1.0          # singleStep of the displacement spinbox (model units)
        # Snap selection (vertices / midpoints / hole centers) for the Tools pickers
        self._snap_enabled = False          # Config: snap selection priority over raw nodes
        self._snap_points: list = []        # list of (xyz, kind, nid_or_None)
        self._snap_cache_token = None       # id() of the polydata the cache was built from
        # Corner axes triad (lower-left)
        self._axes_widget = None            # vtkOrientationMarkerWidget returned by add_axes()
        # Datum reference geometry (View tab combo)
        self._axes_lines_actors: list = []  # infinite world-axis lines (R/G/B)
        self._grid_planes_actors: list = [] # orthogonal grid planes (faint gray)
        self._datum_grid_spacing = 1000.0   # Config: grid cell size in model units (0 = auto)
        self._datum_grid_opacity = 0.4      # Config: grid plane opacity (0..1)
        # Smooth camera transition state (used by view-cube clicks)
        self._cam_anim_timer = None         # QTimer driving the animation
        self._cam_anim_interp = None        # vtkCameraInterpolator (source + target snapshots)
        self._cam_anim_t0 = 0.0             # start time (perf_counter seconds)
        self._cam_anim_dur_s = 0.18         # animation duration in seconds
        # CATIA-style labeled view cube (Top/Bottom/Left/Right/Front/Back)
        self._view_cube_actor = None        # vtkAnnotatedCubeActor
        self._view_cube_renderer = None     # overlay vtkRenderer in upper-right corner
        self._view_cube_obs_id = None       # interactor observer for clicks on the cube
        self._view_cube_cam_obs_id = None   # main-camera observer to keep cube in sync
        # 3-Points cut plane state
        self._cut_3pt_observer_id = None    # interactor observer tag while picking 3 nodes
        self._cut_3pt_pts: list = []        # XYZ tuples of the picked nodes (max 3)
        self._cut_3pt_markers: list = []    # marker actors shown during picking

        # ── Root layout ────────────────────────────────────────────────────
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        root.addWidget(self._build_ribbon())
        root.addWidget(self._build_body(), stretch=1)

        self._status = QStatusBar()
        self._status.setSizeGripEnabled(True)
        self._status.showMessage("3D Viewer 2.0  —  ready")
        root.addWidget(self._status)

        # Esc clears the navigator selection so toolbar actions revert to global scope.
        self._esc_shortcut = QShortcut(QKeySequence(Qt.Key.Key_Escape), self)
        self._esc_shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
        self._esc_shortcut.activated.connect(self._clear_tree_selection)

        if file_path:
            QTimer.singleShot(0, lambda: self._start_load(file_path))

    # =========================================================================
    #  Ribbon
    # =========================================================================

    def _build_ribbon(self) -> QWidget:
        container = QWidget()
        container.setFixedHeight(96)
        vlay = QVBoxLayout(container)
        vlay.setContentsMargins(0, 0, 0, 0)
        vlay.setSpacing(0)

        self._ribbon_tabs = QTabWidget()
        self._ribbon_tabs.setObjectName("ribbon_tabs")
        self._ribbon_tabs.setDocumentMode(True)
        self._ribbon_tabs.setFixedHeight(96)

        for tab_label, builder in [
            ("File",       self._build_tb_file),
            ("View",       self._build_tb_view),
            ("Tools",      self._build_tb_tools),
        ]:
            tb = builder()
            tb.setObjectName("ribbon_tb")
            tb.setMovable(False)
            tb.setFloatable(False)
            tb.setIconSize(QSize(32, 32) if tab_label == "View" else QSize(32, 32))
            tb.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
            self._ribbon_toolbars.append(tb)
            page = QWidget()
            page.setFixedHeight(66)
            pl = QHBoxLayout(page)
            pl.setContentsMargins(0, 0, 0, 0)
            pl.setSpacing(0)
            pl.addWidget(tb)
            self._ribbon_tabs.addTab(page, tab_label)

        vlay.addWidget(self._ribbon_tabs)
        # Open on the "View" ribbon tab — it carries the most-used controls
        # (camera presets, render style, mesh toggle).
        self._ribbon_tabs.setCurrentIndex(1)
        return container

    # ── Tab: File ─────────────────────────────────────────────────────────

    def _build_tb_file(self) -> QToolBar:
        tb = QToolBar()
        self._a_open       = self._tb_act(tb, "Open",       "Ctrl+O",       "Import a .k model file",   self._action_import)
        _open_ico = os.path.join(_ICONS_DIR, "import_file.ico")
        if os.path.exists(_open_ico):
            self._a_open.setIcon(QIcon(_open_ico))
        
        tb.addSeparator()
        # Screenshot — assign imagen.ico (image/photo icon)
        self._a_screenshot = self._tb_act(tb, "Screenshot", "Ctrl+Shift+S", "Save viewport as PNG",     self._action_screenshot)
        _ss_ico = os.path.join(_ICONS_DIR, "imagen.ico")
        if os.path.exists(_ss_ico):
            self._a_screenshot.setIcon(QIcon(_ss_ico))
        tb.addSeparator()

        # ── Theme combo button ────────────────────────────────────────────
        self._theme_btn = QToolButton()
        # Use the appearance/palette icon for Theme; fall back to no icon
        _theme_ico = os.path.join(_ICONS_DIR, "theme2_viewer_v2.ico")
        if os.path.exists(_theme_ico):
            self._theme_btn.setIcon(QIcon(_theme_ico))
        self._theme_btn.setText("Theme")
        self._theme_btn.setToolTip("Select GUI theme")
        self._theme_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._theme_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self._theme_btn.setMinimumWidth(56)

        theme_menu = QMenu(self._theme_btn)
        for _name in ("Classic", "Modern", "Modern Header"):
            _act = theme_menu.addAction(_name)
            _act.triggered.connect(lambda checked=False, n=_name: self._apply_theme(n))
        theme_menu.addSeparator()
        _dark_act = theme_menu.addAction("Dark (Viewer)")
        _dark_act.triggered.connect(lambda: self._apply_theme("Dark (Viewer)"))
        self._theme_btn.setMenu(theme_menu)
        # Clicking the button face directly re-applies the current theme
        self._theme_btn.clicked.connect(lambda: self._apply_theme(self._current_theme))
        tb.addWidget(self._theme_btn)
        self._ribbon_combo_buttons.append(self._theme_btn)

        tb.addSeparator()
        self._tb_act(tb, "Close", "Ctrl+W", "Close viewer", self.close)
        return tb

    # ── Tab: View ─────────────────────────────────────────────────────────

    def _build_tb_view(self) -> QToolBar:  # noqa: PLR0915
        tb = QToolBar()

        # ── Render style dropdown ─────────────────────────────────────────
        _style_defs = [
            ("Surface+Edges", "surface_wire_MV.ico"),
            ("Surface",       "surface_MV.ico"),
            ("Wireframe",     "wire_MV.ico"),
            ("Points",        "points_MV.ico"),
        ]
        self._v2_style_menu = QMenu()
        self._v2_style_menu.setStyle(_large_icon_menu_style)
        _style_menu = self._v2_style_menu
        self._style_actions: dict[str, QAction] = {}
        self._style_group = QActionGroup(self)
        self._style_group.setExclusive(True)
        _style_dflt_icon = None
        for _lbl, _ico_name in _style_defs:
            _p = os.path.join(_ICONS_DIR, _ico_name)
            _icon = QIcon(_p) if os.path.exists(_p) else QIcon()
            if _style_dflt_icon is None:
                _style_dflt_icon = _icon
            _act = _style_menu.addAction(_icon, _lbl)
            _act.setCheckable(True)
            _act.setToolTip(f"Render style: {_lbl}")
            self._style_group.addAction(_act)
            self._style_actions[_lbl] = _act
        self._style_actions["Surface+Edges"].setChecked(True)
        self._v2_style_btn = QToolButton()
        self._v2_style_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self._v2_style_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._v2_style_btn.setIconSize(QSize(32, 32))
        self._v2_style_btn.setMinimumWidth(64)
        self._v2_style_btn.setMenu(_style_menu)
        if _style_dflt_icon:
            self._v2_style_btn.setIcon(_style_dflt_icon)
        self._v2_style_btn.setText("Style")
        self._v2_style_btn.setToolTip("Select render style")
        for _lbl, _ico_name in _style_defs:
            _p = os.path.join(_ICONS_DIR, _ico_name)
            _ico = QIcon(_p) if os.path.exists(_p) else QIcon()
            self._style_actions[_lbl].triggered.connect(
                lambda checked=False, l=_lbl, ic=_ico: [
                    self._v2_style_btn.setIcon(ic),
                    self._v2_style_btn.setText(l),
                    self._set_render_style(l),
                ]
            )
        self._v2_style_btn.clicked.connect(lambda: self._set_render_style("Surface+Edges"))
        tb.addWidget(self._v2_style_btn)
        self._ribbon_combo_buttons.append(self._v2_style_btn)

        tb.addSeparator()

        # ── View direction dropdown ───────────────────────────────────────
        _view_defs = [
            ("Front",  "front_view_MV.ico",  "Front view (–Y)",  lambda: self.plotter.view_vector((0, 1, 0), (0, 0, 1))),
            ("Back",   "back_view_MV.ico",   "Back view (+Y)",   lambda: self.plotter.view_vector((0, -1, 0), (0, 0, 1))),
            ("Left",   "left_view_MV.ico",   "Left view (–X)",   lambda: self.plotter.view_vector((1, 0, 0), (0, 0, 1))),
            ("Right",  "right_view_MV.ico",  "Right view (+X)",  lambda: self.plotter.view_vector((-1, 0, 0), (0, 0, 1))),
            ("Top",    "top_view_MV.ico",    "Top view (–Z)",    lambda: self.plotter.view_vector((0, 0, 1), (0, 1, 0))),
            ("Bottom", "bottom_view_MV.ico", "Bottom view (+Z)", lambda: self.plotter.view_vector((0, 0, -1), (0, 1, 0))),
            ("Iso",    "iso_view_MV.ico",    "Isometric view",   lambda: self.plotter.view_isometric()),
        ]
        self._v2_view_menu = QMenu()
        self._v2_view_menu.setStyle(_large_icon_menu_style)
        _view_menu = self._v2_view_menu
        _view_dflt_icon = None
        for _lbl, _ico_name, _tip, _fn in _view_defs:
            _p = os.path.join(_ICONS_DIR, _ico_name)
            _icon = QIcon(_p) if os.path.exists(_p) else QIcon()
            if _lbl == "Iso":
                _view_dflt_icon = _icon
            _act = _view_menu.addAction(_icon, _lbl)
            _act.setToolTip(_tip)
            _act.triggered.connect(
                lambda checked=False, fn=_fn, ic=_icon, l=_lbl: [
                    setattr(self, "_v2_current_view_fn", fn),
                    self._vtk_guarded(fn)(),
                    self._v2_view_btn.setIcon(ic),
                    self._v2_view_btn.setText(l),
                ]
            )
        self._v2_view_btn = QToolButton()
        self._v2_view_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self._v2_view_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._v2_view_btn.setIconSize(QSize(32, 32))
        self._v2_view_btn.setMinimumWidth(56)
        self._v2_view_btn.setMenu(_view_menu)
        if _view_dflt_icon:
            self._v2_view_btn.setIcon(_view_dflt_icon)
        self._v2_view_btn.setText("View")
        self._v2_view_btn.setToolTip("Select camera view direction")
        # Clicking the button face re-applies the currently selected view
        # (not always isometric), so re-clicking keeps the chosen orientation.
        self._v2_view_btn.clicked.connect(self._apply_current_view)
        tb.addWidget(self._v2_view_btn)
        self._ribbon_combo_buttons.append(self._v2_view_btn)

        tb.addSeparator()

        # ── Zoom dropdown ─────────────────────────────────────────────────
        _zoom_defs = [
            ("Zoom In",  "zoom_in_MV.ico",  "Zoom in",  lambda: (self.plotter.camera.Zoom(1.3), self.plotter.render())),
            ("Zoom Out", "zoom_out_MV.ico", "Zoom out", lambda: (self.plotter.camera.Zoom(0.7), self.plotter.render())),
        ]
        self._v2_zoom_menu = QMenu()
        self._v2_zoom_menu.setStyle(_large_icon_menu_style)
        _zoom_menu = self._v2_zoom_menu
        _zoom_dflt_icon = None
        for _lbl, _ico_name, _tip, _fn in _zoom_defs:
            _p = os.path.join(_ICONS_DIR, _ico_name)
            _icon = QIcon(_p) if os.path.exists(_p) else QIcon()
            if _zoom_dflt_icon is None:
                _zoom_dflt_icon = _icon
            _act = _zoom_menu.addAction(_icon, _lbl)
            _act.setToolTip(_tip)
            _act.triggered.connect(self._vtk_guarded(_fn))
        self._v2_zoom_btn = QToolButton()
        self._v2_zoom_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self._v2_zoom_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._v2_zoom_btn.setIconSize(QSize(32, 32))
        self._v2_zoom_btn.setMinimumWidth(56)
        self._v2_zoom_btn.setMenu(_zoom_menu)
        if _zoom_dflt_icon:
            self._v2_zoom_btn.setIcon(_zoom_dflt_icon)
        self._v2_zoom_btn.setText("Zoom")
        self._v2_zoom_btn.setToolTip("Zoom in / out")
        self._v2_zoom_btn.clicked.connect(
            self._vtk_guarded(lambda: (self.plotter.camera.Zoom(1.3), self.plotter.render()))
        )
        tb.addWidget(self._v2_zoom_btn)
        self._ribbon_combo_buttons.append(self._v2_zoom_btn)

        # ── Fit All ───────────────────────────────────────────────────────
        _fit_p = os.path.join(_ICONS_DIR, "fit_MV.ico")
        _fit_icon = QIcon(_fit_p) if os.path.exists(_fit_p) else QIcon()
        self._a_fit = QAction(_fit_icon, "Fit All", self)
        self._a_fit.setToolTip("Reset camera to fit entire model")
        self._a_fit.triggered.connect(self._action_fit_all)
        tb.addAction(self._a_fit)

        # ── Zoom Window ───────────────────────────────────────────────────
        _zw_p = os.path.join(_ICONS_DIR, "zoom_window_MV.ico")
        _zw_icon = QIcon(_zw_p) if os.path.exists(_zw_p) else QIcon()
        self._a_zoom_window = QAction(_zw_icon, "Zoom Win.", self)
        self._a_zoom_window.setCheckable(True)
        self._a_zoom_window.setToolTip(
            "Click two points in the viewer to zoom into that rectangle"
        )
        self._a_zoom_window.toggled.connect(self._action_toggle_zoom_window)
        tb.addAction(self._a_zoom_window)

        tb.addSeparator()

        # ── Axes toggle ───────────────────────────────────────────────────
        _axes_p = os.path.join(_ICONS_DIR, "axes_MV.ico")
        _axes_icon = QIcon(_axes_p) if os.path.exists(_axes_p) else QIcon()
        self._a_axes = QAction(_axes_icon, "Axes", self)
        self._a_axes.setCheckable(True)
        self._a_axes.setChecked(True)
        self._a_axes.setToolTip("Toggle orientation axes widget")
        self._a_axes.triggered.connect(self._action_toggle_axes)
        tb.addAction(self._a_axes)

        # ── Datum combo (World Axes / Grid Planes) ───────────────────────
        self._v2_datum_btn = QToolButton()
        self._v2_datum_btn.setText("Datum")
        self._v2_datum_btn.setToolTip(
            "Reference geometry: infinite world axes (X/Y/Z lines through the "
            "origin) and orthogonal grid planes."
        )
        self._v2_datum_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._v2_datum_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        self._v2_datum_btn.setIconSize(QSize(32, 32))
        self._v2_datum_btn.setMinimumWidth(48)
        _datum_axes_ico = os.path.join(_ICONS_DIR, "datum_axes.ico")
        _datum_plane_ico = os.path.join(_ICONS_DIR, "datum_plane.ico")
        if os.path.exists(_datum_axes_ico):
            self._v2_datum_btn.setIcon(QIcon(_datum_axes_ico))
        _datum_menu = QMenu(self._v2_datum_btn)
        self._a_world_axes = _datum_menu.addAction("World Axes (X/Y/Z)")
        if os.path.exists(_datum_axes_ico):
            self._a_world_axes.setIcon(QIcon(_datum_axes_ico))
        self._a_world_axes.setCheckable(True)
        self._a_world_axes.setToolTip(
            "Show infinite X (red), Y (green), Z (blue) lines through the origin"
        )
        self._a_world_axes.toggled.connect(self._toggle_world_axes)
        self._a_grid_planes = _datum_menu.addAction("Grid Planes (XY/YZ/ZX)")
        if os.path.exists(_datum_plane_ico):
            self._a_grid_planes.setIcon(QIcon(_datum_plane_ico))
        self._a_grid_planes.setCheckable(True)
        self._a_grid_planes.setToolTip(
            "Show three orthogonal faint-gray grid planes through the origin"
        )
        self._a_grid_planes.toggled.connect(self._toggle_grid_planes)
        self._v2_datum_btn.setMenu(_datum_menu)
        tb.addWidget(self._v2_datum_btn)
        self._ribbon_combo_buttons.append(self._v2_datum_btn)

        # ── Grid toggle ───────────────────────────────────────────────────
        _grid_p = os.path.join(_ICONS_DIR, "ruler_MV.ico")
        _grid_icon = QIcon(_grid_p) if os.path.exists(_grid_p) else QIcon()
        self._a_grid = QAction(_grid_icon, "Grid", self)
        self._a_grid.setCheckable(True)
        self._a_grid.setChecked(False)
        self._a_grid.setToolTip("Toggle bounding grid with coordinates")
        self._a_grid.triggered.connect(self._action_toggle_grid)
        tb.addAction(self._a_grid)

        # ── Parallel/Perspective toggle ───────────────────────────────────
        _persp_p = os.path.join(_ICONS_DIR, "perspective_MV.ico")
        _ortho_p = os.path.join(_ICONS_DIR, "orthogonal_MV.ico")
        self._v2_persp_icon = QIcon(_persp_p) if os.path.exists(_persp_p) else QIcon()
        self._v2_ortho_icon = QIcon(_ortho_p) if os.path.exists(_ortho_p) else QIcon()
        self._a_proj = QAction(self._v2_persp_icon, "Perspective", self)
        self._a_proj.setCheckable(True)
        self._a_proj.setChecked(False)
        self._a_proj.setToolTip("Toggle parallel / perspective projection")
        self._a_proj.triggered.connect(self._action_toggle_projection)
        tb.addAction(self._a_proj)

        tb.addSeparator()

        # ── Background dropdown ───────────────────────────────────────────
        _bg_defs = [
            ("White",      "backgroun_white_MV.ico",         "white"),
            ("Light Gray", "backgroun_grey_MV.ico",          "lightgray"),
            ("Dark Gray",  "backgroun_dark_grey_MV.ico",     "#3c3c3c"),
            ("Black",      "backgroun_black_MV.ico",         "black"),
            ("Grad Blue",  "backgroun_gradient_MV.ico",      "__gradient_blue"),
            ("Grad Gray",  "backgroun_gradient_grey_MV.ico", "__gradient_gray"),
        ]
        self._v2_bg_menu = QMenu()
        self._v2_bg_menu.setStyle(_large_icon_menu_style)
        _bg_menu = self._v2_bg_menu
        _bg_dflt_icon = None
        for _lbl, _ico_name, _bg_key in _bg_defs:
            _p = os.path.join(_ICONS_DIR, _ico_name)
            _icon = QIcon(_p) if os.path.exists(_p) else QIcon()
            if _bg_dflt_icon is None:
                _bg_dflt_icon = _icon
            _act = _bg_menu.addAction(_icon, _lbl)
            _act.setToolTip(f"Background: {_lbl}")
            _act.triggered.connect(
                lambda checked=False, bk=_bg_key, ic=_icon, l=_lbl: [
                    self._set_background(bk),
                    self._v2_bg_btn.setIcon(ic),
                    self._v2_bg_btn.setText(l),
                ]
            )
        self._v2_bg_btn = QToolButton()
        self._v2_bg_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self._v2_bg_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._v2_bg_btn.setIconSize(QSize(32, 32))
        self._v2_bg_btn.setMinimumWidth(56)
        self._v2_bg_btn.setMenu(_bg_menu)
        if _bg_dflt_icon:
            self._v2_bg_btn.setIcon(_bg_dflt_icon)
        self._v2_bg_btn.setText("BG Color")
        self._v2_bg_btn.setToolTip("Background color")
        self._v2_bg_btn.clicked.connect(lambda: self._set_background("white"))
        tb.addWidget(self._v2_bg_btn)
        self._ribbon_combo_buttons.append(self._v2_bg_btn)

        tb.addSeparator()

        # ── Opacity combo ─────────────────────────────────────────────────
        tb.addWidget(QLabel(" Opacity: "))
        self._v2_opacity_combo = QComboBox()
        self._v2_opacity_combo.addItems(["100%", "90%", "75%", "50%", "25%"])
        self._v2_opacity_combo.setFixedWidth(72)
        self._v2_opacity_combo.setToolTip("Mesh opacity")
        self._v2_opacity_combo.currentTextChanged.connect(self._set_opacity)
        tb.addWidget(self._v2_opacity_combo)

        tb.addSeparator()

        # ── Mesh toggle ───────────────────────────────────────────────────
        _mesh_p = os.path.join(_ICONS_DIR, "mesh_MV.ico")
        _mesh_icon = QIcon(_mesh_p) if os.path.exists(_mesh_p) else QIcon()
        self._v2_a_mesh = QAction(_mesh_icon, "Mesh", self)
        self._v2_a_mesh.setCheckable(True)
        self._v2_a_mesh.setChecked(True)
        self._v2_a_mesh.setToolTip("Toggle mesh wireframe")
        self._v2_a_mesh.triggered.connect(self._action_toggle_mesh)
        tb.addAction(self._v2_a_mesh)

        tb.addSeparator()

        # ── Visual effects dropdown ───────────────────────────────────────
        _fx_defs = [
            ("Silhouette",     "Si", "Add silhouette contour around model"),
            ("PBR (Metallic)", "PB", "Physically-based metallic rendering"),
            ("Smooth Shading", "Sm", "Enable smooth (Phong) shading"),
            ("Anti-aliasing",  "AA", "Multi-sample anti-aliasing"),
            ("SSAO",           "AO", "Screen-space ambient occlusion (shadows in crevices)"),
            ("Depth Peeling",  "Dp", "Accurate transparency (depth peeling)"),
        ]
        self._v2_fx_menu = QMenu()
        self._v2_fx_menu.setStyle(_large_icon_menu_style)
        _fx_menu = self._v2_fx_menu
        self._v2_fx_actions: dict[str, QAction] = {}
        for _lbl, _abbr, _tip in _fx_defs:
            _ico_path = os.path.join(
                _ICONS_DIR,
                f"{_lbl.lower().replace(' ', '_').replace('(', '').replace(')', '')}_MV.ico"
            )
            _ico = QIcon(_ico_path) if os.path.exists(_ico_path) else _icon_from_text(_abbr)
            _act = _fx_menu.addAction(_ico, _lbl)
            _act.setCheckable(True)
            _act.setChecked(False)
            _act.setToolTip(_tip)
            _act.toggled.connect(self._make_fx_callback(_lbl))
            self._v2_fx_actions[_lbl] = _act
        _fx_p = os.path.join(_ICONS_DIR, "fx.ico")
        _fx_icon = QIcon(_fx_p) if os.path.exists(_fx_p) else QIcon()
        self._v2_fx_btn = QToolButton()
        self._v2_fx_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self._v2_fx_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._v2_fx_btn.setIconSize(QSize(32, 32))
        self._v2_fx_btn.setMinimumWidth(48)
        self._v2_fx_btn.setIcon(_fx_icon)
        self._v2_fx_btn.setText("FX")
        self._v2_fx_btn.setMenu(_fx_menu)
        self._v2_fx_btn.setToolTip("Visual effects")
        self._v2_fx_btn.clicked.connect(lambda: self._v2_fx_btn.showMenu())
        tb.addWidget(self._v2_fx_btn)
        self._ribbon_combo_buttons.append(self._v2_fx_btn)

        tb.addSeparator()

        # ── Orbit (continuous rotation) ───────────────────────────────────────
        _orbit_p = os.path.join(_ICONS_DIR, "orbit.ico")
        _orbit_icon = QIcon(_orbit_p) if os.path.exists(_orbit_p) else QIcon()
        self._a_orbit = QAction(_orbit_icon, "Orbit", self)
        self._a_orbit.setCheckable(True)
        self._a_orbit.setChecked(False)
        self._a_orbit.setToolTip("Toggle continuous orbit rotation")
        self._a_orbit.triggered.connect(self._action_toggle_orbit)
        tb.addAction(self._a_orbit)
        self._orbit_timer = QTimer(self)
        self._orbit_timer.setInterval(33)   # ~30 fps
        self._orbit_timer.timeout.connect(self._orbit_step)

        tb.addSeparator()

        # ── Properties panel toggle ──────────────────────────────────────────
        _props_p = os.path.join(_ICONS_DIR, "property.ico")
        _props_icon = QIcon(_props_p) if os.path.exists(_props_p) else _icon_from_text("Pr")
        self._a_props = QAction(_props_icon, "Properties", self)
        self._a_props.setCheckable(True)
        self._a_props.setChecked(True)
        self._a_props.setToolTip("Show / hide the Properties panel")
        self._a_props.triggered.connect(self._action_toggle_properties_panel)
        tb.addAction(self._a_props)

        return tb

    # ── Datum reference geometry (World Axes / Grid Planes) ───────────────

    def _datum_extent(self) -> float:
        """Half-length for datum geometry. Kept a moderate multiple of the
        model size so the geometry participates in the camera clipping range
        (UseBounds=True) without being clipped by the far plane. A truly huge
        'infinite' extent would be cut off by VTK's near/far clipping."""
        if self._polydata is not None:
            try:
                b = self._polydata.bounds
                diag = (
                    (b[1] - b[0]) ** 2 + (b[3] - b[2]) ** 2 + (b[5] - b[4]) ** 2
                ) ** 0.5
                if diag > 1e-9:
                    return diag * 2.5
            except Exception:
                pass
        return 100.0

    def _toggle_world_axes(self, checked: bool) -> None:
        if checked:
            self._build_world_axes()
        else:
            self._clear_world_axes()

    def _build_world_axes(self) -> None:
        self._clear_world_axes()
        if self.plotter is None:
            return
        try:
            import pyvista as pv
            L = self._datum_extent()
            for p0, p1, col in (
                ((-L, 0, 0), (L, 0, 0), "red"),     # X
                ((0, -L, 0), (0, L, 0), "green"),   # Y
                ((0, 0, -L), (0, 0, L), "blue"),    # Z
            ):
                actor = self.plotter.add_mesh(
                    pv.Line(p0, p1), color=col, line_width=2,
                    pickable=False, reset_camera=False, label="_world_axis",
                )
                self._axes_lines_actors.append(actor)
            self.plotter.render()
        except Exception:
            logger.debug("World axes build failed", exc_info=True)

    def _clear_world_axes(self) -> None:
        if self.plotter is None:
            self._axes_lines_actors = []
            return
        for a in self._axes_lines_actors:
            try:
                self.plotter.remove_actor(a)
            except Exception:
                pass
        self._axes_lines_actors = []
        try:
            self.plotter.render()
        except Exception:
            pass

    def _toggle_grid_planes(self, checked: bool) -> None:
        if checked:
            self._build_grid_planes()
        else:
            self._clear_grid_planes()

    def _on_datum_grid_spacing_changed(self, value: float) -> None:
        """Config → 'Datum grid spacing'. Rebuilds the grid planes live when
        they are visible; otherwise the value is just stored for next time."""
        self._datum_grid_spacing = float(value)
        if self._grid_planes_actors:
            self._build_grid_planes()

    def _on_datum_grid_opacity_changed(self, value: int) -> None:
        """Config → 'Datum grid opacity'. Updates existing grid plane actors
        in place (no rebuild needed)."""
        self._datum_grid_opacity = max(0.0, min(1.0, value / 100.0))
        for a in self._grid_planes_actors:
            try:
                a.GetProperty().SetOpacity(self._datum_grid_opacity)
            except Exception:
                pass
        if self._grid_planes_actors and self.plotter is not None:
            try:
                self.plotter.render()
            except Exception:
                pass

    def _build_grid_planes(self) -> None:
        self._clear_grid_planes()
        if self.plotter is None:
            return
        try:
            import pyvista as pv
            L = self._datum_extent()
            total = 2.0 * L
            # Spacing of 0 → Auto (10 divisions). Otherwise derive the
            # division count from the requested cell size, clamped so a tiny
            # spacing on a large model can't explode the resolution.
            if self._datum_grid_spacing and self._datum_grid_spacing > 0:
                res = int(round(total / self._datum_grid_spacing))
                res = max(1, min(res, 400))
            else:
                res = 10
            for normal in ((0, 0, 1), (1, 0, 0), (0, 1, 0)):  # XY, YZ, ZX
                plane = pv.Plane(
                    center=(0.0, 0.0, 0.0), direction=normal,
                    i_size=2 * L, j_size=2 * L,
                    i_resolution=res, j_resolution=res,
                )
                actor = self.plotter.add_mesh(
                    plane, style="wireframe", color="#999999",
                    opacity=self._datum_grid_opacity, line_width=1,
                    pickable=False, reset_camera=False, label="_grid_plane",
                )
                self._grid_planes_actors.append(actor)
            self.plotter.render()
        except Exception:
            logger.debug("Grid planes build failed", exc_info=True)

    def _clear_grid_planes(self) -> None:
        if self.plotter is None:
            self._grid_planes_actors = []
            return
        for a in self._grid_planes_actors:
            try:
                self.plotter.remove_actor(a)
            except Exception:
                pass
        self._grid_planes_actors = []
        try:
            self.plotter.render()
        except Exception:
            pass

    # ── Tab: Tools ───────────────────────────────────────────────────────
    #
    # Incremental home for FEM inspection utilities (see
    # resources/update_files/viewer_v2_capabilities_QA.md). Buttons are added
    # one at a time after design review.

    def _build_tb_tools(self) -> QToolBar:
        tb = QToolBar()
        self._a_pick_node = self._tb_act(
            tb, "Pick Node", None,
            "Toggle pick mode: left-click on the geometry to show the nearest "
            "LS-DYNA node ID and its XYZ in the status bar.",
            self._action_toggle_pick_node,
        )
        self._a_pick_node.setCheckable(True)
        _pick_ico = os.path.join(_ICONS_DIR, "x_y_z_Coord.ico")
        if os.path.exists(_pick_ico):
            self._a_pick_node.setIcon(QIcon(_pick_ico))

        # Measure combo button (toggle + mode dropdown: Distance/Radius/Angle)
        self._measure_btn = QToolButton()
        self._measure_btn.setText("Measure")
        self._measure_btn.setToolTip(
            "Toggle measure mode. Use the dropdown to choose what to measure: "
            "Distance (2 nodes), Radius (3 nodes → circumscribed circle), or "
            "Angle (3 nodes → middle one is the vertex)."
        )
        self._measure_btn.setCheckable(True)
        self._measure_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._measure_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self._measure_btn.setIconSize(QSize(32, 32))
        self._measure_btn.setMinimumWidth(56)
        _meas_ico = os.path.join(_ICONS_DIR, "length_ruler.ico")
        if os.path.exists(_meas_ico):
            self._measure_btn.setIcon(QIcon(_meas_ico))

        measure_menu = QMenu(self._measure_btn)
        measure_menu.setStyle(_large_icon_menu_style)
        _MEAS_TIPS = {
            "DIST": "Distance between two picked nodes",
            "RAD":  "Radius of the circle through three picked nodes",
            "ANG":  "Angle at the second picked node (vertex), arms to the 1st and 3rd",
        }
        _MEAS_ICONS = {
            "DIST": os.path.join(_ICONS_DIR, "length_ruler.ico"),
            "RAD":  os.path.join(_ICONS_DIR, "radius.ico"),
            "ANG":  os.path.join(_ICONS_DIR, "angle_alpha.ico"),
        }
        for _label, _mode in (
            ("Length", "DIST"),
            ("Radius",   "RAD"),
            ("Angle",    "ANG"),
        ):
            _act = measure_menu.addAction(_label)
            _act.setToolTip(_MEAS_TIPS[_mode])
            _ico_path = _MEAS_ICONS[_mode]
            if os.path.exists(_ico_path):
                _act.setIcon(QIcon(_ico_path))
            _act.triggered.connect(
                lambda _checked=False, m=_mode, lb=_label: self._set_measure_mode(m, lb)
            )
        self._measure_btn.setMenu(measure_menu)
        self._measure_btn.toggled.connect(self._action_toggle_measure)
        tb.addWidget(self._measure_btn)
        self._ribbon_combo_buttons.append(self._measure_btn)

        # Cut Plane combo button (toggle + mode dropdown)
        self._cut_btn = QToolButton()
        self._cut_btn.setText("ZY")
        self._cut_btn.setToolTip(
            "Toggle a clipping plane. Use the dropdown to pick the cut "
            "orientation: orthogonal (X/Y/Z) or free (drag-rotate)."
        )
        self._cut_btn.setCheckable(True)
        self._cut_btn.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
        self._cut_btn.setPopupMode(QToolButton.ToolButtonPopupMode.MenuButtonPopup)
        self._cut_btn.setIconSize(QSize(32, 32))
        self._cut_btn.setMinimumWidth(56)
        _cut_default_ico = os.path.join(_ICONS_DIR, "ZY_cut_plane.ico")
        if os.path.exists(_cut_default_ico):
            self._cut_btn.setIcon(QIcon(_cut_default_ico))

        cut_menu = QMenu(self._cut_btn)
        cut_menu.setStyle(_large_icon_menu_style)
        _CUT_TIPS = {
            "X":    "Clip along the YZ plane (X-normal)",
            "Y":    "Clip along the XZ plane (Y-normal)",
            "Z":    "Clip along the XY plane (Z-normal)",
            "FREE": "Free orientation — drag the arrow handle to rotate the normal",
            "3PT":  "Define the cut plane by picking 3 nodes on the geometry",
        }
        _CUT_ICONS = {
            "X":    os.path.join(_ICONS_DIR, "ZY_cut_plane.ico"),
            "Y":    os.path.join(_ICONS_DIR, "ZX_cut_plane.ico"),
            "Z":    os.path.join(_ICONS_DIR, "XY_cut_plane.ico"),
            "FREE": os.path.join(_ICONS_DIR, "free_cut_plane.ico"),
            "3PT":  os.path.join(_ICONS_DIR, "3P_cut_plane.ico"),
        }
        for _label, _mode in (
            ("ZY",   "X"),
            ("ZX",   "Y"),
            ("XY",   "Z"),
            ("Free", "FREE"),
            ("3P",   "3PT"),
        ):
            _act = cut_menu.addAction(_label)
            _act.setToolTip(_CUT_TIPS[_mode])
            _ico_path = _CUT_ICONS.get(_mode)
            if _ico_path and os.path.exists(_ico_path):
                _act.setIcon(QIcon(_ico_path))
            _act.triggered.connect(
                lambda _checked=False, m=_mode, lb=_label: self._set_cut_mode(m, lb)
            )
        cut_menu.addSeparator()
        self._a_slice_view = cut_menu.addAction("Slice only")
        self._a_slice_view.setCheckable(True)
        _slice_ico = os.path.join(_ICONS_DIR, "slice_cut_plane.ico")
        if os.path.exists(_slice_ico):
            self._a_slice_view.setIcon(QIcon(_slice_ico))
        self._a_slice_view.setToolTip(
            "Hide the model and show only the cross-section caps at the "
            "current cut plane. Each cap takes the colour of its part. "
            "Toggle ON/OFF without changing the active cut plane."
        )
        self._a_slice_view.toggled.connect(self._toggle_slice_view)
        cut_menu.addSeparator()
        self._a_flip_cut_normal = cut_menu.addAction("Flip normal")
        self._a_flip_cut_normal.setToolTip(
            "Reverse the cut direction — swap which side of the plane is "
            "hidden and which is shown. Works in any mode."
        )
        self._a_flip_cut_normal.triggered.connect(self._flip_cut_normal)
        self._cut_btn.setMenu(cut_menu)
        self._cut_btn.toggled.connect(self._action_toggle_cut_plane)
        tb.addWidget(self._cut_btn)
        self._ribbon_combo_buttons.append(self._cut_btn)

        # Cut plane displacement control (Offset spinbox).
        # The value represents the plane's displacement along its current
        # normal from the position it had when the cut was activated.
        # Arrows / mouse wheel / typed value all translate the plane.
        # Right-click → "Set step…" to change the per-arrow increment.
        tb.addSeparator()
        _disp_lbl = QLabel("Offset:")
        tb.addWidget(_disp_lbl)
        self._cut_disp_spin = QDoubleSpinBox()
        self._cut_disp_spin.setRange(-1.0e9, 1.0e9)
        self._cut_disp_spin.setDecimals(4)
        self._cut_disp_spin.setValue(0.0)
        self._cut_disp_spin.setSingleStep(self._cut_step_value)
        self._cut_disp_spin.setFixedWidth(110)
        self._cut_disp_spin.setToolTip(
            "Displacement of the cut plane along its current normal, "
            "relative to the position it had when the cut was activated.\n"
            "  • Up/Down arrows or mouse wheel: move by ±step.\n"
            "  • Type a number to jump to that exact offset.\n"
            "  • Right-click to change the step or reset to 0."
        )
        self._cut_disp_spin.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self._cut_disp_spin.customContextMenuRequested.connect(
            self._on_cut_disp_context_menu
        )
        self._cut_disp_spin.valueChanged.connect(self._on_cut_disp_changed)
        tb.addWidget(self._cut_disp_spin)
        return tb

    def _action_toggle_pick_node(self, checked: bool) -> None:
        if checked:
            self._install_pick_node_observer()
        else:
            self._remove_pick_node_observer()

    def _install_pick_node_observer(self) -> None:
        if self.plotter is None or self._polydata is None:
            self._status.showMessage("Pick Node: load a model first")
            if getattr(self, "_a_pick_node", None) is not None:
                self._a_pick_node.setChecked(False)
            return
        if self._pick_node_observer_id is not None:
            return
        # Mutual exclusion: only one Tools-tab picker may be active at a time
        if self._measure_observer_id is not None:
            if getattr(self, "_measure_btn", None) is not None:
                self._measure_btn.setChecked(False)
            self._remove_measure_observer()
        if self._cut_3pt_observer_id is not None:
            if getattr(self, "_cut_btn", None) is not None:
                self._cut_btn.setChecked(False)
            self._remove_cut_3pt_picking()
        try:
            import vtk
            if self._pick_node_picker is None:
                self._pick_node_picker = vtk.vtkPointPicker()
                self._pick_node_picker.SetTolerance(0.005)
            vtk_iren = self._vtk_interactor()
            if vtk_iren is None:
                self._status.showMessage("Pick Node: interactor not available")
                self._a_pick_node.setChecked(False)
                return
            self._pick_node_observer_id = vtk_iren.AddObserver(
                "LeftButtonPressEvent", self._on_pick_left_button, 10.0
            )
            try:
                self.plotter.setCursor(Qt.CursorShape.CrossCursor)
            except Exception:
                pass
            self._status.showMessage(
                "Pick Node: ON — left-click a node (toggle the button to exit)"
            )
        except Exception:
            logger.exception("Failed to install Pick Node observer")
            if getattr(self, "_a_pick_node", None) is not None:
                self._a_pick_node.setChecked(False)

    def _remove_pick_node_observer(self) -> None:
        if self._pick_node_observer_id is None:
            return
        try:
            vtk_iren = self._vtk_interactor()
            if vtk_iren is not None:
                vtk_iren.RemoveObserver(self._pick_node_observer_id)
        except Exception:
            pass
        self._pick_node_observer_id = None
        try:
            self.plotter.unsetCursor()
        except Exception:
            pass
        self._clear_pick_node_marker()
        self._status.showMessage("Pick Node: OFF")

    def _vtk_interactor(self):
        """Return the underlying vtkRenderWindowInteractor or None.

        ``plotter.iren`` is the pyvista ``RenderWindowInteractor`` wrapper,
        which does not expose the VTK PascalCase API (e.g. ``AddObserver``).
        The wrapped VTK object lives at ``plotter.iren.interactor``.
        """
        if self.plotter is None:
            return None
        iren = getattr(self.plotter, "iren", None)
        if iren is None:
            return None
        return getattr(iren, "interactor", iren)

    def _on_pick_left_button(self, caller, _event) -> None:
        try:
            x, y = caller.GetEventPosition()
            # Snap selection takes priority if enabled and a candidate is close
            snap = self._find_snap_at(x, y)
            if snap is not None:
                sxyz, skind, snid = snap
                kind_lbl = self._SNAP_KIND_LABELS.get(skind, skind)
                id_suffix = f" (NID {snid})" if snid is not None else ""
                self._status.showMessage(
                    f"Pick Node: snap to {kind_lbl}{id_suffix}  "
                    f"XYZ ({sxyz[0]:.3f}, {sxyz[1]:.3f}, {sxyz[2]:.3f})"
                )
                self._show_pick_node_marker(sxyz, snap_kind=skind)
                return
            picker = self._pick_node_picker
            renderer = self.plotter.renderer
            picker.Pick(x, y, 0, renderer)
            point_id = picker.GetPointId()
            if point_id < 0:
                self._status.showMessage("Pick Node: no hit (click on the geometry)")
                return
            ds = picker.GetDataSet()
            if ds is None:
                self._status.showMessage("Pick Node: no dataset under cursor")
                return
            pd_arr = ds.GetPointData()
            nid_arr = pd_arr.GetArray("node_ids") if pd_arr is not None else None
            label = (
                f"NID {int(nid_arr.GetValue(point_id))}"
                if nid_arr is not None
                else f"VTK point {point_id}"
            )
            nx, ny, nz = ds.GetPoint(point_id)
            self._status.showMessage(
                f"Pick Node: {label}  XYZ ({nx:.3f}, {ny:.3f}, {nz:.3f})"
            )
            self._show_pick_node_marker((nx, ny, nz))
        except Exception:
            logger.exception("Pick Node callback failed")

    def _show_pick_node_marker(self, xyz: tuple, snap_kind: str | None = None) -> None:
        """Highlight the last-picked node and attach a floating ``xyz (X, Y, Z)``
        label next to it. Marker colour and size vary by *snap_kind* so the
        user can tell at a glance whether the pick snapped to a vertex
        (red), an edge midpoint (cyan) or a hole centre (yellow)."""
        if self.plotter is None:
            return
        self._clear_pick_node_marker()
        color, size = self._SNAP_MARKER_STYLES.get(
            snap_kind, self._SNAP_MARKER_STYLES[None]
        )
        try:
            import pyvista as pv
            self._pick_node_marker_actor = self.plotter.add_mesh(
                pv.PolyData([list(xyz)]),
                color=color, point_size=size,
                render_points_as_spheres=True,
                pickable=False,
                reset_camera=False,
                label="_pick_node_marker",
            )
        except Exception:
            logger.debug("Pick Node marker add failed", exc_info=True)
        try:
            nx, ny, nz = xyz
            # Offset the label position a small fraction of the model diagonal
            # so the rounded-rect background does not overlap the red sphere.
            off = self._label_offset_world()
            label_pos = (nx + off, ny + off, nz + off)
            self._pick_node_label_actor = self.plotter.add_point_labels(
                [list(label_pos)], [f"xyz ({nx:.3f}, {ny:.3f}, {nz:.3f})"],
                font_size=14, text_color="yellow",
                shape_color="black", shape_opacity=0.6,
                show_points=False, always_visible=True,
                pickable=False, reset_camera=False,
                name="_pick_node_label",
            )
        except Exception:
            logger.debug("Pick Node label add failed", exc_info=True)
        try:
            self.plotter.render()
        except Exception:
            pass

    # ── Snap selection ───────────────────────────────────────────────

    _SNAP_KIND_LABELS = {
        "vertex":      "vertex",
        "midpoint":    "edge midpoint",
        "hole_center": "hole center",
    }
    # Marker style per snap kind: (color, point_size). ``None`` is the
    # fallback (regular node pick, no snap).
    _SNAP_MARKER_STYLES = {
        "vertex":      ("red",    12),
        "midpoint":    ("cyan",    9),
        "hole_center": ("yellow", 14),
        None:          ("red",     8),
    }

    def _on_snap_selection_toggled(self, checked: bool) -> None:
        self._snap_enabled = bool(checked)
        if self._snap_enabled:
            n = self._ensure_snap_cache()
            self._status.showMessage(
                f"Snap selection: ON — {n} snap targets cached"
            )
        else:
            self._status.showMessage("Snap selection: OFF")

    def _invalidate_snap_cache(self) -> None:
        self._snap_points = []
        self._snap_cache_token = None

    def _ensure_snap_cache(self) -> int:
        """Build (or return cached) snap targets for the current polydata.
        Returns the number of cached snap points."""
        if self._polydata is None:
            return 0
        if self._snap_cache_token == id(self._polydata) and self._snap_points:
            return len(self._snap_points)
        self._build_snap_cache()
        self._snap_cache_token = id(self._polydata)
        return len(self._snap_points)

    def _build_snap_cache(self) -> None:
        """Compute vertices + feature-edge midpoints + boundary-loop centres
        using the SAME pipeline as the project's Wireframe overlay
        (``_clean_feature_edges`` with ``feature_angle=89``). This guarantees
        the snap targets coincide with the visible "wire" edges and are NOT
        influenced by mesh density on curved surfaces."""
        self._snap_points = []
        if self._polydata is None:
            return
        try:
            import vtk
        except Exception:
            return

        # ── 1+2. Vertices (degree ≥ 3) + midpoints from cleaned wire edges
        try:
            cleaned = self._clean_feature_edges(self._polydata, feature_angle=89)
            if cleaned is not None and cleaned.n_points > 0:
                fpoints = cleaned.GetPoints()
                flines = cleaned.GetLines()
                n_fpoints = fpoints.GetNumberOfPoints()
                degree = [0] * n_fpoints
                id_list = vtk.vtkIdList()
                flines.InitTraversal()
                while flines.GetNextCell(id_list):
                    if id_list.GetNumberOfIds() != 2:
                        continue
                    a = id_list.GetId(0); b = id_list.GetId(1)
                    degree[a] += 1
                    degree[b] += 1
                    pa = fpoints.GetPoint(a)
                    pb = fpoints.GetPoint(b)
                    mid = (
                        (pa[0] + pb[0]) * 0.5,
                        (pa[1] + pb[1]) * 0.5,
                        (pa[2] + pb[2]) * 0.5,
                    )
                    self._snap_points.append((mid, "midpoint", None))
                for i in range(n_fpoints):
                    if degree[i] < 3:
                        continue
                    pt = fpoints.GetPoint(i)
                    self._snap_points.append((tuple(pt), "vertex", None))
        except Exception:
            logger.debug("Snap: feature edges step failed", exc_info=True)

        # ── 3. Hole centres: closed boundary loops → centroid ──────────
        # Uses cleaned polydata too so the loop nodes match the visible wire.
        try:
            cleaner = vtk.vtkCleanPolyData()
            cleaner.SetInputData(self._polydata)
            cleaner.SetTolerance(0.0)
            cleaner.PointMergingOn()
            cleaner.Update()
            bd = vtk.vtkFeatureEdges()
            bd.SetInputConnection(cleaner.GetOutputPort())
            bd.FeatureEdgesOff()
            bd.BoundaryEdgesOn()
            bd.NonManifoldEdgesOff()
            bd.ManifoldEdgesOff()
            bd.Update()
            stripper = vtk.vtkStripper()
            stripper.SetInputData(bd.GetOutput())
            stripper.Update()
            stripped = stripper.GetOutput()
            sp = stripped.GetPoints()
            cells = stripped.GetLines()
            id_list = vtk.vtkIdList()
            cells.InitTraversal()
            while cells.GetNextCell(id_list):
                n = id_list.GetNumberOfIds()
                if n < 4:
                    continue
                first = id_list.GetId(0)
                last  = id_list.GetId(n - 1)
                if first != last:
                    continue  # open polyline, not a closed loop
                sx = sy = sz = 0.0
                for k in range(n - 1):
                    p = sp.GetPoint(id_list.GetId(k))
                    sx += p[0]; sy += p[1]; sz += p[2]
                m = n - 1
                self._snap_points.append((
                    (sx / m, sy / m, sz / m), "hole_center", None
                ))
        except Exception:
            logger.debug("Snap: boundary loops step failed", exc_info=True)

        logger.debug("Snap cache built: %d targets", len(self._snap_points))

    def _find_snap_at(self, x_disp: int, y_disp: int, tol_px: int = 15):
        """Return ``(xyz, kind, nid_or_None)`` of the closest snap target
        within *tol_px* of the (x,y) display position, or ``None`` if none
        is in range."""
        if not self._snap_enabled or self.plotter is None:
            return None
        self._ensure_snap_cache()
        if not self._snap_points:
            return None
        renderer = self.plotter.renderer
        best = None
        best_d2 = float(tol_px * tol_px)
        for xyz, kind, nid in self._snap_points:
            try:
                renderer.SetWorldPoint(xyz[0], xyz[1], xyz[2], 1.0)
                renderer.WorldToDisplay()
                dp = renderer.GetDisplayPoint()
                sx, sy, sz = dp[0], dp[1], dp[2]
            except Exception:
                continue
            if sz < 0.0 or sz > 1.0:
                continue
            dx = sx - x_disp
            dy = sy - y_disp
            d2 = dx * dx + dy * dy
            if d2 < best_d2:
                best_d2 = d2
                best = (xyz, kind, nid)
        return best

    def _label_offset_world(self) -> float:
        """Small world-space offset (≈2% of the model diagonal) used to push
        floating labels away from the marker so the rounded-rect background
        does not overlap the sphere."""
        if self._polydata is None:
            return 0.0
        try:
            b = self._polydata.bounds
            diag = (
                (b[1] - b[0]) ** 2 + (b[3] - b[2]) ** 2 + (b[5] - b[4]) ** 2
            ) ** 0.5
            return diag * 0.02
        except Exception:
            return 0.0

    def _clear_pick_node_marker(self) -> None:
        if self.plotter is None:
            self._pick_node_marker_actor = None
            self._pick_node_label_actor = None
            return
        if self._pick_node_marker_actor is not None:
            try:
                self.plotter.remove_actor(self._pick_node_marker_actor)
            except Exception:
                pass
            self._pick_node_marker_actor = None
        if self._pick_node_label_actor is not None:
            try:
                self.plotter.remove_actor(self._pick_node_label_actor)
            except Exception:
                pass
            self._pick_node_label_actor = None

    # ── Measure (combo: Distance / Radius / Angle) ──────────────────────

    _MEASURE_LABELS = {"DIST": "Distance", "RAD": "Radius", "ANG": "Angle"}
    _MEASURE_POINTS_NEEDED = {"DIST": 2, "RAD": 3, "ANG": 3}

    def _set_measure_mode(self, mode: str, label: str | None = None) -> None:
        """Pick the measure mode from the combo dropdown. If a measurement is
        currently in progress it is cleared so the user starts fresh under
        the new mode (consistent with picking a new mode from Cut Plane)."""
        if mode not in self._MEASURE_LABELS:
            return
        self._measure_mode = mode
        if label is not None and getattr(self, "_measure_btn", None) is not None:
            self._measure_btn.setText(label)
            _mode_icons = {
                "DIST": "length_ruler.ico",
                "RAD":  "radius.ico",
                "ANG":  "angle_alpha.ico",
            }
            _ico = os.path.join(_ICONS_DIR, _mode_icons[mode])
            if os.path.exists(_ico):
                self._measure_btn.setIcon(QIcon(_ico))
        if self._measure_observer_id is not None:
            self._clear_measurement()
            prompt = self._measure_prompt_for_pick(0)
            self._status.showMessage(prompt)
            return
        self._measure_btn.blockSignals(True)
        self._measure_btn.setChecked(True)
        self._measure_btn.blockSignals(False)
        self._install_measure_observer()

    def _action_toggle_measure(self, checked: bool) -> None:
        if checked:
            self._install_measure_observer()
        else:
            self._remove_measure_observer()

    def _measure_prompt_for_pick(self, n_already_picked: int) -> str:
        """Status-bar prompt before the next click."""
        label = self._MEASURE_LABELS[self._measure_mode]
        needed = self._MEASURE_POINTS_NEEDED[self._measure_mode]
        next_idx = n_already_picked
        next_word = ("first", "second", "third")[next_idx]
        return f"{label}: {n_already_picked}/{needed} — click the {next_word} node"

    def _install_measure_observer(self) -> None:
        if self.plotter is None or self._polydata is None:
            self._status.showMessage("Measure: load a model first")
            if getattr(self, "_measure_btn", None) is not None:
                self._measure_btn.setChecked(False)
            return
        if self._measure_observer_id is not None:
            return
        # Mutual exclusion: only one Tools-tab picker may be active at a time
        if self._pick_node_observer_id is not None:
            if getattr(self, "_a_pick_node", None) is not None:
                self._a_pick_node.setChecked(False)
            self._remove_pick_node_observer()
        if self._cut_3pt_observer_id is not None:
            if getattr(self, "_cut_btn", None) is not None:
                self._cut_btn.setChecked(False)
            self._remove_cut_3pt_picking()
        try:
            import vtk
            if self._pick_node_picker is None:
                self._pick_node_picker = vtk.vtkPointPicker()
                self._pick_node_picker.SetTolerance(0.005)
            vtk_iren = self._vtk_interactor()
            if vtk_iren is None:
                self._status.showMessage("Measure: interactor not available")
                self._measure_btn.setChecked(False)
                return
            self._measure_observer_id = vtk_iren.AddObserver(
                "LeftButtonPressEvent", self._on_measure_left_button, 10.0
            )
            try:
                self.plotter.setCursor(Qt.CursorShape.CrossCursor)
            except Exception:
                pass
            self._status.showMessage(self._measure_prompt_for_pick(0))
        except Exception:
            logger.exception("Failed to install Measure observer")
            if getattr(self, "_measure_btn", None) is not None:
                self._measure_btn.setChecked(False)

    def _remove_measure_observer(self) -> None:
        if self._measure_observer_id is None:
            self._clear_measurement()
            return
        try:
            vtk_iren = self._vtk_interactor()
            if vtk_iren is not None:
                vtk_iren.RemoveObserver(self._measure_observer_id)
        except Exception:
            pass
        self._measure_observer_id = None
        try:
            self.plotter.unsetCursor()
        except Exception:
            pass
        self._clear_measurement()
        self._status.showMessage("Measure: OFF")

    def _on_measure_left_button(self, caller, _event) -> None:
        try:
            x, y = caller.GetEventPosition()
            # Snap selection takes priority
            snap = self._find_snap_at(x, y)
            if snap is not None:
                sxyz, skind, snid = snap
                xyz = sxyz
                nid = snid
            else:
                skind = None
                picker = self._pick_node_picker
                renderer = self.plotter.renderer
                picker.Pick(x, y, 0, renderer)
                point_id = picker.GetPointId()
                if point_id < 0:
                    self._status.showMessage("Measure: no hit (click on the geometry)")
                    return
                ds = picker.GetDataSet()
                if ds is None:
                    self._status.showMessage("Measure: no dataset under cursor")
                    return
                pd_arr = ds.GetPointData()
                nid_arr = pd_arr.GetArray("node_ids") if pd_arr is not None else None
                nid = int(nid_arr.GetValue(point_id)) if nid_arr is not None else None
                xyz = tuple(float(c) for c in ds.GetPoint(point_id))

            needed = self._MEASURE_POINTS_NEEDED[self._measure_mode]
            # An extra click after a completed measurement → reset and treat
            # this click as the new first point of a new measurement.
            if len(self._measure_pts) >= needed:
                self._clear_measurement()

            marker = self._add_measure_marker(xyz, snap_kind=skind)
            self._measure_pts.append({"xyz": xyz, "nid": nid, "marker": marker})

            n = len(self._measure_pts)
            if n < needed:
                self._status.showMessage(self._measure_prompt_for_pick(n))
                try:
                    self.plotter.render()
                except Exception:
                    pass
                return

            # Last point picked — compute and draw
            if self._measure_mode == "DIST":
                self._draw_distance_measurement()
            elif self._measure_mode == "RAD":
                self._draw_radius_measurement()
            elif self._measure_mode == "ANG":
                self._draw_angle_measurement()
        except Exception:
            logger.exception("Measure callback failed")

    def _add_measure_marker(self, xyz: tuple, snap_kind: str | None = None):
        """Add a marker sphere at *xyz*. Colour and size vary by *snap_kind*
        so vertices/midpoints/hole-centres are visually distinct."""
        color, size = self._SNAP_MARKER_STYLES.get(
            snap_kind, self._SNAP_MARKER_STYLES[None]
        )
        try:
            import pyvista as pv
            return self.plotter.add_mesh(
                pv.PolyData([list(xyz)]),
                color=color, point_size=size,
                render_points_as_spheres=True,
                pickable=False,
                reset_camera=False,
                label="_measure_marker",
            )
        except Exception:
            logger.debug("Measure marker add failed", exc_info=True)
            return None

    def _draw_distance_measurement(self) -> None:
        if len(self._measure_pts) < 2 or self.plotter is None:
            return
        a = self._measure_pts[0]
        b = self._measure_pts[1]
        ax, ay, az = a["xyz"]
        bx, by, bz = b["xyz"]
        dx, dy, dz = bx - ax, by - ay, bz - az
        dist = (dx * dx + dy * dy + dz * dz) ** 0.5
        mid = ((ax + bx) / 2.0, (ay + by) / 2.0, (az + bz) / 2.0)
        try:
            import pyvista as pv
            self._measure_line_actor = self.plotter.add_mesh(
                pv.Line(list(a["xyz"]), list(b["xyz"])),
                color="yellow", line_width=3,
                pickable=False, reset_camera=False,
                label="_measure_line",
            )
        except Exception:
            logger.debug("Measure line add failed", exc_info=True)
        try:
            self._measure_label_actor = self.plotter.add_point_labels(
                [list(mid)], [f"{dist:.3f}"],
                font_size=14, text_color="yellow",
                shape_color="black", shape_opacity=0.6,
                show_points=False, always_visible=True,
                pickable=False, reset_camera=False,
                name="_measure_label",
            )
        except Exception:
            logger.debug("Measure label add failed", exc_info=True)

        a_lbl = f"NID {a['nid']}" if a["nid"] is not None else "pt 1"
        b_lbl = f"NID {b['nid']}" if b["nid"] is not None else "pt 2"
        self._status.showMessage(
            f"Distance: {a_lbl} → {b_lbl} = {dist:.3f}  "
            f"(Δ {dx:.3f}, {dy:.3f}, {dz:.3f})"
        )
        try:
            self.plotter.render()
        except Exception:
            pass

    def _draw_radius_measurement(self) -> None:
        """Compute and render the circumscribed circle for 3 picked nodes:
        circumcenter, radius, and the circle itself drawn as a yellow polyline
        in the plane of the 3 points. Label shows ``R = <value>`` at the
        centre."""
        if len(self._measure_pts) < 3 or self.plotter is None:
            return
        import numpy as np
        p1 = np.asarray(self._measure_pts[0]["xyz"], dtype=float)
        p2 = np.asarray(self._measure_pts[1]["xyz"], dtype=float)
        p3 = np.asarray(self._measure_pts[2]["xyz"], dtype=float)
        result = self._compute_circumcircle(p1, p2, p3)
        if result is None:
            self._status.showMessage(
                "Radius: the 3 picked nodes are collinear — pick 3 non-collinear nodes"
            )
            self._clear_measurement()
            return
        center, radius, normal = result

        # Build a 64-segment polyline approximating the circle in the plane
        try:
            import pyvista as pv
            ref = np.array([1.0, 0.0, 0.0]) if abs(normal[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
            u = np.cross(normal, ref); u /= np.linalg.norm(u)
            v = np.cross(normal, u);   v /= np.linalg.norm(v)
            n_seg = 64
            thetas = np.linspace(0.0, 2.0 * np.pi, n_seg + 1)
            pts = [
                (center + radius * (np.cos(t) * u + np.sin(t) * v)).tolist()
                for t in thetas
            ]
            circle_actor = self.plotter.add_mesh(
                pv.lines_from_points(np.array(pts)),
                color="yellow", line_width=2,
                pickable=False, reset_camera=False,
                label="_measure_circle",
            )
            self._measure_extra_actors.append(circle_actor)
        except Exception:
            logger.debug("Radius circle add failed", exc_info=True)

        # Center marker + label
        try:
            import pyvista as pv
            center_marker = self.plotter.add_mesh(
                pv.PolyData([list(center)]),
                color="yellow", point_size=8,
                render_points_as_spheres=True,
                pickable=False, reset_camera=False,
                label="_measure_circle_center",
            )
            self._measure_extra_actors.append(center_marker)
        except Exception:
            logger.debug("Radius center marker add failed", exc_info=True)
        try:
            off = self._label_offset_world()
            label_pos = (center[0] + off, center[1] + off, center[2] + off)
            label_actor = self.plotter.add_point_labels(
                [list(label_pos)], [f"R = {radius:.3f}"],
                font_size=14, text_color="yellow",
                shape_color="black", shape_opacity=0.6,
                show_points=False, always_visible=True,
                pickable=False, reset_camera=False,
                name="_measure_radius_label",
            )
            self._measure_extra_actors.append(label_actor)
        except Exception:
            logger.debug("Radius label add failed", exc_info=True)

        self._status.showMessage(
            f"Radius: R = {radius:.3f}  "
            f"center ({center[0]:.3f}, {center[1]:.3f}, {center[2]:.3f})"
        )
        try:
            self.plotter.render()
        except Exception:
            pass

    def _draw_angle_measurement(self) -> None:
        """Compute the angle at p2 (vertex) with arms to p1 and p3. Draws
        two yellow arms and a label ``α = NN.NN°`` near the vertex."""
        if len(self._measure_pts) < 3 or self.plotter is None:
            return
        import numpy as np
        p1 = np.asarray(self._measure_pts[0]["xyz"], dtype=float)
        p2 = np.asarray(self._measure_pts[1]["xyz"], dtype=float)
        p3 = np.asarray(self._measure_pts[2]["xyz"], dtype=float)
        v1 = p1 - p2
        v2 = p3 - p2
        n1 = float(np.linalg.norm(v1))
        n2 = float(np.linalg.norm(v2))
        if n1 < 1e-12 or n2 < 1e-12:
            self._status.showMessage(
                "Angle: vertex coincides with another point — pick 3 distinct nodes"
            )
            self._clear_measurement()
            return
        cos_a = float(np.dot(v1, v2) / (n1 * n2))
        cos_a = max(-1.0, min(1.0, cos_a))
        angle_deg = float(np.degrees(np.arccos(cos_a)))

        # Two arms from vertex to p1 and p3
        try:
            import pyvista as pv
            arm1 = self.plotter.add_mesh(
                pv.Line(list(p2), list(p1)),
                color="yellow", line_width=3,
                pickable=False, reset_camera=False,
                label="_measure_arm1",
            )
            arm2 = self.plotter.add_mesh(
                pv.Line(list(p2), list(p3)),
                color="yellow", line_width=3,
                pickable=False, reset_camera=False,
                label="_measure_arm2",
            )
            self._measure_extra_actors.append(arm1)
            self._measure_extra_actors.append(arm2)
        except Exception:
            logger.debug("Angle arms add failed", exc_info=True)

        # Label offset from vertex along the angle bisector so it doesn't
        # overlap the marker
        try:
            bisector = v1 / n1 + v2 / n2
            bnorm = float(np.linalg.norm(bisector))
            if bnorm > 1e-9:
                bisector = bisector / bnorm
            else:
                bisector = np.array([1.0, 0.0, 0.0])
            off = self._label_offset_world() * 2.0
            label_pos = (
                float(p2[0] + bisector[0] * off),
                float(p2[1] + bisector[1] * off),
                float(p2[2] + bisector[2] * off),
            )
            label_actor = self.plotter.add_point_labels(
                [list(label_pos)], [f"Angle = {angle_deg:.2f}°"],
                font_size=14, text_color="yellow",
                shape_color="black", shape_opacity=0.6,
                show_points=False, always_visible=True,
                pickable=False, reset_camera=False,
                name="_measure_angle_label",
            )
            self._measure_extra_actors.append(label_actor)
        except Exception:
            logger.debug("Angle label add failed", exc_info=True)

        v_lbl = f"NID {self._measure_pts[1]['nid']}" if self._measure_pts[1]['nid'] is not None else "pt 2"
        self._status.showMessage(
            f"Angle (vertex {v_lbl}): {angle_deg:.2f}°"
        )
        try:
            self.plotter.render()
        except Exception:
            pass

    @staticmethod
    def _compute_circumcircle(p1, p2, p3):
        """Return ``(center, radius, normal)`` for the circle through p1/p2/p3
        or ``None`` if the points are (near-)collinear. Uses the barycentric
        formula for the circumcenter (robust in 3D)."""
        import numpy as np
        try:
            a = float(np.linalg.norm(p2 - p3))  # opposite to p1
            b = float(np.linalg.norm(p1 - p3))  # opposite to p2
            c = float(np.linalg.norm(p1 - p2))  # opposite to p3
            cross = np.cross(p2 - p1, p3 - p1)
            cross_mag = float(np.linalg.norm(cross))
            if cross_mag < 1e-12 or a * b * c < 1e-12:
                return None
            normal = cross / cross_mag
            # Barycentric weights for the circumcenter
            alpha = a * a * (b * b + c * c - a * a)
            beta  = b * b * (c * c + a * a - b * b)
            gamma = c * c * (a * a + b * b - c * c)
            denom = alpha + beta + gamma
            if abs(denom) < 1e-12:
                return None
            center = (alpha * p1 + beta * p2 + gamma * p3) / denom
            radius = float(np.linalg.norm(center - p1))
            return center, radius, normal
        except Exception:
            return None

    def _clear_measurement(self) -> None:
        if self.plotter is None:
            self._measure_pts = []
            self._measure_line_actor = None
            self._measure_label_actor = None
            self._measure_extra_actors = []
            return
        for p in self._measure_pts:
            actor = p.get("marker")
            if actor is not None:
                try:
                    self.plotter.remove_actor(actor)
                except Exception:
                    pass
        self._measure_pts = []
        if self._measure_line_actor is not None:
            try:
                self.plotter.remove_actor(self._measure_line_actor)
            except Exception:
                pass
            self._measure_line_actor = None
        if self._measure_label_actor is not None:
            try:
                self.plotter.remove_actor(self._measure_label_actor)
            except Exception:
                pass
            self._measure_label_actor = None
        for actor in self._measure_extra_actors:
            try:
                self.plotter.remove_actor(actor)
            except Exception:
                pass
        self._measure_extra_actors = []

    # ── Cut Plane (interactive clipping) ────────────────────────────────

    _CUT_MODE_NORMALS = {
        "X":    (1.0, 0.0, 0.0),
        "Y":    (0.0, 1.0, 0.0),
        "Z":    (0.0, 0.0, 1.0),
        "FREE": (1.0, 0.0, 0.0),  # initial normal, free to rotate
        "3PT":  (1.0, 0.0, 0.0),  # placeholder, replaced after picking
    }

    # Distinct gold used to paint the whole cross-section cap when the
    # "Highlight cut profile" Config option is on, so the cut profile reads
    # clearly regardless of the part's own colour.
    _CUT_CAP_HIGHLIGHT_COLOR = (1.0, 0.80, 0.10)

    def _set_cut_mode(self, mode: str, label: str | None = None) -> None:
        """Pick the cut plane mode from the combo dropdown.

        Picking a mode auto-activates the cut (or re-initializes if already on).
        The button text is updated to show the selected mode. All modes — 3PT
        included — start with a fresh plane: no position/orientation is cached
        across toggle off/on. Use ``Reset`` to clear the mode entirely.
        """
        if mode not in self._CUT_MODE_NORMALS:
            return
        self._cut_mode = mode
        if label is not None and getattr(self, "_cut_btn", None) is not None:
            self._cut_btn.setText(label)
            _cut_mode_icons = {
                "X":    "ZY_cut_plane.ico",
                "Y":    "ZX_cut_plane.ico",
                "Z":    "XY_cut_plane.ico",
                "FREE": "free_cut_plane.ico",
                "3PT":  "3P_cut_plane.ico",
            }
            _ico = os.path.join(_ICONS_DIR, _cut_mode_icons[mode])
            if os.path.exists(_ico):
                self._cut_btn.setIcon(QIcon(_ico))
        # Tear down anything currently active
        if self._cut_widget is not None:
            self._remove_cut_plane_widget()
        self._remove_cut_3pt_picking()

        self._cut_btn.blockSignals(True)
        self._cut_btn.setChecked(True)
        self._cut_btn.blockSignals(False)
        self._activate_cut_plane()

    def _action_toggle_cut_plane(self, checked: bool) -> None:
        if checked:
            self._activate_cut_plane()
        else:
            self._remove_cut_plane_widget()
            self._remove_cut_3pt_picking()

    def _activate_cut_plane(self) -> None:
        """Enter whichever cut workflow matches the current mode."""
        if self._cut_mode == "3PT":
            self._start_cut_3pt_picking()
        else:
            self._install_cut_plane_widget()

    def _install_cut_plane_widget(self, *, force_origin=None, force_normal=None) -> None:
        if self.plotter is None or self._polydata is None:
            self._status.showMessage("Cut Plane: load a model first")
            if getattr(self, "_cut_btn", None) is not None:
                self._cut_btn.setChecked(False)
            return
        if self._cut_widget is not None:
            return
        try:
            import vtk
            vtk_iren = self._vtk_interactor()
            if vtk_iren is None:
                self._status.showMessage("Cut Plane: interactor not available")
                self._cut_btn.setChecked(False)
                return

            bounds = self._polydata.bounds  # (xmin,xmax,ymin,ymax,zmin,zmax)
            if force_origin is not None:
                cx, cy, cz = force_origin
            else:
                cx = (bounds[0] + bounds[1]) / 2.0
                cy = (bounds[2] + bounds[3]) / 2.0
                cz = (bounds[4] + bounds[5]) / 2.0
            if force_normal is not None:
                nx, ny, nz = force_normal
                # 3PT plane locks the orientation — preserves the user's
                # explicit 3-node definition. Use Flip normal to invert.
                self._cut_locked_normal = (nx, ny, nz)
            else:
                nx, ny, nz = self._CUT_MODE_NORMALS[self._cut_mode]
                self._cut_locked_normal = (
                    (nx, ny, nz) if self._cut_mode != "FREE" else None
                )

            # Persistent shared plane: the widget mutates it on each interaction
            # and every actor mapper holds the same reference, so render() picks
            # up the new state without rebuilding geometry.
            self._cut_plane = vtk.vtkPlane()
            self._cut_plane.SetOrigin(cx, cy, cz)
            self._cut_plane.SetNormal(nx, ny, nz)

            rep = vtk.vtkImplicitPlaneRepresentation()
            rep.SetPlaceFactor(1.25)
            rep.PlaceWidget(bounds)
            rep.SetOrigin(cx, cy, cz)
            rep.SetNormal(nx, ny, nz)
            try:
                rep.OutlineTranslationOff()
                rep.ScaleEnabledOff()
            except Exception:
                pass

            self._cut_widget = vtk.vtkImplicitPlaneWidget2()
            self._cut_widget.SetInteractor(vtk_iren)
            self._cut_widget.SetRepresentation(rep)
            self._cut_widget.AddObserver(
                "InteractionEvent", self._on_cut_plane_changed
            )
            self._cut_widget.AddObserver(
                "EndInteractionEvent", self._on_cut_plane_released
            )
            self._cut_widget.On()

            self._snapshot_and_hide_edges()
            self._apply_cut_plane_to_actors()
            self._apply_cut_widget_visibility()
            # Reference point for the Offset spinbox: this origin == offset 0
            self._cut_initial_origin = (float(cx), float(cy), float(cz))
            self._set_cut_disp_silent(0.0)
            if self._slice_view_enabled:
                self._enter_slice_view()
            if self._caps_enabled_now():
                self._regenerate_cut_caps()
            mode_label = {
                "X": "X-normal", "Y": "Y-normal",
                "Z": "Z-normal", "FREE": "free",
                "3PT": "3 points",
            }[self._cut_mode]
            self._status.showMessage(
                f"Cut Plane: ON ({mode_label}) — drag the handle to move the plane"
            )
        except Exception:
            logger.exception("Failed to install Cut Plane widget")
            if getattr(self, "_cut_btn", None) is not None:
                self._cut_btn.setChecked(False)

    def _remove_cut_plane_widget(self) -> None:
        if self._cut_widget is not None:
            try:
                self._cut_widget.Off()
                self._cut_widget.SetInteractor(None)
            except Exception:
                pass
            self._cut_widget = None
        if self._cut_plane is not None:
            self._cut_plane = None
        self._cut_locked_normal = None
        self._cut_initial_origin = None
        self._set_cut_disp_silent(0.0)
        self._exit_slice_view()
        self._clear_cut_caps()
        self._clear_cut_plane_from_actors()
        self._restore_edges_snapshot()
        try:
            if self.plotter is not None:
                self.plotter.render()
        except Exception:
            pass
        self._status.showMessage("Cut Plane: OFF")

    def _set_cut_disp_silent(self, value: float) -> None:
        """Set the Offset spinbox value without firing valueChanged (used to
        sync the spinbox after the user has dragged the widget with the mouse
        — we must not feed that change back as another translation)."""
        spin = getattr(self, "_cut_disp_spin", None)
        if spin is None:
            return
        try:
            spin.blockSignals(True)
            spin.setValue(float(value))
        finally:
            spin.blockSignals(False)

    def _on_cut_disp_changed(self, value: float) -> None:
        """Spinbox value changed (typed, arrows or wheel). Translate the
        plane to ``initial_origin + value * current_normal`` along the
        normal that the plane has right now (flips and rotations are honored)."""
        if (
            self._cut_widget is None
            or self._cut_plane is None
            or self._cut_initial_origin is None
        ):
            return
        try:
            ox0, oy0, oz0 = self._cut_initial_origin
            nx, ny, nz = self._cut_plane.GetNormal()
            new_origin = (ox0 + nx * value, oy0 + ny * value, oz0 + nz * value)
            self._cut_plane.SetOrigin(new_origin)
            try:
                rep = self._cut_widget.GetRepresentation()
                if rep is not None:
                    rep.SetOrigin(new_origin)
            except Exception:
                pass
            if self._caps_enabled_now():
                self._regenerate_cut_caps()
            try:
                self.plotter.render()
            except Exception:
                pass
            self._status.showMessage(
                f"Cut Plane: offset = {value:+.4f} along normal"
            )
        except Exception:
            logger.debug("Cut plane offset apply failed", exc_info=True)

    def _on_cut_disp_context_menu(self, pos) -> None:
        """Right-click on the Offset spinbox → menu with 'Set step…' and
        'Reset displacement to 0'."""
        spin = self._cut_disp_spin
        menu = QMenu(spin)
        act_step = menu.addAction(f"Set step…  (current: {self._cut_step_value:g})")
        act_reset = menu.addAction("Reset displacement to 0")
        act_step.triggered.connect(self._prompt_set_cut_step)
        act_reset.triggered.connect(lambda: self._cut_disp_spin.setValue(0.0))
        menu.exec(spin.mapToGlobal(pos))

    def _prompt_set_cut_step(self) -> None:
        """Ask the user for a new step value (singleStep of the Offset spinbox)."""
        from PySide6.QtWidgets import QInputDialog
        new_step, ok = QInputDialog.getDouble(
            self, "Cut Plane step",
            "Step (model units) for each arrow click or wheel notch:",
            value=float(self._cut_step_value),
            minValue=0.0001, maxValue=1.0e9, decimals=4,
        )
        if not ok or new_step <= 0:
            return
        self._cut_step_value = float(new_step)
        try:
            self._cut_disp_spin.setSingleStep(self._cut_step_value)
        except Exception:
            pass
        self._status.showMessage(
            f"Cut Plane step set to {self._cut_step_value:g}"
        )

    def _flip_cut_normal(self) -> None:
        """Reverse the cut plane normal so the previously-hidden half becomes
        visible (and vice versa). Updates both the persistent plane and the
        widget representation so the arrow handle flips on screen."""
        if self._cut_plane is None or self._cut_widget is None:
            self._status.showMessage("Flip normal: activate Cut Plane first")
            return
        try:
            nx, ny, nz = self._cut_plane.GetNormal()
            nx, ny, nz = -nx, -ny, -nz
            self._cut_plane.SetNormal(nx, ny, nz)
            if self._cut_locked_normal is not None:
                self._cut_locked_normal = (nx, ny, nz)
            try:
                rep = self._cut_widget.GetRepresentation()
                if rep is not None:
                    rep.SetNormal(nx, ny, nz)
            except Exception:
                pass
            # Plane origin is unchanged but the meaning of "+ displacement"
            # along the normal has flipped — negate the spinbox value so it
            # still describes the same point on the plane.
            spin = getattr(self, "_cut_disp_spin", None)
            if spin is not None:
                self._set_cut_disp_silent(-float(spin.value()))
            if self._caps_enabled_now():
                self._regenerate_cut_caps()
            try:
                self.plotter.render()
            except Exception:
                pass
        except Exception:
            logger.debug("Flip cut normal failed", exc_info=True)

    # ── 3-Points cut plane (pick 3 nodes to define the plane) ──────────

    def _start_cut_3pt_picking(self) -> None:
        if self.plotter is None or self._polydata is None:
            self._status.showMessage("Cut Plane (3 Points): load a model first")
            if getattr(self, "_cut_btn", None) is not None:
                self._cut_btn.setChecked(False)
            return
        if self._cut_3pt_observer_id is not None:
            return
        # Mutual exclusion with the other left-click observers
        if self._pick_node_observer_id is not None:
            if getattr(self, "_a_pick_node", None) is not None:
                self._a_pick_node.setChecked(False)
            self._remove_pick_node_observer()
        if self._measure_observer_id is not None:
            if getattr(self, "_measure_btn", None) is not None:
                self._measure_btn.setChecked(False)
            self._remove_measure_observer()
        try:
            import vtk
            if self._pick_node_picker is None:
                self._pick_node_picker = vtk.vtkPointPicker()
                self._pick_node_picker.SetTolerance(0.005)
            vtk_iren = self._vtk_interactor()
            if vtk_iren is None:
                self._status.showMessage("Cut Plane (3 Points): interactor not available")
                self._cut_btn.setChecked(False)
                return
            self._cut_3pt_pts = []
            self._cut_3pt_markers = []
            self._cut_3pt_observer_id = vtk_iren.AddObserver(
                "LeftButtonPressEvent", self._on_cut_3pt_click, 10.0
            )
            try:
                self.plotter.setCursor(Qt.CursorShape.CrossCursor)
            except Exception:
                pass
            self._status.showMessage(
                "Cut Plane (3 Points): left-click the first node"
            )
        except Exception:
            logger.exception("Failed to start 3-point cut plane picking")
            if getattr(self, "_cut_btn", None) is not None:
                self._cut_btn.setChecked(False)

    def _on_cut_3pt_click(self, caller, _event) -> None:
        try:
            x, y = caller.GetEventPosition()
            # Snap selection takes priority
            snap = self._find_snap_at(x, y)
            if snap is not None:
                xyz = snap[0]
                skind = snap[1]
            else:
                skind = None
                picker = self._pick_node_picker
                renderer = self.plotter.renderer
                picker.Pick(x, y, 0, renderer)
                point_id = picker.GetPointId()
                if point_id < 0:
                    self._status.showMessage(
                        "Cut Plane (3 Points): no hit — click on the geometry"
                    )
                    return
                ds = picker.GetDataSet()
                if ds is None:
                    return
                xyz = tuple(float(c) for c in ds.GetPoint(point_id))

            self._cut_3pt_pts.append(xyz)
            self._add_cut_3pt_marker(xyz, snap_kind=skind)

            n = len(self._cut_3pt_pts)
            if n == 1:
                self._status.showMessage(
                    "Cut Plane (3 Points): 1 of 3 picked — click the second node"
                )
                try:
                    self.plotter.render()
                except Exception:
                    pass
                return
            if n == 2:
                self._status.showMessage(
                    "Cut Plane (3 Points): 2 of 3 picked — click the third node"
                )
                try:
                    self.plotter.render()
                except Exception:
                    pass
                return

            # We have 3 points — compute the plane
            p1, p2, p3 = self._cut_3pt_pts
            result = self._compute_plane_from_3_points(p1, p2, p3)
            if result is None:
                self._status.showMessage(
                    "Cut Plane (3 Points): the 3 picked nodes are collinear — "
                    "pick 3 non-collinear nodes"
                )
                self._clear_cut_3pt_markers()
                self._cut_3pt_pts = []
                return

            origin, normal = result
            # End picking and install the widget
            self._remove_cut_3pt_observer_only()
            self._clear_cut_3pt_markers()
            self._install_cut_plane_widget(
                force_origin=origin, force_normal=normal,
            )
        except Exception:
            logger.exception("Cut Plane (3 Points) click failed")

    @staticmethod
    def _compute_plane_from_3_points(p1, p2, p3):
        """Return ``(origin, normal)`` for the plane through p1/p2/p3 or
        ``None`` if the three points are (near-)collinear."""
        try:
            v1 = (p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2])
            v2 = (p3[0] - p1[0], p3[1] - p1[1], p3[2] - p1[2])
            nx = v1[1] * v2[2] - v1[2] * v2[1]
            ny = v1[2] * v2[0] - v1[0] * v2[2]
            nz = v1[0] * v2[1] - v1[1] * v2[0]
            mag = (nx * nx + ny * ny + nz * nz) ** 0.5
            if mag < 1e-9:
                return None
            normal = (nx / mag, ny / mag, nz / mag)
            origin = (
                (p1[0] + p2[0] + p3[0]) / 3.0,
                (p1[1] + p2[1] + p3[1]) / 3.0,
                (p1[2] + p2[2] + p3[2]) / 3.0,
            )
            return origin, normal
        except Exception:
            return None

    def _add_cut_3pt_marker(self, xyz: tuple, snap_kind: str | None = None) -> None:
        if self.plotter is None:
            return
        color, size = self._SNAP_MARKER_STYLES.get(
            snap_kind, self._SNAP_MARKER_STYLES[None]
        )
        try:
            import pyvista as pv
            actor = self.plotter.add_mesh(
                pv.PolyData([list(xyz)]),
                color=color, point_size=size,
                render_points_as_spheres=True,
                pickable=False, reset_camera=False,
                label="_cut_3pt_marker",
            )
            self._cut_3pt_markers.append(actor)
        except Exception:
            logger.debug("3PT marker add failed", exc_info=True)

    def _clear_cut_3pt_markers(self) -> None:
        if self.plotter is None:
            self._cut_3pt_markers = []
            return
        for actor in self._cut_3pt_markers:
            try:
                self.plotter.remove_actor(actor)
            except Exception:
                pass
        self._cut_3pt_markers = []

    def _remove_cut_3pt_observer_only(self) -> None:
        """Detach the picking observer without clearing markers/state.

        Used at the end of a successful 3-pick sequence — the widget install
        path clears the markers itself after consuming the picked points.
        """
        if self._cut_3pt_observer_id is None:
            return
        try:
            vtk_iren = self._vtk_interactor()
            if vtk_iren is not None:
                vtk_iren.RemoveObserver(self._cut_3pt_observer_id)
        except Exception:
            pass
        self._cut_3pt_observer_id = None
        try:
            self.plotter.unsetCursor()
        except Exception:
            pass

    def _remove_cut_3pt_picking(self) -> None:
        """Cancel an in-progress 3-point picking session (markers + observer)."""
        self._remove_cut_3pt_observer_only()
        self._clear_cut_3pt_markers()
        self._cut_3pt_pts = []

    def _on_cut_plane_changed(self, caller, _event) -> None:
        try:
            rep = caller.GetRepresentation()
            if rep is None or self._cut_plane is None:
                return
            # Update the shared plane in place so all mappers see the new state
            rep.GetPlane(self._cut_plane)
            # In orthogonal modes the user may only translate; re-clamp the
            # normal so the widget arrow cannot drift the plane off-axis.
            if self._cut_locked_normal is not None:
                nx, ny, nz = self._cut_locked_normal
                self._cut_plane.SetNormal(nx, ny, nz)
                try:
                    rep.SetNormal(nx, ny, nz)
                except Exception:
                    pass
            # Sync the Offset spinbox so the user sees the displacement that
            # the mouse drag just produced. Silent set — no feedback loop.
            if self._cut_initial_origin is not None:
                ox0, oy0, oz0 = self._cut_initial_origin
                cx, cy, cz = self._cut_plane.GetOrigin()
                nx, ny, nz = self._cut_plane.GetNormal()
                disp = (cx - ox0) * nx + (cy - oy0) * ny + (cz - oz0) * nz
                self._set_cut_disp_silent(disp)
            self.plotter.render()
        except Exception:
            logger.debug("Cut Plane interaction callback failed", exc_info=True)

    def _caps_enabled_now(self) -> bool:
        """Caps are generated when either the Config checkbox is checked OR
        the Slice-only view toggle is active (which forces caps so the
        cross-section is visible)."""
        return self._close_cut_caps or self._slice_view_enabled

    def _apply_cut_widget_visibility(self) -> None:
        """Show/hide the plane-widget visuals (handle, arrow, outline,
        rectangle) without disabling the clipping effect itself."""
        if self._cut_widget is None:
            return
        try:
            rep = self._cut_widget.GetRepresentation()
            if rep is not None:
                rep.SetVisibility(1 if self._cut_widget_visible else 0)
        except Exception:
            pass

    def _on_cut_widget_visible_toggled(self, checked: bool) -> None:
        """Config → 'Show cut plane widget' checkbox handler. Applies
        immediately if the cut is active; otherwise just remembers the
        preference for the next time the cut is enabled."""
        self._cut_widget_visible = bool(checked)
        if self._cut_widget is None:
            return
        self._apply_cut_widget_visibility()
        try:
            self.plotter.render()
        except Exception:
            pass

    def _toggle_slice_view(self, checked: bool) -> None:
        """Slice-only view toggle (Cut Plane menu item).

        Acts on the currently active cut plane — does NOT replace the plane.
        Toggle ON: hide all model actors, force-generate caps in part colours.
        Toggle OFF: restore visibility, drop caps unless the Config checkbox
        keeps them on. Preference persists across cut off/on toggles.
        """
        self._slice_view_enabled = bool(checked)
        if self._cut_widget is None:
            if checked:
                self._status.showMessage(
                    "Slice only: enabled — applies once the Cut Plane is active"
                )
            return
        if self._slice_view_enabled:
            self._enter_slice_view()
            self._regenerate_cut_caps()
            self._status.showMessage("Slice only: ON — only cut caps visible")
        else:
            self._exit_slice_view()
            if not self._close_cut_caps:
                self._clear_cut_caps()
            self._status.showMessage("Slice only: OFF")
        try:
            self.plotter.render()
        except Exception:
            pass

    def _on_cut_plane_released(self, _caller, _event) -> None:
        """Mouse released after a drag interaction with the plane widget.

        Caps regeneration (vtkCutter + vtkContourTriangulator) is deferred to
        this point so the drag itself stays interactive (only the cheap mapper
        clipping happens at InteractionEvent rate)."""
        if not self._caps_enabled_now():
            return
        self._regenerate_cut_caps()

    def _enter_slice_view(self) -> None:
        """SLICE mode: hide every model actor so only the cap polygons remain
        visible. Visibility is snapshotted so the previous state can be
        restored when leaving the mode."""
        self._slice_hidden_actors = []
        for actor in self._slice_hideable_actors():
            try:
                prev = bool(actor.GetVisibility())
                self._slice_hidden_actors.append((actor, prev))
                actor.SetVisibility(0)
            except Exception:
                pass

    def _exit_slice_view(self) -> None:
        for actor, prev in self._slice_hidden_actors:
            try:
                actor.SetVisibility(1 if prev else 0)
            except Exception:
                pass
        self._slice_hidden_actors = []

    def _slice_hideable_actors(self):
        """All non-cap actors that should be hidden in SLICE mode."""
        seen = set()
        sources: list = []
        sources.extend(self._part_actors.values())
        sources.extend(self._entity_actors.values())
        sources.extend(getattr(self, "_style_fe_actors", {}).values())
        sources.extend(getattr(self, "_material_fe_actors", {}).values())
        sources.extend(getattr(self, "_highlight_fe_actors", {}).values())
        if getattr(self, "_wire_overlay_actor", None) is not None:
            sources.append(self._wire_overlay_actor)
        for actor in sources:
            if actor is None or id(actor) in seen:
                continue
            seen.add(id(actor))
            yield actor

    def _regenerate_cut_caps(self) -> None:
        """Build one cap polygon per part by intersecting the part polydata
        with the active cut plane and triangulating the resulting loops.

        Cap color follows the part's base color so the cross-section visually
        matches the rest of the part. Open meshes (typical *ELEMENT_SHELL*
        parts) often produce no closed loop — those parts get no cap, which is
        the documented degradation for shell-only models.
        """
        self._clear_cut_caps()
        if (
            not self._close_cut_caps
            or self._cut_plane is None
            or self.plotter is None
            or not self._part_polydata
        ):
            return
        try:
            import vtk
            import pyvista as pv
        except Exception:
            return

        highlight = bool(getattr(self, "_highlight_cut_caps", False))
        for pid, sub_pd in self._part_polydata.items():
            try:
                # vtkCutter wants a vtk.vtkPolyData input. pyvista PolyData
                # subclasses it so we can pass it directly.
                cutter = vtk.vtkCutter()
                cutter.SetInputData(sub_pd)
                cutter.SetCutFunction(self._cut_plane)
                cutter.Update()
                cut_pd = cutter.GetOutput()
                if cut_pd is None or cut_pd.GetNumberOfPoints() == 0:
                    continue

                # Each intersected triangle emits its own copy of the shared
                # edge-intersection points, so the open segment ends never
                # match exactly: vtkStripper can't close the loop and the
                # triangulator produces no cap (this is what leaves the tube
                # cross-section open). Merge the coincident points first.
                cleaner = vtk.vtkCleanPolyData()
                cleaner.SetInputData(cut_pd)
                cleaner.PointMergingOn()
                cleaner.ConvertLinesToPointsOff()
                cleaner.ConvertPolysToLinesOff()
                cleaner.Update()
                cleaned = cleaner.GetOutput()
                if cleaned is None or cleaned.GetNumberOfPoints() == 0:
                    continue

                # Join short line segments into longer polylines so the
                # triangulator sees closed loops. JoinContiguousSegments is
                # intentionally left OFF: it bridges across open features
                # (notches/slots), making the triangulator fill regions that
                # must stay open. Merging coincident points above is enough to
                # close genuine loops (e.g. the tube cross-section).
                stripper = vtk.vtkStripper()
                stripper.SetInputData(cleaned)
                stripper.Update()
                stripped = stripper.GetOutput()
                if stripped is None or stripped.GetNumberOfPoints() == 0:
                    continue

                tri = vtk.vtkContourTriangulator()
                tri.SetInputData(stripped)
                tri.Update()
                cap_pd = tri.GetOutput()
                if cap_pd is None or cap_pd.GetNumberOfPolys() == 0:
                    continue

                if highlight:
                    color = self._CUT_CAP_HIGHLIGHT_COLOR
                else:
                    color = self._part_base_color.get(pid, (0.7, 0.7, 0.7))
                cap_actor = self.plotter.add_mesh(
                    pv.PolyData(cap_pd),
                    color=color,
                    pickable=False, reset_camera=False,
                    label=f"_cut_cap_{pid}",
                )
                self._cut_cap_actors[pid] = cap_actor
            except Exception:
                logger.debug("Cut cap generation failed for pid %s", pid, exc_info=True)

        try:
            self.plotter.render()
        except Exception:
            pass

    def _clear_cut_caps(self) -> None:
        if not self._cut_cap_actors:
            return
        if self.plotter is None:
            self._cut_cap_actors.clear()
            return
        for actor in list(self._cut_cap_actors.values()):
            try:
                self.plotter.remove_actor(actor)
            except Exception:
                pass
        self._cut_cap_actors.clear()

    def _on_close_cut_caps_toggled(self, checked: bool) -> None:
        """Config → 'Close cut caps' checkbox handler. Applies immediately
        when the cut plane is active; otherwise the preference is just stored
        for the next time the cut is enabled."""
        self._close_cut_caps = bool(checked)
        if self._cut_widget is None:
            return
        if self._close_cut_caps:
            self._regenerate_cut_caps()
        else:
            self._clear_cut_caps()
            try:
                self.plotter.render()
            except Exception:
                pass

    def _on_highlight_cut_caps_toggled(self, checked: bool) -> None:
        """Config → 'Highlight cut profile' checkbox handler. Re-colours the
        cross-section caps live when they are currently shown; otherwise the
        preference is just stored for the next time caps are generated."""
        self._highlight_cut_caps = bool(checked)
        if self._cut_widget is None or not self._caps_enabled_now():
            return
        self._regenerate_cut_caps()

    def _snapshot_and_hide_edges(self) -> None:
        """Snapshot edge visibility and hide all edge-bearing actors while the
        cut plane is active so the clipped silhouette reads as a clean surface.

        Covers:
          * per-part actors      → ``EdgeVisibility = 0``
          * Wireframe-style edge actors (``_style_fe_actors``,
            ``_wire_overlay_actor``) → full actor visibility off

        Skipped while ``self._hide_cut_edges`` is False (Config checkbox).
        """
        self._cut_edge_snapshot = {}
        self._cut_aux_visibility = []
        if not self._hide_cut_edges:
            return
        for pid, actor in self._part_actors.items():
            if actor is None:
                continue
            try:
                prop = actor.GetProperty()
                self._cut_edge_snapshot[pid] = bool(prop.GetEdgeVisibility())
                prop.SetEdgeVisibility(0)
            except Exception:
                pass
        for actor in self._cut_auxiliary_edge_actors():
            try:
                prev = bool(actor.GetVisibility())
                self._cut_aux_visibility.append((actor, prev))
                actor.SetVisibility(0)
            except Exception:
                pass

    def _restore_edges_snapshot(self) -> None:
        for pid, was_visible in self._cut_edge_snapshot.items():
            actor = self._part_actors.get(pid)
            if actor is None:
                continue
            try:
                actor.GetProperty().SetEdgeVisibility(1 if was_visible else 0)
            except Exception:
                pass
        self._cut_edge_snapshot = {}
        for actor, prev in self._cut_aux_visibility:
            try:
                actor.SetVisibility(1 if prev else 0)
            except Exception:
                pass
        self._cut_aux_visibility = []

    def _cut_auxiliary_edge_actors(self):
        """Dedicated wireframe/edge actors that live alongside the main part
        actors and must be hidden (not just edge-toggled) while ``Hide cut
        edges`` is active."""
        seen = set()
        sources: list = []
        sources.extend(getattr(self, "_style_fe_actors", {}).values())
        if getattr(self, "_wire_overlay_actor", None) is not None:
            sources.append(self._wire_overlay_actor)
        for actor in sources:
            if actor is None or id(actor) in seen:
                continue
            seen.add(id(actor))
            yield actor

    def _on_hide_cut_edges_toggled(self, checked: bool) -> None:
        """Config → 'Hide cut edges' checkbox handler. Applies immediately when
        the cut plane is active, no-op otherwise (the preference is remembered
        and used the next time the cut is enabled)."""
        self._hide_cut_edges = bool(checked)
        if self._cut_widget is None:
            return
        if self._hide_cut_edges:
            self._snapshot_and_hide_edges()
        else:
            self._restore_edges_snapshot()
        try:
            self.plotter.render()
        except Exception:
            pass

    def _apply_cut_plane_to_actors(self) -> None:
        if self._cut_plane is None or self.plotter is None:
            return
        for actor in self._cut_clip_targets():
            try:
                mapper = actor.GetMapper()
                if mapper is None:
                    continue
                mapper.RemoveAllClippingPlanes()
                mapper.AddClippingPlane(self._cut_plane)
            except Exception:
                pass
        try:
            self.plotter.render()
        except Exception:
            pass

    def _clear_cut_plane_from_actors(self) -> None:
        if self.plotter is None:
            return
        for actor in self._cut_clip_targets():
            try:
                mapper = actor.GetMapper()
                if mapper is not None:
                    mapper.RemoveAllClippingPlanes()
            except Exception:
                pass

    def _cut_clip_targets(self):
        """Actors to apply the clipping plane to.

        Covers every actor that renders geometry/edges so nothing visually
        floats through the cut: parts, entity overlays (SET_NODE/SHELL/...),
        Wireframe-mode edge actors, material feature-edges, and selection
        highlights.
        """
        seen = set()
        sources: list = []
        sources.extend(self._part_actors.values())
        sources.extend(self._entity_actors.values())
        sources.extend(getattr(self, "_style_fe_actors", {}).values())
        sources.extend(getattr(self, "_material_fe_actors", {}).values())
        sources.extend(getattr(self, "_highlight_fe_actors", {}).values())
        if getattr(self, "_wire_overlay_actor", None) is not None:
            sources.append(self._wire_overlay_actor)
        for actor in sources:
            if actor is not None and id(actor) not in seen:
                seen.add(id(actor))
                yield actor

    # ── Tab: Configuration ────────────────────────────────────────────────

    def _build_tb_configuration(self) -> QToolBar:
        tb = QToolBar()
        self._tb_act(tb, "Clear Cache", None, "Delete cached VTK data for this file", self._action_clear_cache)
        tb.addSeparator()
        self._tb_act(tb, "About", None, "About 3D Viewer 2.0", self._action_about)
        return tb

    @staticmethod
    def _tb_act(tb: QToolBar, label: str, shortcut: str | None, tooltip: str, slot) -> QAction:
        act = QAction(label)
        if shortcut:
            act.setShortcut(shortcut)
        act.setToolTip(tooltip)
        act.triggered.connect(slot)
        tb.addAction(act)
        return act

    def _vtk_guarded(self, fn):
        def _wrapper():
            if self.plotter is not None:
                fn()
                self.plotter.render()
        return _wrapper

    def _apply_current_view(self) -> None:
        """Re-apply the currently selected View-tab orientation. Clicking the
        View button face keeps the chosen view instead of forcing isometric;
        defaults to isometric until the user picks a view from the dropdown."""
        if self.plotter is None:
            return
        fn = getattr(self, "_v2_current_view_fn", None)
        if fn is None:
            fn = lambda: self.plotter.view_isometric()
        self._vtk_guarded(fn)()

    # =========================================================================
    #  Body — three-panel splitter
    # =========================================================================

    def _build_body(self) -> QWidget:
        """Build the body area: activity bar + three-panel splitter."""
        body = QWidget()
        body_lay = QHBoxLayout(body)
        body_lay.setContentsMargins(0, 0, 0, 0)
        body_lay.setSpacing(0)

        body_lay.addWidget(self._build_activity_bar())
        body_lay.addWidget(self._build_splitter(), stretch=1)
        return body

    def _build_splitter(self) -> QSplitter:
        spl = QSplitter(Qt.Orientation.Horizontal)
        spl.setHandleWidth(4)
        spl.setChildrenCollapsible(True)
        spl.addWidget(self._build_left_panel())
        spl.addWidget(self._build_viewport_area())
        self._right_panel = self._build_right_panel()
        spl.addWidget(self._right_panel)
        spl.setSizes([_SPLIT_LEFT, _SPLIT_CENTER, _SPLIT_RIGHT])
        spl.setStretchFactor(0, 0)
        spl.setStretchFactor(1, 1)
        spl.setStretchFactor(2, 0)
        self._main_splitter = spl
        return spl

    # ── Activity bar ──────────────────────────────────────────────────────

    def _build_activity_bar(self) -> QWidget:
        bar = QWidget()
        bar.setObjectName("activity_bar")
        lay = QVBoxLayout(bar)
        lay.setContentsMargins(3, 6, 3, 6)
        lay.setSpacing(4)
        lay.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignHCenter)

        # Toggle button — collapses / expands the left panel
        self._act_toggle_btn = QToolButton()
        self._act_toggle_btn.setText("◀")
        self._act_toggle_btn.setToolTip("Hide/show side panel")
        self._act_toggle_btn.setCheckable(False)
        self._act_toggle_btn.clicked.connect(self._toggle_left_panel)
        lay.addWidget(self._act_toggle_btn, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Visual separator
        sep = QFrame()
        sep.setObjectName("act_sep")
        sep.setFrameShape(QFrame.Shape.HLine)
        lay.addWidget(sep)

        # Files tab button        
        self._act_files_btn = QToolButton()
        _file_ico = os.path.join(_ICONS_DIR, "open_file_viewer_v2.ico")
        if os.path.exists(_file_ico):
            self._act_files_btn.setIcon(QIcon(_file_ico))
            self._act_files_btn.setIconSize(QSize(32, 32))
        else:
            self._act_files_btn.setText("📁")
        self._act_files_btn.setToolTip("Project Files")
        self._act_files_btn.setCheckable(True)
        self._act_files_btn.clicked.connect(lambda: self._act_show_tab(0))
        lay.addWidget(self._act_files_btn, alignment=Qt.AlignmentFlag.AlignHCenter)
        
        # Navigator tab button
        self._act_nav_btn = QToolButton()
        _nav_ico = os.path.join(_ICONS_DIR, "navigator_tree.ico")
        if os.path.exists(_nav_ico):
            self._act_nav_btn.setIcon(QIcon(_nav_ico))
            self._act_nav_btn.setIconSize(QSize(32, 32))
        else:
            self._act_nav_btn.setText("🌲")
        self._act_nav_btn.setToolTip("Model Navigator")
        self._act_nav_btn.setCheckable(True)
        self._act_nav_btn.clicked.connect(lambda: self._act_show_tab(1))
        lay.addWidget(self._act_nav_btn, alignment=Qt.AlignmentFlag.AlignHCenter)

        # Configuration tab button       
        self._act_cfg_btn = QToolButton()
        _cfg_ico = os.path.join(_ICONS_DIR, "settings_viewer_v2.ico")
        if os.path.exists(_cfg_ico):
            self._act_cfg_btn.setIcon(QIcon(_cfg_ico))
            self._act_cfg_btn.setIconSize(QSize(32, 32))
        else:
            self._act_cfg_btn.setText("🌲")
        self._act_cfg_btn.setToolTip("Model Navigator")
        self._act_cfg_btn.setCheckable(True)
        self._act_cfg_btn.clicked.connect(lambda: self._act_show_tab(2))
        lay.addWidget(self._act_cfg_btn, alignment=Qt.AlignmentFlag.AlignHCenter)
        

        lay.addStretch()
        return bar

    def _toggle_left_panel(self):
        """Collapse or expand the left side panel."""
        if self._left_panel_open:
            sizes = self._main_splitter.sizes()
            self._left_panel_size = max(sizes[0], 60)
            total = sizes[0] + sizes[1]
            self._main_splitter.setSizes([0, total, sizes[2]])
            self._act_toggle_btn.setText("▶")
            self._act_toggle_btn.setToolTip("Show side panel")
        else:
            sizes = self._main_splitter.sizes()
            w = self._left_panel_size or _SPLIT_LEFT
            center = max(200, sizes[0] + sizes[1] - w)
            self._main_splitter.setSizes([w, center, sizes[2]])
            self._act_toggle_btn.setText("◀")
            self._act_toggle_btn.setToolTip("Hide side panel")
        self._left_panel_open = not self._left_panel_open

    def _act_show_tab(self, index: int):
        """Show a specific tab in the left panel, opening it if collapsed."""
        # Update checked state of activity buttons
        self._act_files_btn.setChecked(index == 0)
        self._act_nav_btn.setChecked(index == 1)
        self._act_cfg_btn.setChecked(index == 2)
        # Switch tab
        self._left_tabs.setCurrentIndex(index)
        # If panel is collapsed, expand it
        if not self._left_panel_open:
            self._toggle_left_panel()

    def _on_left_tab_changed(self, index: int):
        """Sync activity bar button checked state when tab changes directly."""
        self._act_files_btn.setChecked(index == 0)
        self._act_nav_btn.setChecked(index == 1)
        self._act_cfg_btn.setChecked(index == 2)

    # ── Left panel ────────────────────────────────────────────────────────

    def _build_left_panel(self) -> QTabWidget:
        tabs = QTabWidget()
        tabs.setObjectName("side_tabs")
        tabs.setMinimumWidth(160)

        # Tab 1: Project Files
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(_panel_header("Project Files"))
        self._files_list = QListWidget()
        self._files_list.setToolTip("Double-click a .k file to open it")
        self._files_list.itemDoubleClicked.connect(self._on_file_double_clicked)
        lay.addWidget(self._files_list)
        self._populate_files_list()
        tabs.addTab(w, "Files")

        # Tab 2: Model Navigator
        w2 = QWidget()
        lay2 = QVBoxLayout(w2)
        lay2.setContentsMargins(0, 0, 0, 0)
        lay2.setSpacing(0)
        lay2.addWidget(_panel_header("Model Navigator"))
        self._nav_tree = QTreeWidget()
        self._nav_tree.setObjectName("side_tree")
        self._nav_tree.setHeaderHidden(True)
        self._nav_tree.setColumnCount(1)
        self._nav_tree.setSelectionMode(QTreeWidget.SelectionMode.ExtendedSelection)
        # Allow column to grow beyond panel width; horizontal scrollbar appears as needed
        self._nav_tree.header().setStretchLastSection(False)
        self._nav_tree.header().setSectionResizeMode(
            0, self._nav_tree.header().ResizeMode.ResizeToContents
        )
        self._nav_tree.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self._nav_tree.itemChanged.connect(self._on_nav_item_checked)
        self._nav_tree.itemSelectionChanged.connect(self._on_nav_selection_changed)
        self._nav_tree_placeholder()
        lay2.addWidget(self._nav_tree)
        tabs.addTab(w2, "Navigator")

        # Tab 3: Configuration
        w3 = QWidget()
        lay3 = QVBoxLayout(w3)
        lay3.setContentsMargins(0, 0, 0, 0)
        lay3.setSpacing(0)
        lay3.addWidget(_panel_header("Configuration"))
        cfg_inner = QWidget()
        cfg_inner.setObjectName("cfg_panel")
        cfg_lay = QVBoxLayout(cfg_inner)
        cfg_lay.setContentsMargins(8, 8, 8, 8)
        cfg_lay.setSpacing(6)
        from PySide6.QtWidgets import QPushButton

        # ── Phantom mode ────────────────────────────────────────────────
        self._cfg_phantom_check = QCheckBox("Phantom mode")
        self._cfg_phantom_check.setToolTip(
            "Dim non-selected parts when a part is selected in the navigator"
        )
        self._cfg_phantom_check.setChecked(self._phantom_enabled)
        self._cfg_phantom_check.toggled.connect(self._on_phantom_toggled)
        cfg_lay.addWidget(self._cfg_phantom_check)

        opacity_row = QHBoxLayout()
        opacity_row.setContentsMargins(20, 0, 0, 0)  # indent under the checkbox
        opacity_row.setSpacing(6)
        opacity_row.addWidget(QLabel("Phantom opacity:"))
        self._cfg_phantom_opacity = QSpinBox()
        self._cfg_phantom_opacity.setRange(0, 100)
        self._cfg_phantom_opacity.setSingleStep(5)
        self._cfg_phantom_opacity.setSuffix(" %")
        self._cfg_phantom_opacity.setValue(int(round(self._phantom_opacity * 100)))
        self._cfg_phantom_opacity.setToolTip(
            "Opacity applied to non-selected parts while Phantom mode is on"
        )
        self._cfg_phantom_opacity.valueChanged.connect(self._on_phantom_opacity_changed)
        opacity_row.addWidget(self._cfg_phantom_opacity)
        opacity_row.addStretch(1)
        cfg_lay.addLayout(opacity_row)

        # ── Phantom Color (custom override for dimmed parts) ──────────────
        phantom_color_row = QHBoxLayout()
        phantom_color_row.setContentsMargins(20, 0, 0, 0)
        phantom_color_row.setSpacing(8)
        phantom_color_row.addWidget(QLabel("Phantom Color:"))
        self._cfg_phantom_color_swatch = self._make_color_swatch_btn((0.5, 0.5, 0.5))
        self._cfg_phantom_color_swatch.setToolTip(
            "Custom color applied to all parts that are dimmed by Phantom mode.\n"
            "Click the 'Auto' button on the right to clear and let each part keep its own color."
        )
        self._cfg_phantom_color_swatch.clicked.connect(self._on_pick_phantom_color)
        phantom_color_row.addWidget(self._cfg_phantom_color_swatch)
        self._cfg_md_reset = QPushButton("Auto")
        self._cfg_md_reset.setFixedWidth(56)
        self._cfg_md_reset.setToolTip(
            "Restore Model Display defaults:\n"
            " • Background Color → White\n"
            " • Phantom Color → off (each part keeps its own color)\n"
            " • Edge Color → Auto (theme-based)"
        )
        self._cfg_md_reset.clicked.connect(self._on_reset_model_display)
        phantom_color_row.addWidget(self._cfg_md_reset)
        phantom_color_row.addStretch(1)
        cfg_lay.addLayout(phantom_color_row)

        cfg_lay.addSpacing(8)

        # ── Icon and Text ───────────────────────────────────────────────
        self._cfg_icon_text_check = QCheckBox("Icon and Text")
        self._cfg_icon_text_check.setToolTip(
            "Show button labels under their icons in the ribbon toolbars"
        )
        self._cfg_icon_text_check.setChecked(self._icon_text_enabled)
        self._cfg_icon_text_check.toggled.connect(self._on_icon_text_toggled)
        cfg_lay.addWidget(self._cfg_icon_text_check)

        # ── Auto-Zoom ───────────────────────────────────────────────────
        self._cfg_zoom_item_check = QCheckBox("Auto-Zoom")
        self._cfg_zoom_item_check.setToolTip(
            "Auto-fit the view to the selected part(s) whenever the\n"
            "navigator selection changes. Camera orientation is kept;\n"
            "only the framing changes."
        )
        self._cfg_zoom_item_check.setChecked(self._zoom_item_enabled)
        self._cfg_zoom_item_check.toggled.connect(self._on_zoom_item_toggled)
        cfg_lay.addWidget(self._cfg_zoom_item_check)

        # ── Hide cut edges (Cut Plane tool) ─────────────────────────────
        self._cfg_hide_cut_edges_check = QCheckBox("Hide cut edges")
        self._cfg_hide_cut_edges_check.setToolTip(
            "While the Cut Plane tool is active, hide wireframe edges of the "
            "clipped surface so the cut reads as a clean silhouette."
        )
        self._cfg_hide_cut_edges_check.setChecked(self._hide_cut_edges)
        self._cfg_hide_cut_edges_check.toggled.connect(self._on_hide_cut_edges_toggled)
        cfg_lay.addWidget(self._cfg_hide_cut_edges_check)

        # ── Close cut caps (Cut Plane tool) ─────────────────────────────
        self._cfg_close_cut_caps_check = QCheckBox("Close cut caps")
        self._cfg_close_cut_caps_check.setToolTip(
            "Regenerate a closed cross-section cap per part when the cut "
            "plane is released. Each cap takes the colour of its part. "
            "Updated only on mouse-release for performance — drags stay "
            "interactive. Works best on solid meshes; open shells may have "
            "no cap if the intersection is not a closed loop."
        )
        self._cfg_close_cut_caps_check.setChecked(self._close_cut_caps)
        self._cfg_close_cut_caps_check.toggled.connect(self._on_close_cut_caps_toggled)
        cfg_lay.addWidget(self._cfg_close_cut_caps_check)

        # ── Highlight cut profile (Cut Plane tool) ──────────────────────
        self._cfg_highlight_cut_caps_check = QCheckBox("Highlight cut profile")
        self._cfg_highlight_cut_caps_check.setToolTip(
            "Paint each cross-section cap in a distinct highlight colour "
            "instead of the part colour, so the cut profile reads clearly. "
            "Only affects caps already generated by 'Close cut caps' or the "
            "'Slice only' view."
        )
        self._cfg_highlight_cut_caps_check.setChecked(self._highlight_cut_caps)
        self._cfg_highlight_cut_caps_check.toggled.connect(
            self._on_highlight_cut_caps_toggled
        )
        cfg_lay.addWidget(self._cfg_highlight_cut_caps_check)

        # ── Show cut plane widget (Cut Plane tool) ──────────────────────
        self._cfg_show_cut_widget_check = QCheckBox("Show cut plane widget")
        self._cfg_show_cut_widget_check.setToolTip(
            "Show or hide the visual representation of the cut plane "
            "(handle, normal arrow, outline). Hiding it does NOT disable "
            "the clipping — only the on-screen widget visuals are removed, "
            "useful to inspect the clipped model without the widget in the "
            "way. Re-enable it to move the plane again."
        )
        self._cfg_show_cut_widget_check.setChecked(self._cut_widget_visible)
        self._cfg_show_cut_widget_check.toggled.connect(self._on_cut_widget_visible_toggled)
        cfg_lay.addWidget(self._cfg_show_cut_widget_check)

        # ── Snap selection (Tools pickers) ──────────────────────────────
        self._cfg_snap_selection_check = QCheckBox("Snap selection")
        self._cfg_snap_selection_check.setToolTip(
            "When checked, the Tools pickers (Pick Node, Measure, Cut Plane "
            "3-Points) prefer snap targets over raw nodes: feature vertices, "
            "midpoints of feature edges, and centres of boundary loops "
            "(holes). A click within ~15 px of a snap target uses that "
            "target; otherwise it falls back to the nearest node."
        )
        self._cfg_snap_selection_check.setChecked(self._snap_enabled)
        self._cfg_snap_selection_check.toggled.connect(self._on_snap_selection_toggled)
        cfg_lay.addWidget(self._cfg_snap_selection_check)

        # ── Datum grid spacing ──────────────────────────────────────────
        grid_sp_row = QHBoxLayout()
        grid_sp_row.setContentsMargins(0, 0, 0, 0)
        grid_sp_row.setSpacing(6)
        grid_sp_row.addWidget(QLabel("Datum grid spacing:"))
        self._cfg_datum_grid_spacing = QDoubleSpinBox()
        self._cfg_datum_grid_spacing.setRange(0.0, 1.0e9)
        self._cfg_datum_grid_spacing.setDecimals(3)
        self._cfg_datum_grid_spacing.setSingleStep(1.0)
        self._cfg_datum_grid_spacing.setValue(self._datum_grid_spacing)
        self._cfg_datum_grid_spacing.setSpecialValueText("Auto")  # shown at 0
        self._cfg_datum_grid_spacing.setFixedWidth(90)
        self._cfg_datum_grid_spacing.setToolTip(
            "Cell size (in model units) of the datum grid planes.\n"
            "0 = Auto (10 divisions across the grid). Applies immediately "
            "when the grid planes are visible."
        )
        self._cfg_datum_grid_spacing.valueChanged.connect(
            self._on_datum_grid_spacing_changed
        )
        grid_sp_row.addWidget(self._cfg_datum_grid_spacing)
        grid_sp_row.addStretch(1)
        cfg_lay.addLayout(grid_sp_row)

        # ── Datum grid opacity ──────────────────────────────────────────
        grid_op_row = QHBoxLayout()
        grid_op_row.setContentsMargins(0, 0, 0, 0)
        grid_op_row.setSpacing(6)
        grid_op_row.addWidget(QLabel("Datum grid opacity:"))
        self._cfg_datum_grid_opacity = QSpinBox()
        self._cfg_datum_grid_opacity.setRange(0, 100)
        self._cfg_datum_grid_opacity.setSingleStep(5)
        self._cfg_datum_grid_opacity.setSuffix(" %")
        self._cfg_datum_grid_opacity.setValue(int(round(self._datum_grid_opacity * 100)))
        self._cfg_datum_grid_opacity.setFixedWidth(90)
        self._cfg_datum_grid_opacity.setToolTip(
            "Opacity of the datum grid planes (0–100 %). Applies immediately "
            "when the grid planes are visible."
        )
        self._cfg_datum_grid_opacity.valueChanged.connect(
            self._on_datum_grid_opacity_changed
        )
        grid_op_row.addWidget(self._cfg_datum_grid_opacity)
        grid_op_row.addStretch(1)
        cfg_lay.addLayout(grid_op_row)

        cfg_lay.addSpacing(8)

        # ── Model Display: custom colors ────────────────────────────────
        _md_header = QLabel("Model Display")
        _md_font = _md_header.font()
        _md_font.setBold(True)
        _md_header.setFont(_md_font)
        cfg_lay.addWidget(_md_header)

        # Background Color row
        bg_row = QHBoxLayout()
        bg_row.setContentsMargins(20, 0, 0, 0)
        bg_row.setSpacing(8)
        bg_row.addWidget(QLabel("Background Color:"))
        self._cfg_bg_swatch = self._make_color_swatch_btn(self._bg_swatch_initial_rgb())
        self._cfg_bg_swatch.setToolTip("Pick a custom background color")
        self._cfg_bg_swatch.clicked.connect(self._on_pick_bg_color)
        bg_row.addWidget(self._cfg_bg_swatch)
        bg_row.addStretch(1)
        cfg_lay.addLayout(bg_row)

        # Edge Color row
        edge_row = QHBoxLayout()
        edge_row.setContentsMargins(20, 0, 0, 0)
        edge_row.setSpacing(8)
        edge_row.addWidget(QLabel("Edge Color:"))
        self._cfg_edge_swatch = self._make_color_swatch_btn((0.0, 0.0, 0.0))
        self._cfg_edge_swatch.setToolTip("Pick a custom edge color for parts")
        self._cfg_edge_swatch.clicked.connect(self._on_pick_edge_color)
        edge_row.addWidget(self._cfg_edge_swatch)
        _edge_reset = QPushButton("Auto")
        _edge_reset.setToolTip("Reset edge color to follow the theme (white on dark / black on light)")
        _edge_reset.setFixedWidth(56)
        _edge_reset.clicked.connect(self._on_reset_edge_color)
        edge_row.addWidget(_edge_reset)
        edge_row.addStretch(1)
        cfg_lay.addLayout(edge_row)

        cfg_lay.addSpacing(8)

        _btn_cache = QPushButton("Clear Cache")
        _btn_cache.setToolTip("Delete cached VTK data for this file")
        _btn_cache.clicked.connect(self._action_clear_cache)
        cfg_lay.addWidget(_btn_cache)
        _btn_about = QPushButton("About")
        _btn_about.setToolTip("About 3D Viewer 2.0")
        _btn_about.clicked.connect(self._action_about)
        cfg_lay.addWidget(_btn_about)
        cfg_lay.addStretch(1)
        lay3.addWidget(cfg_inner)
        tabs.addTab(w3, "Config")

        self._left_tabs = tabs
        tabs.currentChanged.connect(self._on_left_tab_changed)
        # Open on the Navigator tab — it's the primary surface for picking
        # parts and seeing properties, so users land there directly. The
        # currentChanged signal syncs the activity-bar buttons.
        tabs.setCurrentIndex(1)
        return tabs

    # ── Viewport area ─────────────────────────────────────────────────────

    def _build_viewport_area(self) -> QWidget:
        container = QWidget()
        container.setMinimumWidth(300)
        lay = QVBoxLayout(container)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self._viewport_placeholder = QLabel(
            "3D Viewport\n\n"
            "Open a .k file via  File › Open\n"
            "or double-click a file in the  Files  panel"
        )
        self._viewport_placeholder.setObjectName("viewport_placeholder")
        self._viewport_placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._viewport_placeholder.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        lay.addWidget(self._viewport_placeholder)

        self._loading_overlay = QWidget()
        self._loading_overlay.setObjectName("loading_overlay")
        lo_lay = QVBoxLayout(self._loading_overlay)
        lo_lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._loading_label = QLabel("Loading model…")
        self._loading_label.setObjectName("loading_label")
        self._loading_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lo_lay.addWidget(self._loading_label)
        self._loading_bar = QProgressBar()
        self._loading_bar.setRange(0, 0)
        self._loading_bar.setFixedWidth(320)
        lo_lay.addWidget(self._loading_bar, alignment=Qt.AlignmentFlag.AlignCenter)
        self._loading_overlay.hide()
        lay.addWidget(self._loading_overlay)

        self._viewport_lay = lay
        self._viewport_container = container
        return container

    # ── Right panel ───────────────────────────────────────────────────────

    def _build_right_panel(self) -> QFrame:
        frame = QFrame()
        frame.setObjectName("props_panel")
        frame.setMinimumWidth(150)
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)
        lay.addWidget(_panel_header("Properties"))
        self._props_label = QLabel(
            "Select a part or element\nin the navigator or viewport\nto view properties."
        )
        self._props_label.setObjectName("props_content")
        self._props_label.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        self._props_label.setWordWrap(True)

        # Wrap the label in a QScrollArea so a vertical scrollbar appears
        # automatically when the properties content (many selected parts)
        # exceeds the panel height. Horizontal scroll stays off because
        # _resize_props_panel_to_fit() already grows the panel width to fit
        # the longest line (capped at 50% of the dialog).
        self._props_scroll = QScrollArea()
        self._props_scroll.setObjectName("props_scroll")
        self._props_scroll.setWidgetResizable(True)
        self._props_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self._props_scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff
        )
        self._props_scroll.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self._props_scroll.setStyleSheet(
            "QScrollArea, QScrollArea > QWidget > QWidget { background: transparent; }"
        )
        self._props_scroll.setWidget(self._props_label)
        lay.addWidget(self._props_scroll, 1)
        return frame

    def _populate_files_list(self):
        """Populate the Files tab with .k files from the project directory."""
        self._files_list.clear()
        if self._file_path is None:
            item = QListWidgetItem("(no project file loaded)")
            item.setForeground(QColor(_CLR_TEXT_DIM))
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self._files_list.addItem(item)
            return

        folder = self._file_path.parent
        try:
            k_files = sorted(
                p for p in folder.iterdir()
                if p.suffix.lower() in (".k", ".key", ".dyn") and p.is_file()
            )
        except Exception:
            k_files = []

        if not k_files:
            item = QListWidgetItem("(no .k files found)")
            item.setForeground(QColor(_CLR_TEXT_DIM))
            item.setFlags(Qt.ItemFlag.NoItemFlags)
            self._files_list.addItem(item)
            return

        for p in k_files:
            item = QListWidgetItem(p.name)
            item.setData(Qt.ItemDataRole.UserRole, p)
            if p == self._file_path:
                item.setForeground(QColor(_CLR_ACCENT))
                font = item.font()
                font.setBold(True)
                item.setFont(font)
            self._files_list.addItem(item)

    def _on_file_double_clicked(self, item: QListWidgetItem):
        path: Path | None = item.data(Qt.ItemDataRole.UserRole)
        if path and path.is_file():
            self._file_path = path
            self.setWindowTitle(f"3D Viewer 2.0  —  {path.name}")
            self._populate_files_list()
            self._start_load(path)

    # =========================================================================
    #  Loading & VTK lifecycle
    # =========================================================================

    def _ensure_plotter(self):
        if self.plotter is not None:
            return
        try:
            from pyvistaqt import QtInteractor
        except ImportError as exc:
            QMessageBox.critical(self, "3D Viewer",
                                 f"pyvistaqt is required for the 3D viewport.\n{exc}")
            return
        self.plotter = QtInteractor(parent=self._viewport_container)
        self._viewport_lay.insertWidget(0, self.plotter, stretch=1)
        self._init_view_cube()

    def _init_view_cube(self) -> None:
        """Add a CATIA-style labeled view cube in the upper-right corner.

        Uses a ``vtkAnnotatedCubeActor`` in an overlay ``vtkRenderer`` whose
        camera is kept in sync with the main camera (so the cube always shows
        the current view orientation). Clicking on a face aligns the main
        camera with that orthogonal direction.
        """
        if self.plotter is None or self._view_cube_renderer is not None:
            return
        try:
            import vtk

            cube = vtk.vtkAnnotatedCubeActor()
            # Face labels follow the same convention as the View-tab presets,
            # where pyvista view_vector(v) places the camera at focal + v:
            #   +X (camera at +X) → "Left",  -X → "Right"
            #   +Y (camera at +Y) → "Front", -Y → "Back"
            #   +Z (camera at +Z) → "Top",   -Z → "Bottom"
            cube.SetXPlusFaceText("Left")
            cube.SetXMinusFaceText("Right")
            cube.SetYPlusFaceText("Front")
            cube.SetYMinusFaceText("Back")
            cube.SetZPlusFaceText("Top")
            cube.SetZMinusFaceText("Bottom")
            # Small scale so 6-char words like "Bottom" fit inside the face
            cube.SetFaceTextScale(0.20)
            cube.GetCubeProperty().SetColor(0.88, 0.88, 0.88)
            # Solid black text: fill + outline both black
            cube.GetTextEdgesProperty().SetColor(0.0, 0.0, 0.0)
            cube.GetTextEdgesProperty().SetLineWidth(1.5)
            # In vtkAnnotatedCubeActor the per-face *Property controls the
            # TEXT FILL on that face, not the cube face itself. Set to black.
            for text_fill_prop in (
                cube.GetXPlusFaceProperty(),
                cube.GetXMinusFaceProperty(),
                cube.GetYPlusFaceProperty(),
                cube.GetYMinusFaceProperty(),
                cube.GetZPlusFaceProperty(),
                cube.GetZMinusFaceProperty(),
            ):
                text_fill_prop.SetColor(0.0, 0.0, 0.0)
                text_fill_prop.SetInterpolationToFlat()

            overlay = vtk.vtkRenderer()
            overlay.SetViewport(0.87, 0.84, 0.99, 0.99)
            overlay.SetLayer(1)
            overlay.InteractiveOff()
            overlay.AddActor(cube)
            overlay.SetActiveCamera(vtk.vtkCamera())
            overlay.GetActiveCamera().SetFocalPoint(0.0, 0.0, 0.0)
            overlay.GetActiveCamera().SetViewUp(0.0, 0.0, 1.0)
            overlay.GetActiveCamera().SetPosition(3.0, 3.0, 3.0)
            overlay.ResetCamera()

            rw = self.plotter.render_window
            n_layers = max(2, rw.GetNumberOfLayers())
            rw.SetNumberOfLayers(n_layers)
            rw.AddRenderer(overlay)

            self._view_cube_actor = cube
            self._view_cube_renderer = overlay

            # Keep cube camera direction synced with main camera direction
            try:
                main_cam = self.plotter.camera
                self._view_cube_cam_obs_id = main_cam.AddObserver(
                    "ModifiedEvent", self._sync_view_cube_camera
                )
                self._sync_view_cube_camera(main_cam, None)
            except Exception:
                logger.debug("View cube camera sync setup failed", exc_info=True)

            # Click handler: detect clicks within the cube viewport and
            # rotate the main camera to the picked face's normal view.
            try:
                vtk_iren = self._vtk_interactor()
                if vtk_iren is not None:
                    self._view_cube_obs_id = vtk_iren.AddObserver(
                        "LeftButtonPressEvent", self._on_view_cube_click, 0.5
                    )
            except Exception:
                logger.debug("View cube click observer setup failed", exc_info=True)
        except Exception:
            logger.debug("Failed to init annotated view cube", exc_info=True)
            self._view_cube_actor = None
            self._view_cube_renderer = None

    def _sync_view_cube_camera(self, _caller, _event) -> None:
        """Match the overlay camera's direction with the main camera so the
        cube visually reflects the current model orientation."""
        if self._view_cube_renderer is None or self.plotter is None:
            return
        try:
            import numpy as np
            main_cam = self.plotter.camera
            ovl_cam = self._view_cube_renderer.GetActiveCamera()
            fp = np.asarray(main_cam.GetFocalPoint(), dtype=float)
            pos = np.asarray(main_cam.GetPosition(), dtype=float)
            direction = pos - fp
            n = float(np.linalg.norm(direction))
            if n < 1e-9:
                return
            direction = direction / n
            ovl_cam.SetFocalPoint(0.0, 0.0, 0.0)
            ovl_cam.SetPosition(*(direction * 4.0))
            ovl_cam.SetViewUp(*main_cam.GetViewUp())
            self._view_cube_renderer.ResetCameraClippingRange()
        except Exception:
            logger.debug("View cube camera sync failed", exc_info=True)

    def _on_view_cube_click(self, caller, _event) -> None:
        """Left click on the cube → orient the main camera to that face."""
        if self._view_cube_renderer is None or self.plotter is None:
            return
        try:
            x, y = caller.GetEventPosition()
            rw = self.plotter.render_window
            wsx, wsy = rw.GetSize()
            vp = self._view_cube_renderer.GetViewport()
            vx1 = vp[0] * wsx
            vy1 = vp[1] * wsy
            vx2 = vp[2] * wsx
            vy2 = vp[3] * wsy
            if not (vx1 <= x <= vx2 and vy1 <= y <= vy2):
                return  # click was outside the cube area
            # Suppress the part-selection that would otherwise fire on the
            # matching mouse release: clear the Qt click filter's stored
            # press position so it sees "no click registered" on release.
            flt = getattr(self, "_viewport_click_filter", None)
            if flt is not None:
                try:
                    flt._press_pos = None
                except Exception:
                    pass
            import vtk
            picker = vtk.vtkPropPicker()
            if not picker.Pick(x, y, 0, self._view_cube_renderer):
                return
            pos = picker.GetPickPosition()
            ax = abs(pos[0]); ay = abs(pos[1]); az = abs(pos[2])
            # Map the picked cube face to its label, matching the face texts
            # set in _init_view_cube (+X="Left", +Y="Front", +Z="Top").
            if ax >= ay and ax >= az:
                face = "left" if pos[0] > 0 else "right"
            elif ay >= ax and ay >= az:
                face = "front" if pos[1] > 0 else "back"
            else:
                face = "top" if pos[2] > 0 else "bottom"
            self._apply_view_cube_face(face)
        except Exception:
            logger.debug("View cube click handler failed", exc_info=True)

    _FACE_VIEW_VECTORS = {
        "right":  ((-1, 0, 0), (0, 0, 1)),
        "left":   (( 1, 0, 0), (0, 0, 1)),
        "back":   (( 0,-1, 0), (0, 0, 1)),
        "front":  (( 0, 1, 0), (0, 0, 1)),
        "top":    (( 0, 0, 1), (0, 1, 0)),
        "bottom": (( 0, 0,-1), (0, 1, 0)),
    }

    def _apply_view_cube_face(self, face: str) -> None:
        """Map a clicked cube face name to the corresponding orthogonal view.
        Uses a short animated transition (≈180 ms) instead of jumping."""
        if self.plotter is None:
            return
        vec = self._FACE_VIEW_VECTORS.get(face)
        if vec is None:
            return
        look_vec, up_vec = vec
        self._animate_camera_to_view(look_vec, up_vec, duration_ms=180)
        self._status.showMessage(f"View: {face}")

    def _animate_camera_to_view(
        self, look_vec, up_vec, duration_ms: int = 180
    ) -> None:
        """Smoothly transition the main camera to look along ``look_vec`` with
        the given ``up_vec``. Distance to the focal point is preserved so the
        framing of the model stays the same. If an animation is already in
        progress it is replaced — the new one starts from the current
        (mid-animation) camera state."""
        if self.plotter is None:
            return
        try:
            import vtk
            import numpy as np
            import time as _time
        except Exception:
            return

        self._cancel_camera_animation()

        # Snapshot source state (deep copy so source stays put as the live
        # camera mutates during the animation).
        src_cam = vtk.vtkCamera()
        src_cam.DeepCopy(self.plotter.camera)

        # Build target state: same focal + same distance, new direction.
        focal = self.plotter.camera.GetFocalPoint()
        pos = self.plotter.camera.GetPosition()
        dist = float(np.linalg.norm(np.subtract(pos, focal)))
        if dist < 1e-9:
            dist = 1.0
        look = np.asarray(look_vec, dtype=float)
        ln = float(np.linalg.norm(look))
        if ln < 1e-9:
            return
        look = look / ln
        # Match pyvista's view_vector convention: camera sits at focal + vector
        # (NOT focal - vector), so the cube faces and View-tab presets agree.
        new_pos = (
            float(focal[0] + look[0] * dist),
            float(focal[1] + look[1] * dist),
            float(focal[2] + look[2] * dist),
        )
        tgt_cam = vtk.vtkCamera()
        tgt_cam.SetPosition(*new_pos)
        tgt_cam.SetFocalPoint(*focal)
        tgt_cam.SetViewUp(*up_vec)
        tgt_cam.SetParallelScale(self.plotter.camera.GetParallelScale())
        tgt_cam.SetViewAngle(self.plotter.camera.GetViewAngle())
        tgt_cam.SetClippingRange(*self.plotter.camera.GetClippingRange())

        interp = vtk.vtkCameraInterpolator()
        interp.AddCamera(0.0, src_cam)
        interp.AddCamera(1.0, tgt_cam)

        self._cam_anim_interp = interp
        self._cam_anim_dur_s = max(0.05, duration_ms / 1000.0)
        self._cam_anim_t0 = _time.perf_counter()

        self._cam_anim_timer = QTimer(self)
        self._cam_anim_timer.setInterval(16)  # ~60 fps
        self._cam_anim_timer.timeout.connect(self._cam_anim_tick)
        self._cam_anim_timer.start()

    def _cam_anim_tick(self) -> None:
        if self._cam_anim_interp is None or self.plotter is None:
            self._cancel_camera_animation()
            return
        import time as _time
        t = (_time.perf_counter() - self._cam_anim_t0) / self._cam_anim_dur_s
        if t >= 1.0:
            t = 1.0
        try:
            import vtk
            # Linear camera interpolation between antipodal views (e.g.
            # Top↔Bottom) momentarily makes the view-up parallel to the
            # view direction. VTK auto-fixes the up vector and prints a
            # warning. Silence those warnings for the brief animation
            # window; warnings resume immediately after.
            vtk.vtkObject.GlobalWarningDisplayOff()
            try:
                self._cam_anim_interp.InterpolateCamera(t, self.plotter.camera)
                self.plotter.render()
            finally:
                vtk.vtkObject.GlobalWarningDisplayOn()
        except Exception:
            self._cancel_camera_animation()
            return
        if t >= 1.0:
            self._cancel_camera_animation()

    def _cancel_camera_animation(self) -> None:
        if self._cam_anim_timer is not None:
            try:
                self._cam_anim_timer.stop()
            except Exception:
                pass
            self._cam_anim_timer = None
        self._cam_anim_interp = None

    def _show_loading(self, filename: str):
        self._loading_label.setText(f"Loading  {filename}…")
        self._viewport_placeholder.hide()
        if self.plotter is not None:
            self.plotter.hide()
        self._loading_overlay.show()
        self._status.showMessage(f"Parsing {filename}…")

    def _hide_loading(self):
        self._loading_overlay.hide()
        if self.plotter is not None:
            self.plotter.show()

    def _start_load(self, path: Path):
        if self._load_worker is not None:
            try:
                self._load_worker.finished.disconnect()
            except RuntimeError:
                pass
            try:
                self._load_worker.geometry_ready.disconnect()
            except RuntimeError:
                pass
            self._load_worker.quit()
            self._load_worker.wait(2000)
        self._show_loading(path.name)
        from ui.viewer_v2_loader import LoadWorker
        self._load_worker = LoadWorker(path)
        self._load_worker.geometry_ready.connect(self._on_geometry_ready)
        self._load_worker.finished.connect(self._on_loaded)
        self._load_worker.start()

    def _on_geometry_ready(self, polydata, part_names):
        """Render the model as soon as polydata is ready (entities arrive later)."""
        self._hide_loading()
        self._polydata         = polydata
        # Snap targets depend on the polydata; force a rebuild on next request.
        self._invalidate_snap_cache()
        # Normalize keys to plain Python int. The loader may produce np.int32
        # keys (from element-derived part_ids) and JSON cache may produce str
        # keys; both must match the int(pid) lookups used elsewhere.
        try:
            self._part_names = {int(k): v for k, v in (part_names or {}).items()}
        except Exception:
            self._part_names = dict(part_names or {})
        self._keyword_entities = {}
        if polydata is not None:
            has_parts = "part_ids" in polydata.cell_data
            self._n_parts   = len(set(polydata.cell_data["part_ids"])) if has_parts else 0
            self._has_parts = has_parts
        else:
            self._has_parts = False
            self._n_parts   = 0
        self._ensure_plotter()
        if self.plotter is None:
            return
        self.plotter.clear()
        self._actors.clear()
        self._part_actors.clear()
        self._part_polydata.clear()
        self._per_part_style.clear()
        self._per_part_fx.clear()
        self._per_part_mesh.clear()
        # Reset material highlighting state for the new model.
        self._materials = {}
        self._part_to_mid = {}
        self._material_selected_mids = set()
        self._material_checked_mids = set()
        self._part_user_visible = {}
        self._pre_dim_opacity = {}
        self._pre_dim_color = {}
        self._material_fe_actors = {}  # actors are dropped by plotter.clear() above
        self._style_fe_actors = {}     # ditto
        self._wire_overlay_actor = None  # ditto
        self._remove_all_entity_actors()
        self._remove_highlight_edges()
        self._silhouette_actor    = None
        if polydata is not None:
            self._add_model_mesh()
            self._part_user_visible = {pid: True for pid in self._part_actors}
            # Default style is Surface+Edges → ensure the feature-edge overlay
            # is present from the start. (Actor element-edges already on via
            # show_edges=True in _add_model_mesh.)
            if self._current_style != "Surface":
                self._rebuild_wire_overlay(
                    as_points=(self._current_style == "Points")
                )
            self._update_status()
        else:
            self.plotter.set_background(self._current_bg)
            self._setup_axes()
            self._status.showMessage("No geometry in file")
        self._rebuild_nav_tree()

    def _on_loaded(self, polydata, part_names, kw_entities, error):
        """Final emission: SET entities are now ready; refresh the nav tree."""
        self._load_worker = None
        self._hide_loading()
        if error:
            self._status.showMessage(f"Error: {error}")
            QMessageBox.critical(self, "Load error", error)
            return
        # Geometry was already rendered via _on_geometry_ready; just merge entities.
        if self._polydata is None and polydata is not None:
            self._on_geometry_ready(polydata, part_names)
        else:
            # The geometry signal fires before walk_materials runs, so headings
            # and *INCLUDE_TRANSFORM titles captured from .k files only land in
            # the *finished* part_names dict. The loader resolves the final
            # name per PID (heading vs transform title) — adopt its decision
            # wholesale for any PID present, so transform-title overrides take
            # effect even when PyDyna already supplied a part heading.
            try:
                refreshed = {int(k): v for k, v in (part_names or {}).items()}
            except Exception:
                refreshed = dict(part_names or {})
            for pid, name in refreshed.items():
                if name:
                    self._part_names[pid] = name
        self._keyword_entities = kw_entities or {}
        # Real deck topology counts (elements/nodes per PID from the *ELEMENT* tables).
        _topo = self._keyword_entities.get("__topology__") or {}
        self._part_topology = _topo.get("per_pid") or {}
        # Materials come from the loader under "__materials__"; filter to those
        # actually referenced by at least one *PART and attach the PID set.
        self._consume_materials_payload(self._keyword_entities.get("__materials__"))
        self._rebuild_nav_tree()
        # Refresh properties panel so material info appears for any parts that
        # were already selected before the loader's final emission.
        try:
            self._update_properties_panel(self._get_selected_pids())
        except Exception:
            logger.debug("properties refresh after load failed", exc_info=True)

    # =========================================================================
    #  Mesh
    # =========================================================================

    def _get_part_colors(self) -> dict:
        try:
            from matplotlib import colormaps
            cmap = colormaps.get_cmap("tab20")
        except Exception:
            cmap = None
        part_ids = sorted(set(self._polydata.cell_data["part_ids"])) if self._has_parts else []
        colors: dict = {}
        for idx, pid in enumerate(part_ids):
            if cmap is not None:
                rgba = cmap(idx % cmap.N if hasattr(cmap, "N") else idx / max(len(part_ids), 1))
                colors[pid] = list(rgba[:3])
            else:
                colors[pid] = "steelblue"
        return colors

    def _add_model_mesh(self):
        import numpy as np

        pd = self._polydata
        self._part_actors.clear()
        self._part_polydata.clear()
        self._part_topology.clear()
        self._part_base_color.clear()
        try:
            self.plotter.enable_lightkit()
        except Exception:
            pass
        if self._has_parts:
            part_ids_arr = pd.cell_data["part_ids"]
            colors = self._get_part_colors()

            # O(N log N) vectorised index build — replaces the O(N×M) per-part
            # mask loop (N = total cells, M = number of parts).
            unique_pids = np.unique(part_ids_arr)
            sort_idx    = np.argsort(part_ids_arr, kind="stable")
            sorted_pids = part_ids_arr[sort_idx]
            lo = np.searchsorted(sorted_pids, unique_pids, side="left")
            hi = np.searchsorted(sorted_pids, unique_pids, side="right")

            # Switch VTK SMP to Sequential for the per-part extract_cells loop.
            # With STDThread active, VTK spawns os.cpu_count() threads per call.
            # On high-core-count machines (e.g. 12-core Xeon) this causes an
            # Access Violation in VTK's internal SMP partitioning for large
            # datasets — the process dies with no Python traceback.  Small models
            # (few cells/part) do not trigger the bug.  Sequential is correct here:
            # each call is already O(cells_in_part) and there is no parallelism to
            # exploit at the Python level.  STDThread is restored after the loop so
            # Cut Plane, feature edges and normals continue to use all cores.
            _vtk_smp_reset = False
            try:
                import vtk as _vtk_smp
                if _vtk_smp.vtkSMPTools.GetBackend() != "Sequential":
                    _vtk_smp.vtkSMPTools.SetBackend("Sequential")
                    _vtk_smp_reset = True
            except Exception:
                pass

            try:
                for i, pid in enumerate(sorted(unique_pids)):
                    sub = pd.extract_cells(sort_idx[lo[i]:hi[i]])
                    if sub.n_cells == 0:
                        continue
                    self._part_polydata[pid] = sub
                    name  = self._part_names.get(pid, f"Part {pid}")
                    color = colors.get(pid, "steelblue")
                    actor = self.plotter.add_mesh(
                        sub, color=color,
                        show_edges=True, edge_color="#606060", line_width=0.5,
                        label=f"{pid} {name}",
                    )
                    self._actors.append(actor)
                    self._part_actors[pid] = actor
                    if isinstance(color, (list, tuple)) and len(color) >= 3:
                        self._part_base_color[pid] = (
                            float(color[0]), float(color[1]), float(color[2])
                        )
                    else:
                        try:
                            c = actor.GetProperty().GetColor()
                            self._part_base_color[pid] = (float(c[0]), float(c[1]), float(c[2]))
                        except Exception:
                            pass
            finally:
                if _vtk_smp_reset:
                    try:
                        _vtk_smp.vtkSMPTools.SetBackend("STDThread")
                    except Exception:
                        pass
        else:
            actor = self.plotter.add_mesh(
                pd, show_edges=True, color="steelblue",
                edge_color="#606060", line_width=0.5,
            )
            self._actors.append(actor)
        self._setup_axes()
        self.plotter.set_background(self._current_bg)
        self._fit_camera_to_model()
        self._install_viewport_picker()

    def _install_viewport_picker(self):
        """Install a Qt-level event filter on the interactor widget so left
        clicks on the 3D viewport select the underlying part.

        Click-vs-drag is decided by comparing the press/release positions;
        if the cursor moved more than 3 px we treat it as a camera rotation
        and skip the pick (so PyVista's default interactor still rotates).
        """
        if self.plotter is None or not self._has_parts:
            return
        widget = getattr(self.plotter, "interactor", None)
        if widget is None:
            return
        prev = getattr(self, "_viewport_click_filter", None)
        if prev is not None:
            try:
                widget.removeEventFilter(prev)
            except Exception:
                pass
        flt = _ViewerClickFilter(self)
        widget.installEventFilter(flt)
        # Keep a reference on `self` so Qt doesn't garbage-collect it.
        self._viewport_click_filter = flt

    def _pick_pid_at(self, qt_x: int, qt_y: int) -> int | None:
        """Return the PID of the part under the given viewport coords, or None.

        Shared core of ``_do_viewport_pick`` and ``_do_viewport_deselect``.
        Translates Qt (top-left origin) to VTK display coords (bottom-left),
        runs a cell pick, and matches the hit actor against ``_part_actors``.
        """
        if self.plotter is None or not self._has_parts:
            return None
        widget = getattr(self.plotter, "interactor", None)
        if widget is None:
            return None
        h = widget.height()
        vtk_x = int(qt_x)
        vtk_y = int(h - qt_y)
        try:
            import vtk
            picker = vtk.vtkCellPicker()
            picker.SetTolerance(0.005)
            picker.Pick(vtk_x, vtk_y, 0, self.plotter.renderer)
            picked = picker.GetActor() or picker.GetProp3D()
        except Exception as exc:
            logger.debug("viewport pick failed: %s", exc)
            return None
        if picked is None:
            return None
        pid_hit = next(
            (pid for pid, a in self._part_actors.items() if a is picked),
            None,
        )
        if pid_hit is None:
            picked_addr = picked.__this__ if hasattr(picked, "__this__") else None
            for pid, a in self._part_actors.items():
                if a is None:
                    continue
                a_addr = a.__this__ if hasattr(a, "__this__") else None
                if a_addr is not None and a_addr == picked_addr:
                    pid_hit = pid
                    break
        return pid_hit

    def _do_viewport_pick(self, qt_x: int, qt_y: int, *, additive: bool) -> None:
        """Pick the actor under viewport coords and (additively) select it.

        Suppressed while Pick Node or Measure Distance mode is active — in
        those modes the left click is reserved for reading node coordinates /
        building a measurement and must not also isolate the clicked part.
        """
        if self._pick_node_observer_id is not None:
            return
        if self._measure_observer_id is not None:
            return
        pid_hit = self._pick_pid_at(qt_x, qt_y)
        if pid_hit is None:
            return
        self._select_pid_in_tree(pid_hit, additive=additive)

    def _do_viewport_deselect(self, qt_x: int, qt_y: int) -> None:
        """Pick the actor under viewport coords and remove it from selection.

        Bound to Ctrl+Right-Click in ``_ViewerClickFilter``. If the picked
        part isn't currently selected the call is a no-op — the navigator
        selection state is the single source of truth.
        """
        pid_hit = self._pick_pid_at(qt_x, qt_y)
        if pid_hit is None:
            return
        self._deselect_pid_in_tree(pid_hit)

    def _find_tree_leaf_for_pid(self, item, pid: int):
        d = item.data(0, Qt.ItemDataRole.UserRole)
        if isinstance(d, numbers.Integral) and int(d) == pid:
            return item
        for i in range(item.childCount()):
            r = self._find_tree_leaf_for_pid(item.child(i), pid)
            if r is not None:
                return r
        return None

    def _select_pid_in_tree(self, pid: int, additive: bool = False):
        root = self._nav_tree.topLevelItem(0)
        if root is None:
            return
        target = self._find_tree_leaf_for_pid(root, pid)
        if target is None:
            return
        if not additive:
            self._nav_tree.clearSelection()
        target.setSelected(True)
        self._nav_tree.setCurrentItem(target)
        self._nav_tree.scrollToItem(target)

    def _deselect_pid_in_tree(self, pid: int):
        """Remove a single PID from the navigator selection (others kept)."""
        root = self._nav_tree.topLevelItem(0)
        if root is None:
            return
        target = self._find_tree_leaf_for_pid(root, pid)
        if target is None or not target.isSelected():
            return
        target.setSelected(False)

    def _clear_tree_selection(self):
        if self._nav_tree.selectedItems():
            self._nav_tree.clearSelection()
            self._status.showMessage("Selection cleared", 2000)

    # ── Right-click popup on selected part (Isolate / Hide / Restore all) ──

    def _is_pid_in_selection(self, pid: int) -> bool:
        root = self._nav_tree.topLevelItem(0)
        if root is None:
            return False
        target = self._find_tree_leaf_for_pid(root, pid)
        return bool(target is not None and target.isSelected())

    def _selected_pids(self) -> set:
        """Return the set of FEM-part PIDs currently selected in the navigator."""
        pids: set = set()
        for it in self._nav_tree.selectedItems():
            data = it.data(0, Qt.ItemDataRole.UserRole)
            if isinstance(data, numbers.Integral):
                pids.add(int(data))
        return pids

    def _find_fem_parts_node(self):
        """Return the 'FEM Parts' container item in the navigator, or None."""
        root = self._nav_tree.topLevelItem(0)
        if root is None:
            return None
        for ci in range(root.childCount()):
            c = root.child(ci)
            if c.text(0) == "FEM Parts":
                return c
        return None

    def _has_hidden_parts(self) -> bool:
        """True if at least one FEM part is currently unchecked (hidden)."""
        fem = self._find_fem_parts_node()
        if fem is None:
            return False
        for i in range(fem.childCount()):
            it = fem.child(i)
            data = it.data(0, Qt.ItemDataRole.UserRole)
            if (
                isinstance(data, numbers.Integral)
                and it.checkState(0) == Qt.CheckState.Unchecked
            ):
                return True
        return False

    def _show_background_popup_menu(self, global_pos) -> None:
        """Right-click on empty viewport space → offer 'Restore all' when any
        part is hidden. This is the escape hatch for when EVERY part has been
        hidden and there is no visible part left to right-click."""
        if not self._has_hidden_parts():
            return
        menu = QMenu(self)
        act_restore = menu.addAction("Restore all")
        act_restore.triggered.connect(self._action_restore_all_parts)
        menu.exec(global_pos)

    def _show_part_popup_menu(self, pid: int, global_pos) -> None:
        """Context menu shown when the user right-clicks a selected part in
        the viewport. Actions operate on the WHOLE current selection (so a
        multi-selection is hidden/isolated together), falling back to the
        single right-clicked part when nothing else is selected.

          * Isolate     — keep only the selected parts visible, hide the rest
          * Hide        — hide all selected parts
          * Restore all — check all FEM parts and clear navigator selection
        """
        if pid is None:
            return
        pids = self._selected_pids()
        if int(pid) not in pids:
            pids.add(int(pid))
        if not pids:
            return

        n = len(pids)
        if n == 1:
            only = next(iter(pids))
            name = self._part_names.get(only, f"Part {only}")
            iso_label = f"Isolate '{name}'"
            hide_label = f"Hide '{name}'"
        else:
            iso_label = f"Isolate {n} parts"
            hide_label = f"Hide {n} parts"

        menu = QMenu(self)
        act_iso = menu.addAction(iso_label)
        act_hide = menu.addAction(hide_label)
        menu.addSeparator()
        act_restore = menu.addAction("Restore all")
        pids_snapshot = set(pids)
        act_iso.triggered.connect(lambda: self._action_isolate_pids(pids_snapshot))
        act_hide.triggered.connect(lambda: self._action_hide_pids(pids_snapshot))
        act_restore.triggered.connect(self._action_restore_all_parts)
        menu.exec(global_pos)

    def _action_isolate_pids(self, pids: set) -> None:
        """Keep only *pids* checked (visible); uncheck every other FEM part."""
        if not pids:
            return
        fem = self._find_fem_parts_node()
        if fem is None:
            return
        self._nav_tree.blockSignals(True)
        try:
            for i in range(fem.childCount()):
                it = fem.child(i)
                data = it.data(0, Qt.ItemDataRole.UserRole)
                if not isinstance(data, numbers.Integral):
                    continue
                state = (
                    Qt.CheckState.Checked if int(data) in pids
                    else Qt.CheckState.Unchecked
                )
                it.setCheckState(0, state)
        finally:
            self._nav_tree.blockSignals(False)
        self._sync_parts_from_tree()
        self._apply_material_highlight()
        self._refresh_global_wire_overlay()
        if self.plotter:
            self.plotter.render()
        if len(pids) == 1:
            only = next(iter(pids))
            msg = f"Isolated: {self._part_names.get(only, f'Part {only}')}"
        else:
            msg = f"Isolated {len(pids)} parts"
        self._status.showMessage(msg, 3000)

    def _action_hide_pids(self, pids: set) -> None:
        """Uncheck (hide) every part in *pids* and deselect them in the
        navigator. Camera framing is intentionally left untouched."""
        if not pids:
            return
        fem = self._find_fem_parts_node()
        if fem is None:
            return
        # Do NOT block signals here: letting setCheckState fire itemChanged
        # naturally guarantees the checkbox visually unchecks and the existing
        # handler updates _part_user_visible (proven single-item behaviour).
        for i in range(fem.childCount()):
            it = fem.child(i)
            data = it.data(0, Qt.ItemDataRole.UserRole)
            if not isinstance(data, numbers.Integral):
                continue
            if int(data) in pids:
                it.setCheckState(0, Qt.CheckState.Unchecked)
        # All selected parts are now hidden, so clear the navigator selection
        # in one shot. This fires _on_nav_selection_changed once, which clears
        # both the blue tree highlight and the orange selection-edge overlays.
        self._nav_tree.clearSelection()
        self._apply_material_highlight()
        self._refresh_global_wire_overlay()
        if self.plotter:
            self.plotter.render()
        if len(pids) == 1:
            only = next(iter(pids))
            msg = f"Hidden: {self._part_names.get(only, f'Part {only}')}"
        else:
            msg = f"Hidden {len(pids)} parts"
        self._status.showMessage(msg, 3000)

    def _action_restore_all_parts(self) -> None:
        """Check every FEM part and clear the navigator selection."""
        fem = self._find_fem_parts_node()
        if fem is None:
            return
        self._nav_tree.blockSignals(True)
        try:
            for i in range(fem.childCount()):
                it = fem.child(i)
                data = it.data(0, Qt.ItemDataRole.UserRole)
                if not isinstance(data, numbers.Integral):
                    continue
                it.setCheckState(0, Qt.CheckState.Checked)
        finally:
            self._nav_tree.blockSignals(False)
        self._sync_parts_from_tree()
        self._nav_tree.clearSelection()
        self._apply_material_highlight()
        self._refresh_global_wire_overlay()
        if self.plotter:
            self._fit_camera_to_model()
            self.plotter.render()
        self._status.showMessage("All parts restored", 3000)

    def _apply_style_to_actor(self, actor, style: str, mesh_on: bool | None = None):
        """Set the actor's representation given the render *style* and Mesh state.

        Element-detail visibility (per-cell edges / per-cell points) is driven
        by ``mesh_on``. Main "feature" edges are NOT drawn here — they live in
        a separate global overlay managed by ``_set_render_style``.

        Matrix (per actor):
          * Surface          + mesh-on  → Surface,   EdgeVisibility ON
          * Surface          + mesh-off → Surface,   EdgeVisibility OFF
          * Surface+Edges    + mesh-on  → Surface,   EdgeVisibility ON
          * Surface+Edges    + mesh-off → Surface,   EdgeVisibility OFF
          * Wireframe        + mesh-on  → Wireframe (actor visible)
          * Wireframe        + mesh-off → actor hidden (overlay supplies edges)
          * Points           + mesh-on  → Points     (actor visible)
          * Points           + mesh-off → actor hidden (overlay supplies points)

        Caller (``_apply_material_highlight``) is the single source of truth
        for ``actor.SetVisibility(...)`` — we only touch representation/edges
        here. Visibility is handled there based on the same matrix.
        """
        if actor is None:
            return
        if mesh_on is None:
            mesh_on = bool(getattr(self, "_mesh_visible", True))
        prop = actor.GetProperty()
        if style == "Wireframe":
            prop.SetRepresentationToWireframe()
            prop.EdgeVisibilityOff()
        elif style == "Points":
            prop.SetRepresentationToPoints()
            prop.SetPointSize(5)
            prop.EdgeVisibilityOff()
        else:
            # Surface or Surface+Edges: element edges follow the Mesh toggle.
            prop.SetRepresentationToSurface()
            if mesh_on:
                prop.EdgeVisibilityOn()
            else:
                prop.EdgeVisibilityOff()

    def _get_pydyna_polydata(self):
        """Return a clean PyDyna polydata for Wireframe edge extraction.

        Lazy-builds and caches it on first request. Returns ``None`` if
        PyDyna parsing fails (caller will fall back to the polydata that
        viewer_v2_loader already produced).
        """
        if self._pydyna_polydata is not None:
            print("[wire-diag] PyDyna polydata: cache HIT", flush=True)
            return self._pydyna_polydata
        if self._pydyna_polydata_failed:
            print("[wire-diag] PyDyna polydata: previous failure cached, skipping", flush=True)
            return None
        if self._file_path is None:
            print("[wire-diag] PyDyna polydata: no file path", flush=True)
            return None
        import time
        t0 = time.perf_counter()
        print(
            f"[wire-diag] PyDyna polydata: starting parse for "
            f"{self._file_path.name} ...",
            flush=True,
        )
        # Apply the same geometry-only pre-filter the legacy viewer uses.
        # PyDyna otherwise materialises *CONSTRAINED_* / *MAT_SPOTWELD /
        # *RIGID_BODY etc. as synthetic line cells, which leak into the
        # Wireframe overlay and produce per-element artefacts.
        from ui.model_viewer import _write_geometry_filtered_temp
        tmp_path = None
        try:
            tmp_path = _write_geometry_filtered_temp(self._file_path)
        except Exception as exc:
            print(
                f"[wire-diag] geometry pre-filter raised "
                f"{type(exc).__name__}: {exc} — falling back to raw file",
                flush=True,
            )
        parse_path = tmp_path if tmp_path is not None else self._file_path
        print(
            f"[wire-diag] parsing {'filtered temp' if tmp_path else 'raw file'}: "
            f"{parse_path}",
            flush=True,
        )
        try:
            import warnings
            from ansys.dyna.core import Deck
            from ansys.dyna.core.lib.deck_plotter import get_polydata

            deck = Deck()
            t_imp0 = time.perf_counter()
            deck.import_file(str(parse_path))
            t_imp = time.perf_counter() - t_imp0
            cwd = str(self._file_path.parent) or "."
            t_pd0 = time.perf_counter()
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                pd = get_polydata(deck, cwd=cwd)
            t_pd = time.perf_counter() - t_pd0
            self._pydyna_polydata = pd
            try:
                n_pts = int(pd.n_points)
                n_cells = int(pd.n_cells)
            except Exception:
                n_pts = n_cells = -1
            print(
                f"[wire-diag] PyDyna polydata: SUCCESS  "
                f"import={t_imp:.2f}s  get_polydata={t_pd:.2f}s  "
                f"total={time.perf_counter() - t0:.2f}s  "
                f"points={n_pts}  cells={n_cells}",
                flush=True,
            )
            return pd
        except Exception as exc:
            print(
                f"[wire-diag] PyDyna polydata: FAILED after "
                f"{time.perf_counter() - t0:.2f}s — {type(exc).__name__}: {exc}",
                flush=True,
            )
            logger.warning("PyDyna polydata regeneration failed: %s", exc, exc_info=True)
            self._pydyna_polydata_failed = True
            return None
        finally:
            if tmp_path is not None:
                try:
                    tmp_path.unlink(missing_ok=True)
                except Exception:
                    pass

    def _rebuild_wire_overlay(self, as_points: bool = False) -> None:
        """Add a single combined feature-edge overlay showing true part outlines.

        Uses ``self._polydata`` as loaded.

        When *as_points* is True, the overlay is rendered as points (one per
        feature-edge vertex) — used by the Points render style. Otherwise it
        is rendered as a thin wireframe — used by Wireframe and Surface+Edges.

        Key decisions:
        - 1D cells (BEAM/LINE) are filtered out: they are not polygon geometry
          and their per-segment edges would appear as dense artefacts.
        - ``feature_angle=89``: shows only near-90° sharp corners (box edges,
          plate bends) while filtering out spring/coil inter-element dihedral
          angles (typically < 60°).
        - ``boundary_edges=True``: shows the open perimeter of shell surfaces
          (plate rims, cylinder opening edges).
        - ``manifold_edges=False``: hides all interior shared polygon edges.
        """
        self._remove_wire_overlay()
        if self.plotter is None or self._polydata is None:
            return

        # extract_cells, extract_surface and extract_feature_edges all use
        # vtkSMPTools internally.  With STDThread active on a high-core-count
        # machine (e.g. 12-core Xeon), these calls crash on large datasets
        # (Access Violation in vtkSMPTools partitioning) — same root cause as
        # the crash in _add_model_mesh.  Switch to Sequential for the duration
        # of this function and restore STDThread once the overlay is built.
        _vtk_smp_reset_wo = False
        try:
            import vtk as _vtk_wo
            if _vtk_wo.vtkSMPTools.GetBackend() != "Sequential":
                _vtk_wo.vtkSMPTools.SetBackend("Sequential")
                _vtk_smp_reset_wo = True
        except Exception:
            pass

        try:
            import numpy as np
            import pyvista as pv

            pd = self._polydata

            # Restrict the overlay to parts whose checkbox is on. Unchecked
            # parts must vanish from the global edge overlay too, otherwise
            # their silhouette persists as a phantom wireframe.
            if self._has_parts and "part_ids" in pd.cell_data:
                visible_pids = {
                    pid for pid, vis in self._part_user_visible.items() if vis
                }
                # Phantom mode: when at least one part is selected, suppress
                # the feature edges of every non-selected part so the dimmed
                # silhouettes stop competing visually with the selection.
                # No-selection / Phantom off → behaves as before (all visible
                # parts contribute to the outline).
                if self._phantom_enabled:
                    sel = {int(p) for p in self._get_selected_pids()}
                    if sel:
                        visible_pids = visible_pids & sel
                if not visible_pids:
                    return
                part_ids_arr = pd.cell_data["part_ids"]
                mask = np.isin(part_ids_arr, list(visible_pids))
                if not mask.any():
                    return
                if not mask.all():
                    cell_ids = np.where(mask)[0]
                    pd = pd.extract_cells(cell_ids).extract_surface()

            # Filter out 1D cells (BEAM/LINE elements from PyDyna fallback).
            # PyVista PolyData stores line cells in .lines and polygon cells
            # in .faces — rebuilding from .faces alone drops all 1D cells.
            if isinstance(pd, pv.PolyData):
                raw_lines = pd.lines
                if len(raw_lines) > 0:
                    faces = pd.faces
                    if len(faces) == 0:
                        return  # only 1D elements — nothing to outline
                    pd = pv.PolyData(pd.points, faces)

            edges = pd.extract_feature_edges(
                boundary_edges=True,
                feature_edges=True,
                manifold_edges=False,
                non_manifold_edges=False,
                feature_angle=89,
            )
            if edges is not None and edges.n_points > 0:
                fe_color = "white" if self._theme_is_dark else "black"
                kw: dict = dict(
                    color=fe_color,
                    lighting=False,
                    pickable=False,
                    render=False,
                    reset_camera=False,
                    name="_wire_overlay_global",
                )
                if as_points:
                    kw.update(style="points", point_size=5,
                              render_points_as_spheres=True)
                else:
                    kw.update(style="wireframe", line_width=1.5)
                self._wire_overlay_actor = self.plotter.add_mesh(edges, **kw)
        except Exception as exc:
            logger.debug("wire overlay failed: %s", exc)
        finally:
            if _vtk_smp_reset_wo:
                try:
                    _vtk_wo.vtkSMPTools.SetBackend("STDThread")
                except Exception:
                    pass

    def _remove_wire_overlay(self) -> None:
        if self._wire_overlay_actor is not None and self.plotter is not None:
            try:
                self.plotter.remove_actor(self._wire_overlay_actor, render=False)
            except Exception:
                pass
            self._wire_overlay_actor = None


    def _nav_tree_placeholder(self):
        self._nav_tree.clear()
        item = QTreeWidgetItem(self._nav_tree, ["(No model loaded)"])
        item.setForeground(0, QColor(_CLR_TEXT_DIM))
        item.setFlags(Qt.ItemFlag.NoItemFlags)

    def _rebuild_nav_tree(self):
        tree = self._nav_tree
        tree.blockSignals(True)
        tree.clear()
        has_parts    = bool(self._part_actors)
        has_sets     = any(k != "__names__" for k in self._keyword_entities)
        has_materials = bool(self._materials)
        has_entities = has_sets or has_materials
        if not has_parts and not has_entities:
            self._nav_tree_placeholder()
            tree.blockSignals(False)
            return
        root_item = QTreeWidgetItem(tree, ["Assembly"])
        root_item.setFlags(root_item.flags()
                           | Qt.ItemFlag.ItemIsUserCheckable
                           | Qt.ItemFlag.ItemIsAutoTristate)
        root_item.setCheckState(0, Qt.CheckState.Checked)
        if has_parts:
            fem = QTreeWidgetItem(root_item, ["FEM Parts"])
            fem.setFlags(fem.flags()
                         | Qt.ItemFlag.ItemIsUserCheckable
                         | Qt.ItemFlag.ItemIsAutoTristate)
            fem.setCheckState(0, Qt.CheckState.Checked)
            for pid in sorted(self._part_actors):
                heading = (self._part_names.get(pid, "") or "").strip()
                label = f"PID {pid}: {heading}" if heading else f"PID {pid}"
                it = QTreeWidgetItem(fem, [label])
                it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                it.setCheckState(0, Qt.CheckState.Checked)
                it.setData(0, Qt.ItemDataRole.UserRole, pid)
        if has_entities:
            ent = QTreeWidgetItem(root_item, ["Keyword Entities"])
            ent.setFlags(ent.flags()
                         | Qt.ItemFlag.ItemIsUserCheckable
                         | Qt.ItemFlag.ItemIsAutoTristate)
            ent.setCheckState(0, Qt.CheckState.Unchecked)
            if has_sets:
                _CAT_ORDER  = ["SET_NODE", "SET_SHELL", "SET_SOLID", "SET_PART", "SET_SEGMENT"]
                _CAT_LABELS = {"SET_NODE": "Set Node", "SET_SHELL": "Set Shell",
                               "SET_SOLID": "Set Solid", "SET_PART": "Set Part",
                               "SET_SEGMENT": "Set Segment"}
                _MBR_LABELS = {"SET_NODE": "nodes", "SET_SHELL": "shells",
                               "SET_SOLID": "solids", "SET_PART": "parts",
                               "SET_SEGMENT": "segments"}
                entity_names = self._keyword_entities.get("__names__", {})
                for cat in _CAT_ORDER:
                    sids = self._keyword_entities.get(cat)
                    if not sids:
                        continue
                    cat_it = QTreeWidgetItem(ent, [_CAT_LABELS.get(cat, cat)])
                    cat_it.setFlags(cat_it.flags()
                                    | Qt.ItemFlag.ItemIsUserCheckable
                                    | Qt.ItemFlag.ItemIsAutoTristate)
                    cat_it.setCheckState(0, Qt.CheckState.Unchecked)
                    mlbl = _MBR_LABELS.get(cat, "members")
                    for sid in sorted(sids):
                        name = entity_names.get((cat, sid), "")
                        n    = len(sids[sid])
                        txt  = (f"SID {sid}: {name}  ({n} {mlbl})" if name
                                else f"SID {sid}  ({n} {mlbl})")
                        it = QTreeWidgetItem(cat_it, [txt])
                        it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                        it.setCheckState(0, Qt.CheckState.Unchecked)
                        it.setData(0, Qt.ItemDataRole.UserRole, (cat, sid))
            if has_materials:
                mat_it = QTreeWidgetItem(ent, ["Material"])
                mat_it.setFlags(mat_it.flags()
                                | Qt.ItemFlag.ItemIsUserCheckable
                                | Qt.ItemFlag.ItemIsAutoTristate)
                mat_it.setCheckState(0, Qt.CheckState.Unchecked)
                for mid in sorted(self._materials):
                    title = (self._materials[mid].get("title") or "").strip()
                    txt   = f"MID {mid}: {title}" if title else f"MID {mid}"
                    it = QTreeWidgetItem(mat_it, [txt])
                    it.setFlags(it.flags() | Qt.ItemFlag.ItemIsUserCheckable)
                    it.setCheckState(0, Qt.CheckState.Unchecked)
                    it.setData(0, Qt.ItemDataRole.UserRole, ("MATERIAL", int(mid)))
        tree.expandAll()
        tree.resizeColumnToContents(0)
        tree.blockSignals(False)
        self._autosize_left_panel()

    def _autosize_left_panel(self) -> None:
        """Resize the left panel so the widest visible navigator row fits.

        Measured from the tree's natural column-0 width plus indentation,
        frame and vertical-scrollbar reserve. Clamped to a sensible range
        so a single very long part name can't blow the layout.
        """
        spl = getattr(self, "_main_splitter", None)
        tree = getattr(self, "_nav_tree", None)
        if spl is None or tree is None:
            return
        if not getattr(self, "_left_panel_open", True):
            return
        try:
            col_w = tree.sizeHintForColumn(0)
        except Exception:
            return
        sb_w = 0
        try:
            sb = tree.verticalScrollBar()
            if sb is not None and sb.isVisible():
                sb_w = sb.sizeHint().width()
        except Exception:
            pass
        extras = tree.indentation() + 2 * tree.frameWidth() + sb_w + 16
        needed = col_w + extras
        win_w = self.width() or 1200
        target = max(_SPLIT_LEFT, min(needed, int(win_w * 0.45)))
        sizes = spl.sizes()
        if len(sizes) < 3:
            return
        total = sum(sizes)
        new_left = target
        new_right = sizes[2]
        new_center = max(200, total - new_left - new_right)
        spl.setSizes([new_left, new_center, new_right])
        self._left_panel_size = new_left

    def _resize_props_panel_to_fit(self) -> None:
        """Grow the right Properties panel so its longest line fits without wrap.

        Uses ``QTextDocument.idealWidth`` to measure the rich-text content at
        its natural (unwrapped) width, then resizes the splitter section.
        Capped at 50% of the dialog width so the viewport stays usable; never
        shrinks below the default _SPLIT_RIGHT.
        """
        spl = getattr(self, "_main_splitter", None)
        panel = getattr(self, "_right_panel", None)
        label = getattr(self, "_props_label", None)
        if spl is None or panel is None or label is None:
            return
        if not panel.isVisible():
            return
        try:
            from PySide6.QtGui import QTextDocument
            doc = QTextDocument()
            doc.setDefaultFont(label.font())
            if Qt.mightBeRichText(label.text()):
                doc.setHtml(label.text())
            else:
                doc.setPlainText(label.text())
            doc.setTextWidth(-1)
            content_w = int(doc.idealWidth())
        except Exception:
            content_w = label.sizeHint().width()
        # Add label padding (QSS sets 8 px) + frame border + a small margin.
        extras = 2 * panel.frameWidth() + 16 + 12
        needed = content_w + extras
        win_w = self.width() or 1200
        target = max(_SPLIT_RIGHT, min(needed, int(win_w * 0.5)))
        sizes = spl.sizes()
        if len(sizes) < 3 or sizes[2] >= target:
            return  # already wide enough — don't shrink the user's manual resize
        total = sum(sizes)
        new_right = target
        new_left = sizes[0]
        new_center = max(200, total - new_left - new_right)
        spl.setSizes([new_left, new_center, new_right])

    def _on_nav_item_checked(self, item, _col):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if isinstance(data, tuple) and len(data) == 2:
            cat, val = data
            if cat == "MATERIAL":
                checked = item.checkState(0) == Qt.CheckState.Checked
                if checked:
                    self._material_checked_mids.add(int(val))
                else:
                    self._material_checked_mids.discard(int(val))
                self._apply_material_highlight()
            else:
                self._toggle_entity_visibility(cat, val, item.checkState(0) == Qt.CheckState.Checked)
        elif isinstance(data, numbers.Integral):
            pid = int(data)
            self._part_user_visible[pid] = (
                item.checkState(0) == Qt.CheckState.Checked
            )
            self._refresh_global_wire_overlay()
            self._apply_material_highlight()
        else:
            self._sync_parts_from_tree()
            self._sync_entities_from_tree()
            self._refresh_global_wire_overlay()
            self._apply_material_highlight()
        if self.plotter:
            self.plotter.render()

    def _refresh_global_wire_overlay(self) -> None:
        """Rebuild the global feature-edge overlay if it's currently active.

        The overlay is built once from the full polydata, so toggling part
        visibility leaves stale edges behind. Rebuild it from only the
        checked parts whenever an FEM-Parts checkbox changes.
        """
        style = getattr(self, "_current_style", "Surface")
        if style == "Surface":
            return
        try:
            self._rebuild_wire_overlay(as_points=(style == "Points"))
        except Exception:
            logger.debug("wire overlay refresh failed", exc_info=True)

    def _sync_parts_from_tree(self):
        root = self._nav_tree.topLevelItem(0)
        if root is None:
            return
        for ci in range(root.childCount()):
            child = root.child(ci)
            if child.text(0) == "FEM Parts":
                for i in range(child.childCount()):
                    it  = child.child(i)
                    pid = it.data(0, Qt.ItemDataRole.UserRole)
                    if isinstance(pid, numbers.Integral):
                        self._part_user_visible[int(pid)] = (
                            it.checkState(0) == Qt.CheckState.Checked
                        )

    def _sync_entities_from_tree(self):
        root = self._nav_tree.topLevelItem(0)
        if root is None:
            return
        for ci in range(root.childCount()):
            child = root.child(ci)
            if child.text(0) == "Keyword Entities":
                self._sync_entity_group(child)
                break

    def _sync_entity_group(self, group):
        for ci in range(group.childCount()):
            ch   = group.child(ci)
            data = ch.data(0, Qt.ItemDataRole.UserRole)
            if isinstance(data, tuple) and len(data) == 2:
                cat, sid = data
                self._toggle_entity_visibility(cat, sid, ch.checkState(0) == Qt.CheckState.Checked)
            else:
                self._sync_entity_group(ch)

    def _on_nav_selection_changed(self):
        # Material preview: any selected MATERIAL items contribute their parts
        # to the live highlight set (transient — vanishes on deselection).
        sel_mids: set = set()
        for it in self._nav_tree.selectedItems():
            d = it.data(0, Qt.ItemDataRole.UserRole)
            if isinstance(d, tuple) and len(d) == 2 and d[0] == "MATERIAL":
                sel_mids.add(int(d[1]))
        if sel_mids != self._material_selected_mids:
            self._material_selected_mids = sel_mids
            self._apply_material_highlight()
        selected_pids = self._get_selected_pids()
        self._apply_selection_dim(selected_pids)
        for pid in list(self._highlighted_pids - set(selected_pids)):
            actor = self._highlight_fe_actors.pop(pid, None)
            if actor is not None:
                try:
                    self.plotter.remove_actor(actor)
                except Exception:
                    pass
            self._highlighted_pids.discard(pid)
        for pid in set(selected_pids) - self._highlighted_pids:
            sub = self._part_polydata.get(pid)
            if sub is None:
                continue
            try:
                edges = sub.extract_feature_edges(
                    boundary_edges=True, feature_edges=True,
                    manifold_edges=False, non_manifold_edges=True, feature_angle=30,
                )
                if edges.n_points > 0:
                    # reset_camera=False keeps PyVista from auto-fitting on
                    # actor add — would otherwise undo Zoom Item's framing.
                    actor = self.plotter.add_mesh(
                        edges, color="orange", style="wireframe",
                        line_width=4.0, label=f"_hl_{pid}",
                        reset_camera=False,
                    )
                    self._highlight_fe_actors[pid] = actor
                    self._highlighted_pids.add(pid)
            except Exception as exc:
                logger.debug("Highlight pid %s failed: %s", pid, exc)
        self._update_properties_panel(selected_pids)
        # Frame the selection AFTER every add_mesh / remove_actor has run so
        # no late-running PyVista reset_camera can undo it.
        self._zoom_to_selection_if_enabled(selected_pids)
        if self.plotter:
            self.plotter.render()

    def _restore_pre_dim_opacity(self) -> None:
        """Restore every part to its snapshot opacity and clear the snapshot."""
        if not self._pre_dim_opacity:
            return
        for pid, opa in self._pre_dim_opacity.items():
            actor = self._part_actors.get(pid)
            if actor is None:
                continue
            try:
                actor.GetProperty().SetOpacity(float(opa))
            except Exception:
                pass
        self._pre_dim_opacity.clear()

    def _restore_pre_dim_color(self) -> None:
        """Restore every part to its snapshot color and clear the snapshot.

        Snapshot is populated by ``_apply_selection_dim`` when a Phantom Color
        override is active. Called when the override is cleared, when Phantom
        mode is turned off, or when the selection is dropped.
        """
        if not self._pre_dim_color:
            return
        for pid, color in self._pre_dim_color.items():
            actor = self._part_actors.get(pid)
            if actor is None:
                continue
            try:
                actor.GetProperty().SetColor(float(color[0]), float(color[1]), float(color[2]))
            except Exception:
                pass
        self._pre_dim_color.clear()

    def _apply_selection_dim(self, selected_pids) -> None:
        """Dim non-selected parts to highlight the navigator selection.

        Driven by Config → "Phantom mode". When ON and at least one part is
        selected, every other part's opacity drops to ``_phantom_opacity``
        while the selected parts keep their pre-dim opacity. When the
        selection is cleared (or Phantom is turned off) every part returns
        to its snapshot value.

        Also refreshes the global feature-edge overlay so dimmed parts'
        silhouettes don't keep showing while their surface fades — see the
        Phantom branch in ``_rebuild_wire_overlay``.
        """
        if not self._part_actors:
            return
        if not self._phantom_enabled:
            self._restore_pre_dim_opacity()
            self._restore_pre_dim_color()
            self._refresh_global_wire_overlay()
            return
        sel = {int(p) for p in (selected_pids or [])}
        if sel:
            # Lazy snapshot: capture each part's current opacity the first time
            # we enter the dimmed state. Subsequent selection changes reuse it.
            if not self._pre_dim_opacity:
                for pid, actor in self._part_actors.items():
                    if actor is None:
                        continue
                    try:
                        self._pre_dim_opacity[pid] = float(
                            actor.GetProperty().GetOpacity()
                        )
                    except Exception:
                        self._pre_dim_opacity[pid] = 1.0
            dim_opa = float(self._phantom_opacity)
            custom_color = self._phantom_custom_color
            for pid, actor in self._part_actors.items():
                if actor is None:
                    continue
                try:
                    base = self._pre_dim_opacity.get(pid, 1.0)
                    target_opa = base if pid in sel else dim_opa
                    actor.GetProperty().SetOpacity(target_opa)
                except Exception:
                    pass
                # Phantom Color override: dimmed parts adopt the custom color,
                # selected parts restore their original. Selected→dimmed and
                # dimmed→selected transitions are handled symmetrically.
                if custom_color is not None:
                    if pid in sel:
                        orig = self._pre_dim_color.pop(pid, None)
                        if orig is not None:
                            try:
                                actor.GetProperty().SetColor(
                                    float(orig[0]), float(orig[1]), float(orig[2])
                                )
                            except Exception:
                                pass
                    else:
                        if pid not in self._pre_dim_color:
                            try:
                                c = actor.GetProperty().GetColor()
                                self._pre_dim_color[pid] = (
                                    float(c[0]), float(c[1]), float(c[2])
                                )
                            except Exception:
                                self._pre_dim_color[pid] = self._part_base_color.get(
                                    pid, (0.7, 0.7, 0.7)
                                )
                        try:
                            actor.GetProperty().SetColor(*custom_color)
                        except Exception:
                            pass
            if custom_color is None:
                # Override was cleared mid-session: pop any leftover snapshots.
                self._restore_pre_dim_color()
        else:
            self._restore_pre_dim_opacity()
            self._restore_pre_dim_color()
        self._refresh_global_wire_overlay()

    def _on_phantom_toggled(self, checked: bool) -> None:
        self._phantom_enabled = bool(checked)
        if hasattr(self, "_cfg_phantom_opacity"):
            self._cfg_phantom_opacity.setEnabled(self._phantom_enabled)
        # Re-apply with the current selection so the change takes effect immediately.
        self._apply_selection_dim(self._get_selected_pids())
        if self.plotter:
            self.plotter.render()

    def _on_phantom_opacity_changed(self, value: int) -> None:
        self._phantom_opacity = max(0.0, min(1.0, value / 100.0))
        if self._phantom_enabled:
            self._apply_selection_dim(self._get_selected_pids())
            if self.plotter:
                self.plotter.render()

    def _on_zoom_item_toggled(self, checked: bool) -> None:
        """Config → 'Zoom item'. When toggled on while parts are already
        selected, frame them immediately so the user sees the effect."""
        self._zoom_item_enabled = bool(checked)
        if self._zoom_item_enabled:
            self._zoom_to_selection_if_enabled(self._get_selected_pids())

    def _zoom_to_selection_if_enabled(self, selected_pids) -> None:
        """Fit camera to *selected_pids* when Zoom Item is on.

        Combines the bounds of each selected part's polydata and lets VTK's
        ``ResetCamera(bounds)`` recompute the camera position/clipping range
        along the *current* view direction — orientation (azimuth/elevation/
        roll) is preserved. Empty selection is a no-op so the user keeps
        whatever view they had before deselecting.
        """
        if not self._zoom_item_enabled:
            return
        if not selected_pids or self.plotter is None:
            return
        xmin = ymin = zmin = float("inf")
        xmax = ymax = zmax = float("-inf")
        any_bounds = False
        for pid in selected_pids:
            sub = self._part_polydata.get(int(pid))
            if sub is None:
                continue
            try:
                b = sub.bounds  # (xmin, xmax, ymin, ymax, zmin, zmax)
            except Exception:
                continue
            any_bounds = True
            if b[0] < xmin: xmin = b[0]
            if b[1] > xmax: xmax = b[1]
            if b[2] < ymin: ymin = b[2]
            if b[3] > ymax: ymax = b[3]
            if b[4] < zmin: zmin = b[4]
            if b[5] > zmax: zmax = b[5]
        if not any_bounds:
            return
        try:
            self.plotter.reset_camera(bounds=(xmin, xmax, ymin, ymax, zmin, zmax))
            self.plotter.render()
        except Exception as exc:
            logger.debug("zoom-to-selection failed: %s", exc)

    def _on_icon_text_toggled(self, checked: bool) -> None:
        self._icon_text_enabled = bool(checked)
        style = (
            Qt.ToolButtonStyle.ToolButtonTextUnderIcon
            if self._icon_text_enabled
            else Qt.ToolButtonStyle.ToolButtonIconOnly
        )
        # QToolBar.setToolButtonStyle only affects QToolButtons it created
        # internally via addAction; custom QToolButtons added via addWidget
        # (the combo-style buttons) need the style set directly.
        for tb in self._ribbon_toolbars:
            try:
                tb.setToolButtonStyle(style)
            except Exception:
                pass
        for btn in self._ribbon_combo_buttons:
            try:
                btn.setToolButtonStyle(style)
            except Exception:
                pass

    # ── Custom color pickers (Config tab) ───────────────────────────────

    def _make_color_swatch_btn(self, rgb: tuple[float, float, float]) -> "QPushButton":
        """Build a small colored button used as a click-to-pick swatch."""
        from PySide6.QtWidgets import QPushButton
        btn = QPushButton()
        btn.setFixedSize(40, 22)
        btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._set_swatch_color(btn, rgb)
        return btn

    @staticmethod
    def _set_swatch_color(btn: "QPushButton", rgb: tuple[float, float, float]) -> None:
        r = max(0, min(255, int(round(rgb[0] * 255))))
        g = max(0, min(255, int(round(rgb[1] * 255))))
        b = max(0, min(255, int(round(rgb[2] * 255))))
        hex_color = f"#{r:02x}{g:02x}{b:02x}"
        btn.setStyleSheet(
            f"QPushButton {{ background:{hex_color}; border:1px solid #808080; border-radius:3px; }}"
            f"QPushButton:hover {{ border:1px solid #1f6feb; }}"
        )
        btn.setProperty("rgb", (rgb[0], rgb[1], rgb[2]))

    def _bg_swatch_initial_rgb(self) -> tuple[float, float, float]:
        """Initial color shown on the BG swatch — best-effort guess from current state."""
        cur = getattr(self, "_current_bg", None)
        if isinstance(cur, str) and cur.startswith("#") and len(cur) == 7:
            try:
                return (int(cur[1:3], 16) / 255.0,
                        int(cur[3:5], 16) / 255.0,
                        int(cur[5:7], 16) / 255.0)
            except ValueError:
                pass
        named = {
            "white": (1.0, 1.0, 1.0),
            "black": (0.0, 0.0, 0.0),
            "lightgray": (0.83, 0.83, 0.83),
        }
        return named.get(cur, (0.95, 0.95, 0.95))

    def _on_pick_bg_color(self) -> None:
        from PySide6.QtWidgets import QColorDialog
        from PySide6.QtGui import QColor
        rgb = self._cfg_bg_swatch.property("rgb") or (1.0, 1.0, 1.0)
        initial = QColor.fromRgbF(*rgb)
        chosen = QColorDialog.getColor(initial, self, "Background Color")
        if not chosen.isValid():
            return
        new_rgb = (chosen.redF(), chosen.greenF(), chosen.blueF())
        self._set_swatch_color(self._cfg_bg_swatch, new_rgb)
        hex_color = chosen.name()  # "#rrggbb"
        self._custom_bg_color = hex_color
        self._set_background(hex_color)

    def _on_pick_phantom_color(self) -> None:
        """Choose a custom color for parts dimmed by Phantom mode."""
        from PySide6.QtWidgets import QColorDialog
        from PySide6.QtGui import QColor
        cur = self._phantom_custom_color or (
            self._cfg_phantom_color_swatch.property("rgb") or (0.5, 0.5, 0.5)
        )
        initial = QColor.fromRgbF(*cur)
        chosen = QColorDialog.getColor(initial, self, "Phantom Color")
        if not chosen.isValid():
            return
        new_rgb = (chosen.redF(), chosen.greenF(), chosen.blueF())
        self._set_swatch_color(self._cfg_phantom_color_swatch, new_rgb)
        self._phantom_custom_color = new_rgb
        # Re-apply dim so the new color shows immediately when phantom is on.
        if self._phantom_enabled:
            self._apply_selection_dim(self._get_selected_pids())
            if self.plotter:
                self.plotter.render()

    def _on_reset_model_display(self) -> None:
        """Restore Model Display defaults: BG=white, Phantom Color off, Edge=Auto.

        Phantom mode itself stays on/off as the user left it — only the
        *custom color* override is cleared so each dimmed part keeps its
        own color again.
        """
        # Background → white
        self._custom_bg_color = None
        self._set_swatch_color(self._cfg_bg_swatch, (1.0, 1.0, 1.0))
        self._set_background("white")
        # Phantom custom color → off (parts will revert to their own colors
        # next time _apply_selection_dim runs).
        self._phantom_custom_color = None
        self._set_swatch_color(self._cfg_phantom_color_swatch, (0.5, 0.5, 0.5))
        if self._phantom_enabled:
            self._apply_selection_dim(self._get_selected_pids())
        else:
            # Phantom is off but stale color snapshots may exist if the user
            # picked a custom color earlier while phantom was on — clear them.
            self._restore_pre_dim_color()
        # Edge color → auto (delegates to existing handler).
        self._on_reset_edge_color()
        if self.plotter:
            self.plotter.render()

    def _on_pick_edge_color(self) -> None:
        from PySide6.QtWidgets import QColorDialog
        from PySide6.QtGui import QColor
        cur = self._custom_edge_color or self._cfg_edge_swatch.property("rgb") or (0.0, 0.0, 0.0)
        initial = QColor.fromRgbF(*cur)
        chosen = QColorDialog.getColor(initial, self, "Edge Color")
        if not chosen.isValid():
            return
        new_rgb = (chosen.redF(), chosen.greenF(), chosen.blueF())
        self._set_swatch_color(self._cfg_edge_swatch, new_rgb)
        self._custom_edge_color = new_rgb
        self._apply_edge_color(new_rgb)

    def _on_reset_edge_color(self) -> None:
        """Restore the automatic edge color (white on dark / black on light)."""
        self._custom_edge_color = None
        bg = getattr(self, "_current_bg", "white")
        auto = (1.0, 1.0, 1.0) if bg == "black" else (0.0, 0.0, 0.0)
        self._set_swatch_color(self._cfg_edge_swatch, auto)
        self._apply_edge_color(auto)

    def _apply_edge_color(self, rgb: tuple[float, float, float]) -> None:
        """Apply *rgb* to the global wire overlay and per-part style edges."""
        actor = self._wire_overlay_actor
        if actor is not None:
            try:
                actor.GetProperty().SetColor(*rgb)
            except Exception:
                pass
        for fe in self._style_fe_actors.values():
            if fe is None:
                continue
            try:
                fe.GetProperty().SetColor(*rgb)
            except Exception:
                pass
        if self.plotter is not None:
            try:
                self.plotter.render()
            except Exception:
                pass

    def _update_properties_panel(self, selected_pids: list[int]):
        if not selected_pids:
            self._props_label.setText(
                "Select a part or element\nin the navigator or viewport\nto view properties."
            )
            return
        lines = []
        for pid in selected_pids:
            raw_name = (self._part_names.get(pid, "") or "").strip()
            heading_row = f"Heading: {raw_name}<br>" if raw_name else ""
            sub  = self._part_polydata.get(pid)
            mat_block = self._material_html_for_pid(pid)
            topo = self._part_topology.get(pid)
            if topo:
                n_nodes = topo.get("nodes", sub.n_points if sub is not None else 0)
                n_elems = topo.get("elements", sub.n_cells if sub is not None else 0)
                lines.append(
                    f"<b>Part {pid}</b><br>"
                    f"{heading_row}"
                    f"Nodes: {n_nodes:,}<br>"
                    f"Elements: {n_elems:,}"
                    f"{mat_block}<hr>"
                )
            elif sub is not None:
                lines.append(
                    f"<b>Part {pid}</b><br>"
                    f"{heading_row}"
                    f"Nodes: {sub.n_points:,}<br>"
                    f"Elements: {sub.n_cells:,}"
                    f"{mat_block}<hr>"
                )
            else:
                lines.append(
                    f"<b>Part {pid}</b><br>{heading_row}{mat_block}<hr>"
                )
        self._props_label.setTextFormat(Qt.TextFormat.RichText)
        self._props_label.setText("".join(lines))
        self._resize_props_panel_to_fit()

    def _material_html_for_pid(self, pid: int) -> str:
        mid = self._part_to_mid.get(int(pid))
        if not mid:
            return ""
        info = self._materials.get(mid, {}) or {}
        title = (info.get("title") or "").strip()
        keyword = (info.get("keyword") or "").strip()
        kw_html = f"*{keyword}" if keyword else "(undefined)"
        title_html = f": {title}" if title else ""
        return (
            f"<br>Material: {kw_html}"
            f"<br>MID {mid}{title_html}"
        )

    def _get_selected_pids(self) -> list[int]:
        """Return the leaf pids covered by the current selection.

        If the user selects a parent node (Assembly, FEM Parts, …) all
        descendant FEM-Part leaves are included. Entity items (tuple data)
        are ignored.
        """
        pids: list[int] = []
        seen: set[int] = set()

        def collect(it):
            d = it.data(0, Qt.ItemDataRole.UserRole)
            if isinstance(d, numbers.Integral):
                pid = int(d)
                if pid not in seen:
                    seen.add(pid)
                    pids.append(pid)
                return
            for i in range(it.childCount()):
                collect(it.child(i))

        for item in self._nav_tree.selectedItems():
            collect(item)
        return pids

    def _remove_highlight_edges(self):
        for actor in list(self._highlight_fe_actors.values()):
            try:
                if self.plotter:
                    self.plotter.remove_actor(actor)
            except Exception:
                pass
        self._highlight_fe_actors.clear()
        self._highlighted_pids.clear()

    # =========================================================================
    #  Entity actors
    # =========================================================================

    def _entity_actor_key(self, cat: str, sid: int) -> str:
        return f"{cat}_{sid}"

    def _toggle_entity_visibility(self, cat: str, sid: int, visible: bool):
        key = self._entity_actor_key(cat, sid)
        if visible:
            if key not in self._entity_actors:
                self._add_entity_actor(cat, sid)
        else:
            actor = self._entity_actors.pop(key, None)
            if actor is not None:
                try:
                    self.plotter.remove_actor(actor)
                except Exception:
                    pass

    def _add_entity_actor(self, cat: str, sid: int):
        import numpy as np
        members = self._keyword_entities.get(cat, {}).get(sid)
        if not members or self._polydata is None or self.plotter is None:
            return
        pd  = self._polydata
        key = self._entity_actor_key(cat, sid)
        try:
            if cat == "SET_NODE":
                nids = pd.point_data.get("node_ids")
                if nids is None:
                    return
                mask = np.isin(nids, list(set(members)))
                pts  = pd.points[mask]
                if len(pts) == 0:
                    return
                import pyvista as pv
                actor = self.plotter.add_mesh(
                    pv.PolyData(pts), color="red", point_size=8,
                    render_points_as_spheres=True, label=f"_entity_{key}")
                self._entity_actors[key] = actor
            elif cat in ("SET_SHELL", "SET_SOLID"):
                elem_ids = pd.cell_data.get("element_ids")
                if elem_ids is None:
                    return
                idx = np.where(np.isin(elem_ids, list(set(members))))[0]
                if len(idx) == 0:
                    return
                actor = self.plotter.add_mesh(
                    pd.extract_cells(idx), color="red", opacity=0.6,
                    show_edges=True, edge_color="darkred", line_width=1.5,
                    label=f"_entity_{key}")
                self._entity_actors[key] = actor
            elif cat == "SET_PART":
                pids_arr = pd.cell_data.get("part_ids")
                if pids_arr is None:
                    return
                idx = np.where(np.isin(pids_arr, list(set(members))))[0]
                if len(idx) == 0:
                    return
                actor = self.plotter.add_mesh(
                    pd.extract_cells(idx), color="red", opacity=0.6,
                    show_edges=True, edge_color="darkred", line_width=1.5,
                    label=f"_entity_{key}")
                self._entity_actors[key] = actor
            elif cat == "SET_SEGMENT":
                nids = pd.point_data.get("node_ids")
                if nids is None:
                    return
                id_to_idx = {int(n): i for i, n in enumerate(nids)}
                import pyvista as pv
                faces: list = []
                for seg in members:
                    indices = [id_to_idx.get(n) for n in seg if id_to_idx.get(n) is not None]
                    if len(indices) >= 3:
                        faces.append(len(indices))
                        faces.extend(indices)
                if not faces:
                    return
                actor = self.plotter.add_mesh(
                    pv.PolyData(pd.points, faces=faces), color="red", opacity=0.6,
                    show_edges=True, edge_color="darkred", line_width=2.0,
                    label=f"_entity_{key}")
                self._entity_actors[key] = actor
        except Exception as exc:
            logger.debug("Entity actor %s failed: %s", key, exc)

    def _remove_all_entity_actors(self):
        for actor in list(self._entity_actors.values()):
            try:
                if self.plotter:
                    self.plotter.remove_actor(actor)
            except Exception:
                pass
        self._entity_actors.clear()

    # =========================================================================
    #  Materials — parsing + highlighting
    # =========================================================================

    def _consume_materials_payload(self, payload) -> None:
        """Consume the loader's ``__materials__`` payload.

        Shape: ``{"materials": {mid: {"title": str}}, "part_to_mid": {pid: mid}}``.
        Only materials referenced by at least one *PART are kept; each material
        gets its set of pids attached for highlighting.
        """
        self._materials = {}
        self._part_to_mid = {}
        if not isinstance(payload, dict):
            return
        raw_mats: dict = payload.get("materials") or {}
        part_to_mid: dict = {int(k): int(v) for k, v in (payload.get("part_to_mid") or {}).items()}
        used: dict = {}
        for pid, mid in part_to_mid.items():
            slot = used.setdefault(mid, {"title": "", "parts": set()})
            slot["parts"].add(pid)
        for mid, slot in used.items():
            info = raw_mats.get(mid) or raw_mats.get(str(mid)) or {}
            # Fallback for decks where materials are *INCLUDE'd at global scope
            # (idmoff=0) while parts reference them via *INCLUDE_TRANSFORM with
            # idmoff offsets (typically multiples of 1 000 000).  In that case
            # raw_mats has keys 1/2/3 but part_to_mid values are 1000001 etc.
            # Stripping the offset tier (mid % 1_000_000) recovers the base MID.
            if not info and mid >= 1_000_000:
                base_mid = mid % 1_000_000
                if base_mid > 0:
                    info = raw_mats.get(base_mid) or raw_mats.get(str(base_mid)) or {}
            if isinstance(info, dict):
                slot["title"]   = info.get("title", "") or ""
                slot["keyword"] = info.get("keyword", "") or ""
            else:
                slot["title"] = ""
                slot["keyword"] = ""
        self._materials = used
        self._part_to_mid = part_to_mid

    def _effective_highlighted_pids(self) -> set:
        """Union of pids covered by selected (preview) + checked (permanent) materials."""
        pids: set = set()
        for mid in self._material_checked_mids:
            pids.update(self._materials.get(mid, {}).get("parts", set()))
        for mid in self._material_selected_mids:
            pids.update(self._materials.get(mid, {}).get("parts", set()))
        return pids

    def _apply_material_highlight(self) -> None:
        """Apply material highlighting to part actors:

        - Parts whose material is selected/checked get an intensified version
          of their own base color, an orange feature-edge overlay, and are
          forced visible.
        - Other parts use their base color, no overlay, and respect the
          user's FEM Parts checkbox state (self._part_user_visible).
        """
        if not self._part_actors:
            return
        eff = self._effective_highlighted_pids()
        for pid, actor in self._part_actors.items():
            if actor is None:
                continue
            base = self._part_base_color.get(pid)
            try:
                prop = actor.GetProperty()
                if base is not None:
                    color = _intensify_rgb(base) if pid in eff else base
                    prop.SetColor(float(color[0]), float(color[1]), float(color[2]))
                # Check-off is absolute: nothing of this part renders.
                user_vis = bool(self._part_user_visible.get(pid, True))
                eff_style = self._per_part_style.get(pid, self._current_style)
                mesh_on = bool(self._per_part_mesh.get(pid, self._mesh_visible))
                # Wireframe / Points with mesh OFF: the actor itself carries
                # no useful detail (it'd just show the same outline the
                # feature-edge overlay already provides), so we hide it. The
                # overlay (global or per-part) then supplies the silhouette.
                hide_actor_for_overlay = (
                    eff_style in ("Wireframe", "Points") and not mesh_on
                )
                actor.SetVisibility(user_vis and not hide_actor_for_overlay)
                # Per-part style overlay (selection mode) tracks the part's
                # check-on state.
                fe_style = self._style_fe_actors.get(pid)
                if fe_style is not None:
                    fe_style.SetVisibility(user_vis)
                fe_mat = self._material_fe_actors.get(pid)
                if fe_mat is not None:
                    fe_mat.SetVisibility(user_vis)
            except Exception as exc:
                logger.debug("apply highlight pid %s failed: %s", pid, exc)

        # Manage orange feature-edge overlays: drop those no longer needed,
        # create new ones for newly-highlighted pids.
        if self.plotter is not None:
            for pid in list(self._material_fe_actors.keys()):
                if pid not in eff:
                    actor = self._material_fe_actors.pop(pid, None)
                    if actor is not None:
                        try:
                            self.plotter.remove_actor(actor, render=False)
                        except Exception:
                            pass
            for pid in eff:
                if pid in self._material_fe_actors:
                    continue
                sub = self._part_polydata.get(pid)
                if sub is None:
                    continue
                try:
                    edges = self._clean_feature_edges(sub, feature_angle=60)
                    if edges is None or edges.n_points == 0:
                        continue
                    fe_actor = self.plotter.add_mesh(
                        edges,
                        color=(1.0, 0.45, 0.0),  # orange
                        style="wireframe",
                        line_width=4.0,
                        lighting=False,
                        pickable=False,
                        render=False,
                        name=f"_matfe_{pid}",
                    )
                    self._material_fe_actors[pid] = fe_actor
                except Exception as exc:
                    logger.debug("feature-edge overlay pid %s failed: %s", pid, exc)

        if self.plotter:
            try:
                self.plotter.render()
            except Exception:
                pass

    # =========================================================================
    #  Toolbar action implementations
    # =========================================================================

    def _action_import(self):
        start = str(self._file_path.parent) if self._file_path else ""
        path, _ = QFileDialog.getOpenFileName(
            self, "Open .k Model", start,
            "LS-DYNA Files (*.k *.key *.dyn);;All Files (*)",
        )
        if path:
            self._file_path = Path(path)
            self.setWindowTitle(f"3D Viewer 2.0  —  {self._file_path.name}")
            self._populate_files_list()
            self._start_load(self._file_path)

    def _action_screenshot(self):
        if self.plotter is None:
            self._status.showMessage("No viewport open yet")
            return
        default = (self._file_path.stem + "_3d.png") if self._file_path else "screenshot_3d.png"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Screenshot", default,
            "PNG Images (*.png);;JPEG Images (*.jpg);;All Files (*)",
        )
        if path:
            self.plotter.screenshot(path)
            self._status.showMessage(f"Screenshot saved: {path}", 5000)

    def _set_render_style(self, style: str):
        """Apply a render style to a scoped subset of parts.

        Scope rules (Style is independent from Mesh / visibility):
          * If one or more parts are selected in the navigator → apply only
            to those parts.
          * Otherwise → apply to every part that is currently *check-on*
            (``_part_user_visible[pid] is True``). Check-off parts stay
            hidden and untouched.
          * If no part is visible at all → no-op (status hint only).

        This action MUST NOT toggle the Mesh button or change
        ``_mesh_visible``/``_per_part_mesh``. It DOES manage the global
        feature-edge overlay because that overlay is conceptually part of
        the style (it represents "main edges" of the parts):
          * Surface        → overlay hidden
          * Surface+Edges  → overlay as wireframe
          * Wireframe      → overlay as wireframe
          * Points         → overlay as points

        Element-detail (per-cell edges/points) follows the Mesh toggle and
        is applied by ``_apply_style_to_actor``.
        """
        if self.plotter is None:
            return
        # Keep the Style dropdown's checked indicator in sync regardless of
        # selection — style buttons are mutually exclusive (QActionGroup).
        act = self._style_actions.get(style)
        if act is not None and not act.isChecked():
            act.setChecked(True)

        selected_pids = self._get_selected_pids()
        if selected_pids:
            target_pids = [pid for pid in selected_pids
                           if self._part_actors.get(pid) is not None]
            scope_msg = (
                f"Render style: {style}  (parts: "
                f"{', '.join(str(p) for p in target_pids)})"
                if target_pids else
                f"Render style: {style} — selection has no renderable parts"
            )
        else:
            self._current_style = style
            target_pids = [pid for pid, actor in self._part_actors.items()
                           if actor is not None
                           and self._part_user_visible.get(pid, True)]
            scope_msg = (
                f"Render style: {style}"
                if target_pids else
                f"Render style: {style} — no visible parts, nothing to apply"
            )

        is_global = not selected_pids

        # ── Global feature-edge overlay (the "main edges" of the parts) ──
        # Surface           → no overlay
        # Surface+Edges     → overlay (wireframe)
        # Wireframe         → overlay (wireframe)
        # Points            → overlay (points)
        if is_global:
            # Drop any per-part style overlays — global mode uses the single
            # combined overlay instead.
            for fe in list(self._style_fe_actors.values()):
                try:
                    self.plotter.remove_actor(fe, render=False)
                except Exception:
                    pass
            self._style_fe_actors.clear()
            if style == "Surface":
                self._remove_wire_overlay()
            else:
                self._rebuild_wire_overlay(as_points=(style == "Points"))

        mesh_on = bool(getattr(self, "_mesh_visible", True))
        for pid in target_pids:
            actor = self._part_actors.get(pid)
            self._per_part_style[pid] = style
            self._apply_style_to_actor(actor, style, mesh_on=mesh_on)
            if not is_global:
                self._update_style_fe_overlay(pid, style)

        # Visibility (actor vs feature-edge overlay) is reconciled centrally.
        self._apply_material_highlight()

        self._status.showMessage(scope_msg, 3000)
        self.plotter.render()

    def _clean_feature_edges(self, mesh, feature_angle: float = 60):
        """Extract clean silhouette edges from *mesh*.

        Two-stage approach:
          1. vtkCleanPolyData merges coincident points and removes
             degenerate cells that occasionally slip through and would
             break manifold detection downstream.
          2. vtkFeatureEdges extracts only **boundary edges** (open
             shell perimeters) and **sharp dihedral feature edges**
             above ``feature_angle``. Non-manifold and manifold edges
             are dropped — the former never appear in clean meshes,
             the latter would dump every element edge once topology
             is broken. With feature_angle=60 facet seams along
             cylindrical surfaces (typical dihedral ≤ 30°) are filtered
             out, leaving only true silhouettes (cube corners ≈ 90°,
             cylinder cap rims ≈ 90°).

        Note: we deliberately skip vtkTriangleFilter here. Triangulating
        non-coplanar quads (the lateral faces of a hex-meshed cylinder
        are slightly curved) introduces a diagonal edge whose dihedral
        with the quad's other half can exceed feature_angle, producing
        spurious "artefact" lines.
        """
        import vtk as _vtk
        import pyvista as pv
        try:
            if hasattr(mesh, "extract_surface") and not isinstance(mesh, pv.PolyData):
                mesh_pd = mesh.extract_surface()
            else:
                mesh_pd = mesh

            cleaner = _vtk.vtkCleanPolyData()
            cleaner.SetInputData(mesh_pd)
            cleaner.SetTolerance(0.0)
            cleaner.PointMergingOn()
            cleaner.ConvertLinesToPointsOff()
            cleaner.ConvertPolysToLinesOff()
            cleaner.ConvertStripsToPolysOff()
            cleaner.Update()

            fe = _vtk.vtkFeatureEdges()
            fe.SetInputConnection(cleaner.GetOutputPort())
            fe.BoundaryEdgesOn()
            fe.FeatureEdgesOn()
            fe.NonManifoldEdgesOff()
            fe.ManifoldEdgesOff()
            fe.SetFeatureAngle(feature_angle)
            fe.ColoringOff()
            fe.Update()
            return pv.wrap(fe.GetOutput())
        except Exception as exc:
            logger.debug("clean feature edges failed: %s", exc)
            return None

    def _update_style_fe_overlay(self, pid: int, style: str) -> None:
        """Manage the per-part feature-edge overlay (used in selection mode).

        Mirrors the global overlay matrix:
          * Surface          → remove overlay
          * Surface+Edges    → wireframe overlay
          * Wireframe        → wireframe overlay
          * Points           → points overlay

        For the global (no-selection) case, ``_rebuild_wire_overlay`` uses the
        combined polydata which correctly preserves inter-cell connectivity.
        """
        if self.plotter is None:
            return
        existing = self._style_fe_actors.get(pid)
        if style == "Surface":
            if existing is not None:
                try:
                    self.plotter.remove_actor(existing, render=False)
                except Exception:
                    pass
                self._style_fe_actors.pop(pid, None)
            return

        # Rebuild whenever style switches between wireframe and points; the
        # cheapest correct approach is to drop and re-create.
        if existing is not None:
            try:
                self.plotter.remove_actor(existing, render=False)
            except Exception:
                pass
            self._style_fe_actors.pop(pid, None)

        sub = self._part_polydata.get(pid)
        if sub is None:
            return
        try:
            edges = self._clean_feature_edges(sub, feature_angle=60)
            if edges is None or edges.n_points == 0:
                return
            fe_color = "white" if self._current_bg == "black" else "black"
            kw: dict = dict(
                color=fe_color,
                lighting=False,
                pickable=False,
                render=False,
                name=f"_stylefe_{pid}",
            )
            if style == "Points":
                kw.update(style="points", point_size=5,
                          render_points_as_spheres=True)
            else:
                kw.update(style="wireframe", line_width=1.5)
            fe = self.plotter.add_mesh(edges, **kw)
            self._style_fe_actors[pid] = fe
        except Exception as exc:
            logger.debug("style fe overlay pid %s failed: %s", pid, exc)

    def _fit_camera_to_model(self) -> None:
        """Frame the model only, ignoring datum reference geometry (world
        axes / grid planes) which extend well beyond the model. The datums
        still keep UseBounds=True so the clipping range covers them (they are
        not cut); only the camera framing is restricted to the model bounds."""
        if self.plotter is None:
            return
        b = None
        if self._polydata is not None:
            try:
                b = tuple(self._polydata.bounds)
            except Exception:
                b = None
        try:
            if b is not None:
                self.plotter.reset_camera(bounds=b)
            else:
                self.plotter.reset_camera()
        except Exception:
            try:
                self.plotter.reset_camera()
            except Exception:
                pass

    def _action_fit_all(self):
        if self.plotter:
            self._fit_camera_to_model()
            self.plotter.render()

    # ── Zoom Window ──────────────────────────────────────────────────────

    def _action_toggle_zoom_window(self, checked: bool) -> None:
        """Enter / exit click-drag rubber-band zoom mode.

        Uses VTK's ``vtkInteractorStyleRubberBandZoom``: the user drags a
        rectangle and on mouse release VTK fits the camera to it. We swap
        the interactor style only while the mode is active, then restore the
        previous style automatically when the zoom completes.
        """
        if self.plotter is None or self.plotter.iren is None:
            self._a_zoom_window.setChecked(False)
            return
        if checked:
            self._zw_enter()
        else:
            self._zw_exit()

    def _zw_vtk_iren(self):
        """Return the underlying VTK render-window interactor.

        ``plotter.iren`` is the PyVista wrapper (``RenderWindowInteractor``)
        which exposes ``get_interactor_style`` / ``set_interactor_style`` but
        not the VTK-style PascalCase methods. The wrapped VTK object lives at
        ``plotter.iren.interactor`` and accepts the standard VTK API.
        """
        if self.plotter is None or self.plotter.iren is None:
            return None
        wrapper = self.plotter.iren
        return getattr(wrapper, "interactor", wrapper)

    def _zw_enter(self) -> None:
        vtk_iren = self._zw_vtk_iren()
        if vtk_iren is None:
            self._a_zoom_window.setChecked(False)
            return
        try:
            from vtkmodules.vtkInteractionStyle import (
                vtkInteractorStyleRubberBandZoom,
            )
        except Exception:
            try:
                import vtk
                vtkInteractorStyleRubberBandZoom = vtk.vtkInteractorStyleRubberBandZoom
            except Exception:
                logger.debug("vtkInteractorStyleRubberBandZoom unavailable", exc_info=True)
                self._a_zoom_window.setChecked(False)
                return
        self._zw_prev_style = vtk_iren.GetInteractorStyle()
        style = vtkInteractorStyleRubberBandZoom()
        # Left-drag draws the rectangle and zooms on release.
        try:
            style.SetLockAspectToViewport(True)
        except Exception:
            pass
        vtk_iren.SetInteractorStyle(style)
        # When the user releases the mouse VTK fires EndInteractionEvent on
        # the style — restore the previous style and uncheck the toolbar.
        self._zw_obs_id = style.AddObserver(
            "EndInteractionEvent", self._zw_on_end
        )
        try:
            self.plotter.interactor.setCursor(Qt.CursorShape.CrossCursor)
        except Exception:
            pass
        self._status.showMessage(
            "Zoom Window: drag a rectangle in the viewer (click the button again to cancel)",
            0,
        )

    def _zw_exit(self) -> None:
        vtk_iren = self._zw_vtk_iren()
        prev = getattr(self, "_zw_prev_style", None)
        obs_id = getattr(self, "_zw_obs_id", None)
        cur_style = vtk_iren.GetInteractorStyle() if vtk_iren is not None else None
        if cur_style is not None and obs_id is not None:
            try:
                cur_style.RemoveObserver(obs_id)
            except Exception:
                pass
        if vtk_iren is not None and prev is not None:
            try:
                vtk_iren.SetInteractorStyle(prev)
            except Exception:
                pass
        self._zw_obs_id = None
        self._zw_prev_style = None
        try:
            self.plotter.interactor.unsetCursor()
        except Exception:
            pass
        if self._a_zoom_window.isChecked():
            # Block recursion through toggled signal.
            self._a_zoom_window.blockSignals(True)
            self._a_zoom_window.setChecked(False)
            self._a_zoom_window.blockSignals(False)
        self._status.clearMessage()

    def _zw_on_end(self, _style, _event) -> None:
        """Fired by vtkInteractorStyleRubberBandZoom when the drag completes."""
        try:
            if self.plotter is not None:
                self.plotter.renderer.ResetCameraClippingRange()
                self.plotter.render()
        except Exception:
            pass
        self._zw_exit()

    def _action_toggle_orbit(self):
        """Start/stop continuous azimuth rotation around the model."""
        if self.plotter is None:
            self._a_orbit.setChecked(False)
            return
        if self._orbit_timer.isActive():
            self._orbit_timer.stop()
            self._a_orbit.setChecked(False)
            self._status.showMessage("Orbit stopped", 2000)
        else:
            self._orbit_timer.start()
            self._a_orbit.setChecked(True)
            self._status.showMessage("Orbit running — click Orbit again to stop", 0)

    def _orbit_step(self):
        """Rotate camera azimuth by 1 degree per timer tick."""
        if self.plotter is None:
            self._orbit_timer.stop()
            return
        try:
            self.plotter.camera.Azimuth(1.0)
            self.plotter.render()
        except Exception:
            self._orbit_timer.stop()
            self._a_orbit.setChecked(False)

    def _action_toggle_properties_panel(self):
        """Show / hide the right-hand Properties panel."""
        panel = getattr(self, "_right_panel", None)
        if panel is None:
            return
        new_visible = not panel.isVisible()
        panel.setVisible(new_visible)
        if hasattr(self, "_a_props"):
            self._a_props.setChecked(new_visible)
        if new_visible:
            self._resize_props_panel_to_fit()
        self._status.showMessage(
            f"Properties panel: {'shown' if new_visible else 'hidden'}", 2000
        )

    def _action_toggle_axes(self):
        if self.plotter is None:
            return
        self._axes_visible = not self._axes_visible
        if self._axes_visible:
            self.plotter.show_axes()
        else:
            self.plotter.hide_axes()
        self._a_axes.setChecked(self._axes_visible)
        self.plotter.render()

    def _action_toggle_grid(self):
        if self.plotter is None:
            return
        self._bounds_visible = not self._bounds_visible
        if self._bounds_visible:
            self.plotter.show_bounds(grid="back", location="outer")
        else:
            self.plotter.remove_bounds_axes()
        self._a_grid.setChecked(self._bounds_visible)
        self.plotter.render()

    def _action_toggle_projection(self):
        if self.plotter is None:
            return
        self._parallel = not self._parallel
        if self._parallel:
            self.plotter.enable_parallel_projection()
            self._a_proj.setIcon(getattr(self, '_v2_ortho_icon', QIcon()))
            self._a_proj.setText("Parallel")
        else:
            self.plotter.disable_parallel_projection()
            self._a_proj.setIcon(getattr(self, '_v2_persp_icon', QIcon()))
            self._a_proj.setText("Perspective")
        self._a_proj.setChecked(self._parallel)
        self.plotter.render()

    def _action_toggle_mesh(self):
        """Toggle visibility of per-cell mesh detail (element edges/points).

        This MUST NOT change the render style or the feature-edge overlay —
        those live in ``_set_render_style``. Mesh = element detail; Style =
        main edges and surface representation.
        """
        if self.plotter is None:
            return
        def _is_visible(actor) -> bool:
            try:
                return bool(actor) and bool(actor.GetVisibility())
            except Exception:
                return False
        selected_pids = self._get_selected_pids()
        if selected_pids:
            visible_pids = [
                pid for pid in selected_pids
                if _is_visible(self._part_actors.get(pid))
            ]
            if not visible_pids:
                self._status.showMessage(
                    "Mesh: no visible parts in selection", 3000
                )
                return
            all_on = all(
                self._per_part_mesh.get(pid, self._mesh_visible)
                for pid in visible_pids
            )
            checked = not all_on
            for pid in visible_pids:
                self._per_part_mesh[pid] = checked
                actor = self._part_actors.get(pid)
                if actor is None:
                    continue
                style = self._per_part_style.get(pid, self._current_style)
                self._apply_style_to_actor(actor, style, mesh_on=checked)
            scope = ", ".join(str(p) for p in visible_pids)
            state = "ON" if checked else "OFF"
            self._status.showMessage(
                f"Mesh: {state}  (parts: {scope})", 3000
            )
        else:
            checked = not self._mesh_visible
            self._mesh_visible = checked
            if hasattr(self, '_v2_a_mesh'):
                self._v2_a_mesh.setChecked(checked)
            self._per_part_mesh.clear()
            style = self._current_style
            for pid, actor in self._part_actors.items():
                if actor is None:
                    continue
                self._apply_style_to_actor(actor, style, mesh_on=checked)
            self._status.showMessage(
                f"Mesh: {'ON' if checked else 'OFF'}", 3000
            )

        # Visibility (actor vs feature-edge overlay) is reconciled centrally.
        self._apply_material_highlight()
        self.plotter.render()

    def _set_opacity(self, text: str):
        if self.plotter is None:
            return
        val = int(text.replace("%", "")) / 100.0
        selected_pids = self._get_selected_pids()
        if selected_pids:
            for pid in selected_pids:
                actor = self._part_actors.get(pid)
                if actor is not None:
                    actor.GetProperty().SetOpacity(val)
                # Keep the dim snapshot in sync so deselection restores the
                # value the user just chose, not the pre-dim baseline.
                if self._pre_dim_opacity:
                    self._pre_dim_opacity[int(pid)] = val
            scope = ", ".join(str(p) for p in selected_pids)
            self._status.showMessage(f"Opacity: {text}  (parts: {scope})", 3000)
        else:
            for actor in self._actors:
                if actor is not None:
                    actor.GetProperty().SetOpacity(val)
        self.plotter.render()

    def _make_fx_callback(self, effect_name: str):
        """Return a slot that toggles *effect_name* on/off."""
        def _callback(checked: bool):
            self._apply_fx(effect_name, checked)
        return _callback

    def _apply_fx_to_actor(self, actor, name: str, on: bool):
        """Apply a per-actor visual effect (PBR / Smooth Shading)."""
        if actor is None:
            return
        prop = actor.GetProperty()
        if name == "PBR (Metallic)":
            if on:
                prop.SetInterpolationToPBR()
                prop.SetMetallic(0.7)
                prop.SetRoughness(0.3)
            else:
                prop.SetInterpolationToPhong()
                prop.SetMetallic(0.0)
                prop.SetRoughness(1.0)
        elif name == "Smooth Shading":
            if on:
                prop.SetInterpolationToPhong()
            else:
                prop.SetInterpolationToFlat()

    def _apply_fx(self, name: str, on: bool):
        """Apply or remove a visual effect."""
        try:
            # Global effects (not per-actor)
            if name == "Silhouette":
                if on:
                    if not hasattr(self, '_silhouette_actor') or self._silhouette_actor is None:
                        self._silhouette_actor = self.plotter.add_silhouette(
                            self._polydata, color="black", line_width=2.5,
                        )
                else:
                    if hasattr(self, '_silhouette_actor') and self._silhouette_actor is not None:
                        self.plotter.remove_actor(self._silhouette_actor)
                        self._silhouette_actor = None

            elif name == "Anti-aliasing":
                if on:
                    self.plotter.enable_anti_aliasing('msaa')
                else:
                    self.plotter.disable_anti_aliasing()

            elif name == "Depth Peeling":
                if on:
                    self.plotter.enable_depth_peeling(number_of_peels=8, occlusion_ratio=0.0)
                else:
                    self.plotter.disable_depth_peeling()

            elif name == "SSAO":
                if on:
                    # Radius/bias auto-scale from the model's bounding box so
                    # the effect reads at any model size.
                    try:
                        b = self.plotter.bounds  # (xmin, xmax, ymin, ymax, zmin, zmax)
                        diag = max(
                            1e-6,
                            ((b[1]-b[0])**2 + (b[3]-b[2])**2 + (b[5]-b[4])**2) ** 0.5,
                        )
                    except Exception:
                        diag = 1.0
                    radius = diag * 0.02
                    bias   = diag * 0.001
                    self.plotter.enable_ssao(
                        radius=radius, bias=bias, kernel_size=64, blur=True,
                    )
                else:
                    try:
                        self.plotter.disable_ssao()
                    except AttributeError:
                        # Older PyVista: rebuild the render pass chain by
                        # toggling EnableSSAO off on the renderer directly.
                        try:
                            self.plotter.renderer.SetUseSSAO(False)
                        except Exception:
                            pass

            # Per-actor effects (PBR, Smooth Shading)
            elif name in ("PBR (Metallic)", "Smooth Shading"):
                selected_pids = self._get_selected_pids()
                if selected_pids:
                    for pid in selected_pids:
                        fx_state = self._per_part_fx.setdefault(pid, {})
                        fx_state[name] = on
                        actor = self._part_actors.get(pid)
                        self._apply_fx_to_actor(actor, name, on)
                    scope = ", ".join(str(p) for p in selected_pids)
                    state = "ON" if on else "OFF"
                    self._status.showMessage(f"{name}: {state}  (parts: {scope})", 3000)
                    self.plotter.render()
                    return
                else:
                    for pid, actor in self._part_actors.items():
                        fx_state = self._per_part_fx.setdefault(pid, {})
                        fx_state[name] = on
                        self._apply_fx_to_actor(actor, name, on)

            self.plotter.render()
            state = "ON" if on else "OFF"
            self._status.showMessage(f"{name}: {state}", 3000)
        except Exception as exc:
            logger.warning("Visual effect '%s' failed: %s", name, exc)
            self._status.showMessage(f"{name}: not available", 3000)

    def _set_background(self, bg: str):
        if self.plotter is None:
            return
        if bg == "__gradient_blue":
            self.plotter.set_background("royalblue", top="aliceblue")
        elif bg == "__gradient_gray":
            self.plotter.set_background("#3c3c3c", top="#888888")
        else:
            self.plotter.set_background(bg)
        self._current_bg = bg
        # Edge color follows the theme unless the user picked a custom one.
        if self._custom_edge_color is not None:
            edge_rgb = self._custom_edge_color
        else:
            edge_rgb = (1.0, 1.0, 1.0) if bg == "black" else (0.0, 0.0, 0.0)
        if self._wire_overlay_actor is not None:
            self._wire_overlay_actor.GetProperty().SetColor(*edge_rgb)
        # Corner axes labels need to stay readable against any background.
        self._apply_axes_label_colors()
        # Keep the Config swatch in sync when bg changes via View-tab buttons.
        swatch = getattr(self, "_cfg_bg_swatch", None)
        if swatch is not None and isinstance(bg, str) and bg.startswith("#") and len(bg) == 7:
            try:
                rgb = (int(bg[1:3], 16) / 255.0,
                       int(bg[3:5], 16) / 255.0,
                       int(bg[5:7], 16) / 255.0)
                self._set_swatch_color(swatch, rgb)
            except ValueError:
                pass
        self.plotter.render()

    def _setup_axes(self) -> None:
        """Add the corner axes triad and immediately apply label colours so
        they remain readable against the current background."""
        if self.plotter is None:
            return
        try:
            self._axes_widget = self.plotter.add_axes()
        except Exception:
            self._axes_widget = None
            return
        self._apply_axes_label_colors()

    def _apply_axes_label_colors(self) -> None:
        """X/Y/Z label text → white on dark backgrounds, black on light ones.

        ``pyvista.add_axes()`` returns the inner ``vtkAxesActor`` directly,
        but older versions (or other configurations) wrap it inside a
        ``vtkOrientationMarkerWidget``. Handle both shapes."""
        if self._axes_widget is None:
            return
        try:
            marker = self._axes_widget
            # Unwrap the orientation marker widget if that's what we got.
            if (
                hasattr(marker, "GetOrientationMarker")
                and not hasattr(marker, "GetXAxisCaptionActor2D")
            ):
                marker = marker.GetOrientationMarker()
            if marker is None:
                return
            fg = (1.0, 1.0, 1.0) if self._bg_is_dark() else (0.0, 0.0, 0.0)
            for getter_name in (
                "GetXAxisCaptionActor2D",
                "GetYAxisCaptionActor2D",
                "GetZAxisCaptionActor2D",
            ):
                getter = getattr(marker, getter_name, None)
                if getter is None:
                    continue
                try:
                    cap = getter()
                    if cap is None:
                        continue
                    tp = cap.GetCaptionTextProperty()
                    tp.SetColor(*fg)
                    tp.SetShadow(0)
                except Exception:
                    pass
        except Exception:
            logger.debug("Apply axes label colors failed", exc_info=True)

    def _bg_is_dark(self) -> bool:
        """White axes labels (and similar foreground decorations) are switched
        on only when the background is exactly ``"black"`` — matches the rest
        of the viewer's edge/foreground convention (``bg == "black"``)."""
        return self._current_bg == "black"

    def _action_clear_cache(self):
        if self._file_path is None:
            self._status.showMessage("No file loaded", 2000)
            return
        try:
            from ui.viewer_v2_loader import viewer_cache_key, viewer_cache_dir
            key  = viewer_cache_key(self._file_path)
            d    = viewer_cache_dir()
            removed = 0
            for ext in (".vtp", ".json"):
                p = d / f"{key}{ext}"
                if p.exists():
                    p.unlink()
                    removed += 1
            msg = f"Cache cleared ({removed} files)" if removed else "No cache found"
            self._status.showMessage(msg, 4000)
        except Exception as exc:
            self._status.showMessage(f"Cache clear failed: {exc}", 4000)

    # def _action_about(self):
    #     QMessageBox.about(
    #         self, "About 3D Viewer 2.0",
    #         "<h3>3D Viewer 2.0</h3>"
    #         "<p>Next-generation LS-DYNA model viewer for KeywordManager.</p>"
    #         "<p>Style: industrial/sober — steel-blue accent on dark panels.</p>"
    #         "<p>Reuses PyDyna parse, VTK cache, and render engine from<br>"
    #         "the classic 3D Model Viewer.</p>",
    #     )
        
    def _action_about(self):
        """Show an About dialog with version information."""
        icons_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "resources", "icons",
        )
        msg = QMessageBox(self)
        msg.setWindowTitle("About 3D Viewer 2.0")
        ico_path = os.path.join(icons_dir, "viewer_3D_.ico")
        if os.path.exists(ico_path):
            px = QPixmap(ico_path).scaled(
                64, 64, Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            msg.setIconPixmap(px)
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setText(
            "<h3>3D Viewer 2.0</h3>"
            "<p>Next-generation LS-DYNA model viewer for KeywordManager.</p>"
            "<p>Style: industrial/sober — steel-blue accent on dark panels.</p>"
            "<p>Reuses PyDyna parse, VTK cache, and render engine from<br>"
            "the classic 3D Model Viewer.</p>",
        )
        msg.exec()

    # =========================================================================
    #  Status / lifecycle
    # =========================================================================

    def _apply_theme(self, theme_name: str):
        """Apply a viewer GUI theme.
        'Dark (Viewer)' uses _STYLESHEET_DARK.
        All light themes use _STYLESHEET + per-theme overrides from _VIEWER_THEMES.
        """
        self._current_theme = theme_name
        if theme_name == "Dark (Viewer)":
            self.setStyleSheet(_STYLESHEET_DARK)
            if self.plotter is not None and not self._theme_is_dark:
                self._prev_bg = self._current_bg
                self._set_background("#2b2b2b")
            self._theme_is_dark = True
        else:
            override = _VIEWER_THEMES.get(theme_name, "")
            self.setStyleSheet(_STYLESHEET + override)
            if self.plotter is not None and self._theme_is_dark:
                self._set_background(self._prev_bg)
            self._theme_is_dark = False
        self._status.showMessage(f"Theme: {theme_name}", 3000)

    def _update_status(self):
        if self._polydata is None or self._file_path is None:
            return
        parts_txt = f"  |  Parts: {self._n_parts}" if self._has_parts else ""
        self._status.showMessage(
            f"{self._file_path.name}  |  "
            f"Nodes: {self._polydata.n_points:,}  |  "
            f"Cells: {self._polydata.n_cells:,}{parts_txt}"
        )

    def closeEvent(self, event):
        if getattr(self, "_orbit_timer", None) is not None:
            try:
                self._orbit_timer.stop()
            except Exception:
                pass
        try:
            self._cancel_camera_animation()
        except Exception:
            pass
        # Drop Tools-tab interactor observers before the plotter dies.
        try:
            self._remove_pick_node_observer()
        except Exception:
            pass
        try:
            self._remove_measure_observer()
        except Exception:
            pass
        try:
            self._remove_cut_plane_widget()
        except Exception:
            pass
        try:
            self._remove_cut_3pt_picking()
        except Exception:
            pass
        if self._load_worker is not None:
            try:
                self._load_worker.finished.disconnect()
            except RuntimeError:
                pass
            try:
                self._load_worker.geometry_ready.disconnect()
            except RuntimeError:
                pass
            self._load_worker.quit()
            self._load_worker.wait(2000)
            self._load_worker = None
        if self.plotter is not None:
            try:
                self.plotter.clear()
            except Exception:
                pass
            try:
                rw = self.plotter.render_window
                if rw is not None:
                    rw.Finalize()
            except Exception:
                pass
            try:
                self.plotter.close()
            except Exception:
                pass
        # Drop the PyDyna polydata cache built lazily for Wireframe so the
        # underlying VTK objects can be released before the dialog dies.
        self._pydyna_polydata = None
        self._pydyna_polydata_failed = False
        super().closeEvent(event)
