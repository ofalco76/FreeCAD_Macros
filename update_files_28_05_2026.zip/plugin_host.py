# core/tools/plugin_host.py
"""
Concrete ``KeywordInjectionHost`` for the running application.

This is the app-side translator of the plugin callback protocol: it turns the
pydyna-free ``KeywordSpec`` objects a plugin returns into project tree nodes
(via ``ProjectViewModel``) and refreshes the UI (via ``TreeViewModel``). It is
the single place that knows the tree layout the exporter expects and that
enforces LS-DYNA id-collision / 10-digit rules.

Tree layout produced (matches the importer, so the existing KFileBuilder
serializes it unchanged):

    <main root>
      ├─ DEFINE / TRANSFORMATION / ID:<n>   (record: title, tranid, transforms)
      └─ INCLUDE / TRANSFORM   / ID:<n>      (record: filename, id offsets, tranid)
"""

from __future__ import annotations

import contextlib
import logging
import re
import sys
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

from .keyword_contract import ApplyResult, KeywordSpec, PartIdStats

logger = logging.getLogger(__name__)

# Largest id LS-DYNA accepts in the standard (10-digit) id fields.
MAX_LSDYNA_ID = 9_999_999_999

# Keyword type name -> (GROUP, KEYWORD) node names, matching the importer's
# Root -> GROUP -> KEYWORD -> ID:<n> layout (see import_tree_builder).
_KEYWORD_TREE_NAMES: Dict[str, Tuple[str, str]] = {
    "DEFINE_TRANSFORMATION": ("DEFINE", "TRANSFORMATION"),
    "INCLUDE_TRANSFORM": ("INCLUDE", "TRANSFORM"),
}

# INCLUDE_TRANSFORM id-offset fields that must respect the 10-digit limit.
_ID_OFFSET_FIELDS = (
    "idnoff", "ideoff", "idpoff", "idmoff",
    "idsoff", "idfoff", "iddoff", "idroff",
)


def _app_base_path() -> Path:
    """Base path for app files (PyInstaller-aware), mirroring plugin_loader."""
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent.parent.parent


def _slug(name: Optional[str], fallback: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_-]+", "_", name or "").strip("_")
    return cleaned or fallback


class AppKeywordHost:
    """Implements the ``KeywordInjectionHost`` protocol for the live app."""

    def __init__(self, project_vm, tree_vm):
        self.project_vm = project_vm
        self.tree_vm = tree_vm

    # ── read-only context ────────────────────────────────────────────────
    def active_project_id(self) -> Optional[int]:
        return getattr(self.project_vm, "active_project_id", None)

    def active_project_dir(self) -> Optional[str]:
        """Export folder of the active project — a sensible file-dialog start."""
        pid = self.active_project_id()
        if pid is None:
            return None
        try:
            name = self.project_vm.get_project_name(pid)
        except Exception:
            name = None
        exports = _app_base_path() / "exports" / _slug(name, f"project_{pid}")
        if exports.exists():
            return str(exports)
        # Fall back to the exports root, then the app base.
        root = _app_base_path() / "exports"
        return str(root if root.exists() else _app_base_path())

    def inspect_part_file(self, path: str) -> PartIdStats:
        """Light text scan of a part ``.k`` for node/element id ranges.

        Pure text parsing (no pydyna): reads the first integer of every data
        line inside ``*NODE`` and ``*ELEMENT_*`` blocks. Robust enough to size
        offset blocks and to detect numbering that does not start at 1.
        """
        stats = PartIdStats()
        try:
            text = Path(path).read_text(encoding="utf-8", errors="ignore")
        except OSError as exc:
            logger.debug("inspect_part_file: cannot read %s: %s", path, exc)
            return stats

        mode = None  # "node" | "element" | None
        for raw in text.splitlines():
            line = raw.rstrip("\n")
            if not line.strip():
                continue
            if line.lstrip().startswith("$"):
                continue
            if line.lstrip().startswith("*"):
                kw = line.lstrip()[1:].upper()
                if kw.startswith("NODE"):
                    mode = "node"
                elif kw.startswith("ELEMENT"):
                    mode = "element"
                else:
                    mode = None
                continue
            if mode is None:
                continue
            token = line.replace(",", " ").split()
            if not token:
                continue
            try:
                first = int(float(token[0]))
            except (ValueError, IndexError):
                continue
            if mode == "node":
                stats.node_count += 1
                stats.min_node = first if stats.min_node is None else min(stats.min_node, first)
                stats.max_node = first if stats.max_node is None else max(stats.max_node, first)
            else:
                stats.element_count += 1
                stats.min_element = (
                    first if stats.min_element is None else min(stats.min_element, first)
                )
                stats.max_element = (
                    first if stats.max_element is None else max(stats.max_element, first)
                )
        return stats

    # ── injection ────────────────────────────────────────────────────────
    def apply_keywords(
        self,
        specs: List[KeywordSpec],
        group_label: Optional[str] = None,
        progress: Optional[Callable[[int, int], None]] = None,
    ) -> ApplyResult:
        pid = self.active_project_id()
        if pid is None:
            return ApplyResult(False, message="No project is open.")
        if not specs:
            return ApplyResult(False, message="No keywords to inject.")

        # Validate up front so we don't create a partial tree on bad input.
        error = self._validate(specs)
        if error:
            return ApplyResult(False, message=error)

        try:
            root_id = self._resolve_main_root(pid)
            # Optional named container under 'main' so the whole injected array
            # is grouped together and easy to find/delete (manual undo).
            base_parent = root_id
            container_name = None
            if group_label:
                base_parent, container_name = self._make_array_group(pid, root_id, group_label)
            # Cache of (group, keyword) parent ids created/reused this call.
            parent_cache: Dict[Tuple[str, str], int] = {}
            created: List[int] = []

            # Batch all keyword injections in a single SQLite transaction so the
            # hundreds of add_node / rename_node / upsert_param calls that make
            # up a large array injection result in ONE disk commit instead of
            # one per operation. This is the primary fix for >200 s injection
            # times on slow / non-system disks.
            strategy = getattr(
                getattr(self.project_vm, "db_manager", None), "strategy", None
            )
            batch_ctx = (
                strategy.batch_write()
                if strategy is not None and hasattr(strategy, "batch_write")
                else contextlib.nullcontext()
            )
            with batch_ctx:
                for spec in specs:
                    group, keyword = self._tree_names(spec.keyword)
                    key = (group, keyword)
                    if key not in parent_cache:
                        group_id = self._get_or_create_child(pid, base_parent, group)
                        parent_cache[key] = self._get_or_create_child(pid, group_id, keyword)
                    kw_parent = parent_cache[key]

                    node_id = self.project_vm.add_node("ID:new", kw_parent, pid)
                    # Rename to the ID:<id> form the exporter treats as a record.
                    self.project_vm.rename_node(node_id, f"ID:{node_id}")
                    self.project_vm.add_params(node_id, spec.as_params(), keyword_name=spec.keyword)
                    created.append(node_id)
                    # Optional progress callback (e.g. a plugin dialog progress bar).
                    # Guarded so a faulty callback can never abort the injection.
                    if progress is not None:
                        try:
                            progress(len(created), len(specs))
                        except Exception:
                            logger.debug("apply_keywords progress callback failed", exc_info=True)

            first_id = created[0] if created else None
            self._refresh_tree(pid, select_node_id=first_id)
            where = f"'{container_name}'" if container_name else "the main node"
            return ApplyResult(
                True,
                created_node_ids=created,
                target_root_id=root_id,
                message=f"Injected {len(created)} keywords into {where}.",
            )
        except Exception as exc:  # pragma: no cover - defensive
            logger.exception("apply_keywords failed")
            return ApplyResult(False, message=f"Error injecting keywords: {exc}")

    # ── helpers ──────────────────────────────────────────────────────────
    def _validate(self, specs: List[KeywordSpec]) -> Optional[str]:
        for spec in specs:
            params = spec.as_params()
            if "INCLUDE" in spec.keyword.upper():
                filename = params.get("filename")
                if not filename or not str(filename).strip():
                    return "An INCLUDE_TRANSFORM has no filename assigned."
            for fld in _ID_OFFSET_FIELDS:
                val = params.get(fld)
                if val is None:
                    continue
                try:
                    if int(val) > MAX_LSDYNA_ID:
                        return (
                            f"ID offset '{fld}'={val} exceeds LS-DYNA's 10-digit "
                            "limit. Reduce the instance count or renumber the part."
                        )
                except (ValueError, TypeError):
                    pass
        return None

    def _tree_names(self, keyword: str) -> Tuple[str, str]:
        kw = keyword.upper()
        if kw in _KEYWORD_TREE_NAMES:
            return _KEYWORD_TREE_NAMES[kw]
        # Generic fallback: GROUP = first token, KEYWORD = remainder.
        parts = kw.split("_", 1)
        return (parts[0], parts[1] if len(parts) > 1 else parts[0])

    def _resolve_main_root(self, pid: int) -> int:
        """Return the root node whose name contains 'main', creating one if absent."""
        nodes = self.project_vm.get_nodes(pid) or []
        for nid, parent_id, name in nodes:
            if parent_id is None and "main" in (name or "").lower():
                return nid
        # No main root yet -> create one.
        return self.project_vm.add_node("main", None, pid)

    def _make_array_group(self, pid: int, root_id: int, label: str) -> Tuple[int, str]:
        """Create a uniquely-named container node under ``root_id`` to hold one
        injected array. The ':' in the name keeps the node transparent to the
        exporter's keyword-name resolution (which ignores ':'-containing names),
        so the keyword tree under it still resolves correctly.

        Returns (node_id, name).
        """
        base = f"Array: {label}" if label else "Array"
        nodes = self.project_vm.get_nodes(pid) or []
        existing = {nname for _, pnode, nname in nodes if pnode == root_id}
        name = base
        k = 2
        while name in existing:
            name = f"{base} #{k}"
            k += 1
        return self.project_vm.add_node(name, root_id, pid), name

    def _get_or_create_child(self, pid: int, parent_id: int, name: str) -> int:
        """Find a direct child of ``parent_id`` named ``name``, else create it."""
        nodes = self.project_vm.get_nodes(pid) or []
        for nid, pnode, nname in nodes:
            if pnode == parent_id and nname == name:
                return nid
        return self.project_vm.add_node(name, parent_id, pid)

    def _refresh_tree(self, pid: int, select_node_id: int | None = None) -> None:
        try:
            if self.tree_vm is not None:
                # reload_structure re-syncs the parameter tabs (one per root) and
                # then refreshes the tree. A plain load_tree would refresh the
                # tree but leave a freshly-created 'main' root without its tab,
                # so its records would show no parameters.
                # select_node_id, when given, causes the tree to select that node
                # after the rebuild so the parameters panel populates immediately.
                if hasattr(self.tree_vm, "reload_structure"):
                    self.tree_vm.reload_structure(pid, select_node_id=select_node_id)
                else:
                    self.tree_vm.load_tree(pid)
        except Exception:
            logger.debug("Tree refresh after injection failed", exc_info=True)
