# FIX viewer_v2 — VTK SMP crash en modelo grande (Assembly 120-140 INCLUDE_TRANSFORM)

**Fecha:** 28 mayo 2026  
**Estado:** ✅ RESUELTO — Verificado con modelo de 140 INCLUDE_TRANSFORM (bolt_dummy × 140)  
**Módulos modificados:** `main.py`, `ui/viewer_v2_loader.py`, `ui/model_viewer_v2.py`  
**Referencia investigación:** `CRASH_viewer_v2_load_investigation_2026-05-28.md`

---

## 1. Síntoma

El viewer v2 explota (cierre inmediato del proceso, sin traceback) al abrir un modelo grande generado por el plugin `Part_Array` con 120–140 entradas `*INCLUDE_TRANSFORM`. Modelos pequeños (≤12 partes) funcionan correctamente. En un ordenador con menos cores (laptop) el modelo grande también carga sin problemas.

---

## 2. Causa raíz — tres contribuyentes

### 2.1 Cap de threads VTK SMP (causa principal)

`vtkSMPTools.Initialize(os.cpu_count())` inicializaba VTK con **12 threads** en el Xeon w3-2423. VTK STDThread backend causa `Access Violation` en el partitioning interno de `vtkSMPTools` para datasets grandes cuando se usan todos los cores. El laptop con menos cores no alcanza el umbral de la condición de carrera.

**Afecta a todas las operaciones VTK:** `extract_cells`, `extract_surface`, `extract_feature_edges`, filtros transform en `get_polydata`, etc.

> Nota: `deck.import_file()` es LS-DYNA/Fortran puro — single-threaded, sin riesgo.

### 2.2 Operaciones VTK SMP sin protección Sequential (crash secundario)

Tres funciones llamaban operaciones VTK SMP con STDThread activo sobre el polydata completo (360–420 partes):

| Función | Operación VTK | Protección anterior |
|---|---|---|
| `_add_model_mesh()` | `extract_cells()` × N_parts | ✅ tenía Sequential |
| `_rebuild_wire_overlay()` | `extract_cells` + `extract_surface` + `extract_feature_edges` | ❌ sin protección |
| `load_polydata / get_polydata()` | 140 filtros VTK transform | ❌ sin protección |

`_rebuild_wire_overlay()` se llama **siempre** durante la carga inicial porque el estilo por defecto es `"Surface+Edges"` (≠ `"Surface"`). Es la función que causaba el crash "justo al final" de abrir el modelo.

### 2.3 Race condition: `polydata.save()` vs `extract_cells()` (crash terciario)

El `LoadWorker` emite la señal `geometry_ready` y luego continúa corriendo. El hilo principal llama `extract_cells()` sobre el polydata (en `_add_model_mesh`). Simultáneamente, el `LoadWorker` llama `polydata.save()` para guardar la caché — ambos acceden al **mismo objeto VTK** desde hilos distintos. VTK no es thread-safe para acceso concurrente al mismo objeto.

---

## 3. Solución aplicada — tres capas de defensa

### Capa 1 — Cap global de threads VTK a 4 (fix principal)

**Archivos:** `main.py`, `ui/viewer_v2_loader.py` (warmup + guard en `load_polydata`)

```python
# Antes (crash con 12 cores):
vtk.vtkSMPTools.SetBackend("STDThread")
vtk.vtkSMPTools.Initialize(os.cpu_count() or 1)

# Después (safe):
vtk.vtkSMPTools.SetBackend("STDThread")
vtk.vtkSMPTools.Initialize(min(os.cpu_count() or 1, 4))
```

4 threads replica el comportamiento del laptop que no crasheaba. VTK sigue siendo multi-threaded (no Sequential) — el rendimiento se mantiene.

### Capa 2 — Sequential/STDThread toggle en operaciones VTK críticas

**Archivo:** `ui/model_viewer_v2.py`, `ui/viewer_v2_loader.py`

Patrón aplicado en `_add_model_mesh`, `_rebuild_wire_overlay` y alrededor de `get_polydata()`:

```python
_vtk_smp_reset = False
try:
    import vtk as _vtk
    if _vtk.vtkSMPTools.GetBackend() != "Sequential":
        _vtk.vtkSMPTools.SetBackend("Sequential")
        _vtk_smp_reset = True
except Exception:
    pass

try:
    # ... operaciones VTK SMP-intensivas ...
except Exception as exc:
    logger.debug("...")
finally:
    if _vtk_smp_reset:
        try:
            _vtk.vtkSMPTools.SetBackend("STDThread")
        except Exception:
            pass
```

> **Importante:** Python `try/except` NO puede capturar Access Violations nativas de C++. El `except Exception` en estas funciones protege solo de excepciones Python. La protección real es el cambio a Sequential antes de la operación.

### Capa 3 — Deep-copy del polydata antes de `polydata.save()`

**Archivo:** `ui/viewer_v2_loader.py`, función `_viewer_cache_save()`

```python
# Deep-copy antes de escribir — evita race condition con el hilo principal
try:
    save_pd = polydata.copy(deep=True)
except Exception:
    save_pd = polydata
save_pd.save(str(vtp_path))
```

---

## 4. Diagrama de fases y backend VTK

| Fase | Backend activo | Threads | Motivo |
|---|---|---|---|
| Startup warmup | STDThread | 4 | Cap global |
| `deck.import_file()` | N/A (Fortran puro) | 1 | LS-DYNA es single-threaded |
| `get_polydata()` (140 transform filters) | Sequential | 1 | Toggle explícito |
| Restore tras `get_polydata` | STDThread | 4 | Toggle explícito |
| `_add_model_mesh()` bucle `extract_cells` | Sequential | 1 | Toggle explícito |
| Restore tras loop | STDThread | 4 | Toggle explícito |
| `_rebuild_wire_overlay()` | Sequential | 1 | Toggle explícito |
| Restore tras overlay | STDThread | 4 | Toggle explícito |
| Cut Plane, Feature Edges, Normals (interactivos) | STDThread | 4 | Operaciones únicas, seguras |
| `polydata.save()` (caché) | STDThread | 4 | Deep-copy evita race condition |

---

## 5. Por qué el viewer legacy no crasheaba

1. **Carga desde caché**: El legacy viewer había guardado un `.vtp` en `%TEMP%\pydeck_viewer_cache\` en una sesión anterior. En las pruebas posteriores cargaba desde caché — nunca llamaba a `get_polydata()`, `extract_cells()`, ni `extract_feature_edges()`.
2. **Render single-mesh**: El legacy viewer añade todo el modelo con una sola llamada `plotter.add_mesh(polydata, scalars="part_ids", cmap="tab20")` — sin bucle por partes, sin `extract_cells()` por parte.

Las claves de caché son distintas entre legacy y v2 (v2 incluye `|v7` en el hash), por lo que el v2 siempre ejecutaba el pipeline completo.

---

## 6. Archivos modificados

| Archivo | Cambio |
|---|---|
| `main.py` | `Initialize(min(cpu_count, 4))` en `_viewer_warmup` |
| `ui/viewer_v2_loader.py` | Cap 4 threads en warmup + guard; Sequential toggle en `get_polydata`; deep-copy en `_viewer_cache_save` |
| `ui/model_viewer_v2.py` | Sequential toggle en `_rebuild_wire_overlay` (ya existía en `_add_model_mesh`) |

Copias de los archivos actualizados: ver `main_2026-05-28.py`, `viewer_v2_loader_2026-05-28.py`, `model_viewer_v2_2026-05-28.py` en este mismo directorio.
