# CRASH viewer_v2 — Investigación activa

**Fecha:** 28 mayo 2026  
**Estado:** ✅ CERRADO — Crash resuelto y verificado en producción  
**Módulos implicados:** `ui/viewer_v2_loader.py`, `ui/model_viewer_v2.py`  
**Referencia performance:** `PERF_vtk_smp_multithreading_2026-05-28.md`

---

## 1. Síntoma

Al abrir un modelo `main.k` en el **3D Viewer v2** la aplicación principal explota completamente (cierre inmediato, sin dialog de error, sin traceback en consola). El mismo archivo carga y muestra correctamente en el **viewer legacy**. Un PC de menor potencia trabajando sobre el **disco de sistema C:** también carga el modelo sin problema.

---

## 2. Contexto de entorno relevante

| Parámetro | Valor |
|---|---|
| Disco de trabajo actual | **E:** (disco secundario, no sistema) |
| Ruta del proyecto | `e:\USERS\U5012935_OLBEN_FALCO_SALCINES\2026\Devops\Repository\KeywordManager-deck_file_generation\` |
| Longitud de la ruta raíz | **97 caracteres** |
| PC de referencia que funciona | Trabaja sobre **C:** (disco sistema) |
| OS | Windows 10 Enterprise 10.0.19045 |
| CPU | Intel Xeon w3-2423 — 12 cores lógicos |

---

## 3. Naturaleza del crash

El crash es un cierre forzado del proceso sin excepción Python visible. Esto indica un **fallo nativo (Access Violation / segfault en código C/Fortran)** que Python no puede interceptar con `try/except`. No aparece en logs, no dispara el `_on_loaded` error handler del viewer.

Dos candidatos han sido identificados como causas raíz:

---

## 4. Hipótesis A — Buffer overflow en Fortran de PyDyna (path > 80 chars)

### Mecanismo

`ansys-dyna-core` envuelve rutinas Fortran heredadas de LS-DYNA que declaran nombres de archivo como `CHARACTER*80` (buffer fijo de 80 caracteres). Cuando se pasa un path de más de 80 chars al código Fortran:

- Si el runtime Fortran hace truncamiento silencioso: el archivo no se encuentra → excepción Python (controlable).
- Si hace una asignación directa sin verificar longitud: **desbordamiento de buffer → Access Violation → el proceso OS entero muere**.

La ruta del archivo temp escrito junto al `main.k` supera fácilmente 120 chars:
```
e:\USERS\U5012935_OLBEN_FALCO_SALCINES\...\KeywordManager-deck_file_generation\<subdir>\._mv_XXXXXXXX.tmp
= ~125 caracteres
```

Los tres puntos donde PyDyna recibe paths:
1. `deck.import_file(path)` — el path del archivo temp
2. `get_polydata(deck, cwd=cwd)` — el directorio de trabajo
3. `deck.expand(cwd=cwd, recurse=True)` — el directorio de trabajo para resolver `*INCLUDE`

### Por qué funcionan las otras configuraciones

| Configuración | Por qué funciona |
|---|---|
| **PC con C: sistema** | Ruta corta: `C:\Projects\...` ≤ 40 chars, no toca el límite |
| **Viewer legacy** | No usa PyDyna para cargar geometría — usa un parser diferente |

### Fixes aplicados (en orden)

**Fix 1 — `_win_short_path()` via `GetShortPathNameW`** (aplicado, fallido):
```python
# viewer_v2_loader.py:65
def _win_short_path(path_str: str) -> str:
    ...
    ctypes.windll.kernel32.GetShortPathNameW(path_str, buf, len(buf))
```
**Por qué falló:** La generación de nombres 8.3 está **desactivada en el volumen E:**. Cuando está desactivada, `GetShortPathNameW` devuelve el path original largo sin modificar y sin error. Resultado: mismo path de 125 chars pasado a PyDyna.

Para verificar si 8.3 está desactivado en E:
```powershell
fsutil 8dot3name query e:
# Si responde "8dot3 name creation is disabled" → confirma el diagnóstico
```

**Fix 2 — `os.chdir()` + nombre relativo** (aplicado, pendiente de validación):
```python
# viewer_v2_loader.py:873
_orig_cwd = os.getcwd()
_chdir_ok = False
try:
    os.chdir(file_path.parent)   # CWD = directorio del archivo fuente
    _chdir_ok = True
except Exception:
    pass

deck.import_file(parse_path.name)   # solo "._mv_XXXX.tmp" = < 20 chars
# ...
cwd = "." if _chdir_ok else ...     # "." = CWD ya es file_path.parent
get_polydata(deck, cwd=cwd)
deck.expand(cwd=cwd, recurse=True)
# Restaura CWD después de todas las ops PyDyna
os.chdir(_orig_cwd)
```

La lógica es correcta a nivel de Python. El chdir funciona independientemente del estado 8.3 del volumen porque los paths que ve PyDyna son solo el nombre de archivo corto y `"."`.

**Limitación potencial del Fix 2:** Si PyDyna/Fortran internamente convierte `"."` en un path absoluto llamando a `getcwd()` en C antes de pasarlo a las rutinas Fortran, el path resultante podría volver a ser largo. Esto depende de la implementación interna de `ansys-dyna-core` que no es inspeccionable sin el código fuente.

---

## 5. Hipótesis B — Crash VTK por falta de thread-safety en `_add_model_mesh()`

### Mecanismo

En la sesión de optimización de rendimiento se añadió un `ThreadPoolExecutor` a `_add_model_mesh()` para paralelizar las llamadas `extract_cells()` por part:

```python
# model_viewer_v2.py:4425
with ThreadPoolExecutor(max_workers=n_workers) as pool:
    extracted = dict(pool.map(_extract, unique_pids))
    # _extract = lambda pid: (pid, pd.extract_cells(indices_map[pid]))
```

**VTK no garantiza thread-safety para acceso concurrente al mismo `vtkDataSet` desde múltiples hilos Python.** Aunque cada llamada a `extract_cells()` crea su propio dataset de salida, internamente VTK puede usar:
- Caches de celdas en `vtkDataSet` (invalidación no atómica)
- Factories de objetos globales
- Reference counting que puede tener condiciones de carrera en algunos paths

Un crash en código nativo VTK (C++) en un hilo Python es indistinguible de un crash en PyDyna: Access Violation → cierre del proceso → sin traceback.

### Por qué el viewer legacy no crashea con esto

El viewer legacy nunca tuvo `ThreadPoolExecutor` — llama `extract_cells()` secuencialmente. El v2 sin este fix tampoco lo tenía. **Esta adición es el único cambio estructural entre el v2 previo y el estado actual que podría causar un crash nuevo independiente del problema de path.**

---

## 6. Árbol de diagnóstico — RESUELTO

```
¿Crash en C: SSD?
└── SÍ → el path NO es la causa primaria

¿Crash con modelo pequeño (12 parts)?
└── NO → crash es size-dependent

¿Portátil (menos cores) carga el modelo grande?
└── SÍ → crash es core-count-dependent

Conclusión: VTK STDThread con os.cpu_count() threads (12 en Xeon)
causa Access Violation en vtkSMPTools partitioning interno para
datasets grandes.  Modelos pequeños no activan suficiente trabajo
por thread para desencadenar la condición de carrera.
```

**Causa raíz confirmada**: VTK SMP backend `STDThread` con 12 workers causa crash nativo en el bucle per-part `extract_cells()` para modelos grandes. No es el `ThreadPoolExecutor` Python (ya revertido) sino los threads **internos de VTK C++** al procesar grandes particiones.

---

## 7. Plan de acción según resultado de la prueba en C:

### Si el crash desaparece en C: → es el path, Fix 2 no funciona del todo

El `os.chdir()` en Python no garantiza que PyDyna haga lo mismo. `get_polydata(deck, cwd=".")` podría internamente construir un path absoluto así:

```python
# posible código interno en ansys-dyna-core:
abs_cwd = os.path.abspath(cwd)  # "." → "e:\USERS\...\KeywordManager-...\subdir" → 100+ chars
# o incluso en C: os.getcwd() en el hilo antes de pasarlo a Fortran
```

**Solución propuesta si Fix 2 falla:**  
Copiar los archivos del modelo a un directorio temporal CORTO en C: antes de pasarlos a PyDyna:

```python
import tempfile, shutil

def _make_short_working_copy(file_path: Path) -> tuple[Path, Path]:
    """Copia main.k (y sus includes si los hay) a C:\Temp\pdk_XXXX\.
    Devuelve (short_dir, short_file_path). El caller es responsable de
    limpiar el directorio temporal."""
    short_base = Path(tempfile.gettempdir())  # típicamente C:\Users\...\AppData\Local\Temp
    # o forzar C:\pdk_tmp\ si %TEMP% es también largo
    tmp_dir = Path(tempfile.mkdtemp(prefix="pdk_", dir=str(short_base)))
    dst = shutil.copy2(str(file_path), str(tmp_dir / file_path.name))
    # Para ensamblajes con *INCLUDE: copiar también los archivos referenciados
    # manteniendo la estructura relativa de subdirectorios.
    return tmp_dir, Path(dst)
```

Esta solución garantiza que el path nunca supere ~60 chars independientemente del disco, porque `%TEMP%` en C: es corto.

### Si el crash persiste en C: → es VTK threading

**Solución propuesta:**  
Revertir `_add_model_mesh()` a extracción secuencial pero manteniendo la mejora de índices vectorizados (O(N log N)):

```python
# Mantener la vectorización numpy (sin ThreadPoolExecutor)
unique_pids = np.unique(part_ids_arr)
sort_idx    = np.argsort(part_ids_arr, kind="stable")
sorted_pids = part_ids_arr[sort_idx]
lo = np.searchsorted(sorted_pids, unique_pids, side="left")
hi = np.searchsorted(sorted_pids, unique_pids, side="right")

# Extracción secuencial (thread-safe, sin riesgo VTK)
for i, pid in enumerate(sorted(unique_pids)):
    sub = pd.extract_cells(sort_idx[lo[i]:hi[i]])
    if sub.n_cells == 0:
        continue
    # ... add_mesh etc. igual que antes
```

La mejora numpy (O(N log N) vs O(N×M)) sigue activa y da beneficio real para modelos con muchas partes. El paralelismo VTK viene de `vtkSMPTools.STDThread` que ya está activado y opera dentro de cada `extract_cells()` individual.

---

## 8. Estado final del código

| Archivo | Cambio | Estado |
|---|---|---|
| `ui/viewer_v2_loader.py` | `_win_short_path()` helper (fallback para 8.3) | Implementado — inofensivo |
| `ui/viewer_v2_loader.py` | `os.chdir()` + nombre relativo para PyDyna | Implementado — precaución extra ante paths largos |
| `ui/viewer_v2_loader.py` | `vtkSMPTools.SetBackend("STDThread")` warmup | Implementado ✅ |
| `ui/model_viewer_v2.py` | Índices numpy O(N log N) — vectorizado | Implementado ✅ |
| `ui/model_viewer_v2.py` | `ThreadPoolExecutor` para `extract_cells` | ❌ **REVERTIDO** — crash Python threads + VTK |
| `ui/model_viewer_v2.py` | Sequential durante bucle extract_cells, STDThread restaurado después | ✅ **Fix definitivo** |
| `main.py` | `vtkSMPTools.SetBackend("STDThread")` warmup | Implementado ✅ |

### Comportamiento del backend VTK por fase

| Fase | Backend activo | Motivo |
|---|---|---|
| `deck.import_file()` → `get_polydata()` | STDThread | PyDyna no usa vtkSMPTools aquí |
| `_add_model_mesh()` bucle extract_cells | **Sequential** | VTK C++ crash en datasets grandes con ≥12 threads |
| Cut Plane, Feature Edges, Normals | **STDThread** restaurado | Operaciones únicas sobre geometría completa, seguras |

---

## 10. Impacto y riesgo

- **Viewer legacy:** sin cambios, sin riesgo, sin impacto.
- **Export / keyword pipeline:** sin cambios, sin riesgo.
- **Crash actual:** bloquea completamente el uso del viewer v2 en la máquina de desarrollo con disco E:.
- **La corrección de rendimiento (STDThread)** del .md previo sigue siendo válida y sin riesgo — ese fix no causa crashes.
