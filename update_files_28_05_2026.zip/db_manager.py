# core/db/db_manager.py
import sqlite3
import json
import contextlib
from pathlib import Path

# ── Search-in-tree configuration ────────────────────────────────────────────
# Parameter keys that the 'Search in Tree' dialog scans for value matches.
# Restricted on purpose: node_params holds millions of mesh-data rows (nid/x/
# y/z/etc.) whose values the user never searches, so scanning them all made
# a single "bolt" search take ~50 s. Limiting the index/WHERE to a fixed set
# of "interesting" keys keeps the work to <1 % of the table and lets the
# planner use idx_np_searchable_value_v2 as an index-only scan.
#
# Two families of keys live here:
#  1. Title / heading / filename text fields — the natural search targets.
#     The option-dotted variants ("TITLE.title", "ID.heading", ...) come
#     from OptionCardSet parameters serialised as "<OPTION>.<field>".
#  2. Primary identifier fields ("pid", "mid", "secid", ...) — what the
#     tree shows in its "Info" column. The user typically also searches
#     for a part / material / section by its numeric ID. Mesh-level
#     fields (nid, eid, x, y, z, ...) are deliberately excluded because
#     they account for the vast majority of rows.
#
# IMPORTANT: this tuple MUST match exactly the WHERE clause of
# idx_np_searchable_value_v2 in SQLiteStrategy.migrate(). If either changes,
# bump the index version (drop the old one, create with a new name) — the
# planner only uses the partial index when its predicate is a superset of
# the query's filter.
SEARCHABLE_PARAM_KEYS = (
    # Title / heading text — top-level fields with varying casing
    "TITLE", "title", "HEADING", "heading", "NAME", "name",
    # Title / heading text — option-dotted variants from OptionCardSet
    "TITLE.title", "TITLE.heading",
    "ID.title", "ID.heading",
    # Filename for *INCLUDE / *INCLUDE_TRANSFORM (case variants observed
    # in the codebase: ui/tree_view.py line ~78)
    "filename", "FILENAME", "Filename", "file", "FILE",
    # Comments and original-name fallback for TABLE variants
    "__user_comment__", "__original_name__",
    # Primary identifier fields shown in the "Info" column
    "pid", "mid", "secid", "eosid", "hgid", "cid", "lcid",
    "sid", "tcid", "tmid", "nsid", "tranid",
    # Option-dotted variants — the validator (core/validators/id_validator.py)
    # picks any "ID.<x>" where <x> contains 'id', so list the common ones.
    "ID.id", "ID.pid", "ID.mid", "ID.secid", "ID.cid", "ID.lcid",
    "ID.sid", "ID.nsid", "ID.tcid", "ID.tmid",
)


class DBStrategy:
    def connect(self): ...
    def close(self): ...
    def migrate(self): ...

class SQLiteStrategy(DBStrategy):
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.conn = None
        # Batch-write support: when True, individual _commit() calls are no-ops
        # and a single commit is issued when the batch_write() context exits.
        self._suppress_commit = False

    def connect(self):
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute("PRAGMA foreign_keys = ON;")  # activar cascada
        return self.conn

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def _commit(self):
        """Issue a commit unless we are inside a batch_write() block."""
        if not self._suppress_commit:
            self.conn.commit()

    @contextlib.contextmanager
    def batch_write(self):
        """Context manager that defers all DB commits to a single commit at exit.

        Wrapping a bulk-insert loop in this context reduces per-commit disk
        syncs from N to 1, giving a proportional speedup on I/O-bound storage
        (e.g. a non-system disk where each fsync is slow).

        On exception the in-progress transaction is rolled back so the DB is
        left in the state it was before the batch started.

        Usage::

            with strategy.batch_write():
                strategy.add_node(...)
                strategy.rename_node(...)
                strategy.add_param(...)
            # Single commit happens here
        """
        self._suppress_commit = True
        try:
            yield
            self._suppress_commit = False
            self.conn.commit()
        except Exception:
            self._suppress_commit = False
            try:
                self.conn.rollback()
            except Exception:
                pass
            raise

    def migrate(self):
        import os
        cursor = self.conn.cursor()

        # Tabla de proyectos
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                user TEXT
            )
        """)
        
        # Migration: Add user column if it doesn't exist (for existing databases)
        try:
            cursor.execute("SELECT user FROM projects LIMIT 1")
        except Exception:
            cursor.execute("ALTER TABLE projects ADD COLUMN user TEXT")
            # Update existing projects with current user
            current_user = os.getenv('USERNAME', os.getenv('USER', 'Unknown'))
            cursor.execute("UPDATE projects SET user = ? WHERE user IS NULL", (current_user,))
        
        # Migration: Add updated_at column if it doesn't exist (for existing databases)
        try:
            cursor.execute("SELECT updated_at FROM projects LIMIT 1")
        except Exception:
            cursor.execute("ALTER TABLE projects ADD COLUMN updated_at TIMESTAMP")
            # Initialize updated_at to created_at for existing projects
            cursor.execute("UPDATE projects SET updated_at = created_at WHERE updated_at IS NULL")

        # Tabla de nodos (jerarquía)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS nodes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_id INTEGER NOT NULL,
                parent_id INTEGER,
                name TEXT NOT NULL,
                FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
                FOREIGN KEY(parent_id) REFERENCES nodes(id) ON DELETE CASCADE
            )
        """)

        # Tabla de parámetros asociados a un nodo
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS node_params (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                node_id INTEGER NOT NULL,
                key TEXT NOT NULL,
                value TEXT,
                FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE CASCADE,
                UNIQUE(node_id, key) ON CONFLICT REPLACE
            )
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_node_params_node_id
            ON node_params(node_id)
        """)

        # ── Search-optimisation indexes ──────────────────────────────────────
        # The 'Search in Tree' dialog hits these in sequence:
        #   1. nodes.name        — full keyword/category names ("015_JOHNSON_COOK")
        #   2. node_params.value — only for "searchable" keys (titles, headings,
        #      filenames, primary IDs). Mesh-data params (nid/x/y/z/...) make up
        #      the vast majority of node_params rows but the user never searches
        #      their values, so a *partial* index keeps the index small and the
        #      query planner can skip the full table scan.
        # idx_nodes_project_name: lets the LIKE pattern at least benefit from a
        # (project_id, name) covering scan; the COLLATE NOCASE matches the
        # query so the planner uses it.
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_nodes_project_name
            ON nodes(project_id, name COLLATE NOCASE)
        """)
        # Drop any older version of the partial index whose predicate is now
        # stale (the SEARCHABLE_PARAM_KEYS list has grown). SQLite's partial
        # indexes are only usable when their WHERE predicate is a superset of
        # the query's filter, so a predicate that's missing keys is silently
        # ignored by the planner. Using a versioned index name (`_v2`) makes
        # future changes to SEARCHABLE_PARAM_KEYS a one-line bump.
        cursor.execute("DROP INDEX IF EXISTS idx_np_searchable_value")
        cursor.execute("DROP INDEX IF EXISTS idx_np_searchable_value_v2")
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_np_searchable_value_v3
            ON node_params(value COLLATE NOCASE)
            WHERE key IN (
                'TITLE','title','HEADING','heading','NAME','name',
                'TITLE.title','TITLE.heading','ID.title','ID.heading',
                'filename','FILENAME','Filename','file','FILE',
                '__user_comment__','__original_name__',
                'pid','mid','secid','eosid','hgid','cid','lcid',
                'sid','tcid','tmid','nsid','tranid',
                'ID.id','ID.pid','ID.mid','ID.secid','ID.cid','ID.lcid',
                'ID.sid','ID.nsid','ID.tcid','ID.tmid'
            )
        """)

        # Migration: Add sort_order column if it doesn't exist (for existing databases)
        try:
            cursor.execute("SELECT sort_order FROM nodes LIMIT 1")
        except Exception:
            cursor.execute("ALTER TABLE nodes ADD COLUMN sort_order INTEGER DEFAULT 0")
            # Backfill: preserve current insertion order
            cursor.execute("UPDATE nodes SET sort_order = id WHERE sort_order = 0 OR sort_order IS NULL")

        self.conn.commit()

    # --- Proyectos ---
    def add_project(self, name: str, user: str = None):
        import os
        cursor = self.conn.cursor()
        if user is None:
            user = os.getenv('USERNAME', os.getenv('USER', 'Unknown'))
        cursor.execute("INSERT INTO projects (name, user) VALUES (?, ?)", (name, user))
        self.conn.commit()
        return cursor.lastrowid

    def get_projects(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT id, name, created_at, updated_at, user FROM projects ORDER BY updated_at DESC")
        return cursor.fetchall()
    
    def touch_project(self, project_id: int):
        """Update the updated_at timestamp for a project."""
        cursor = self.conn.cursor()
        cursor.execute(
            "UPDATE projects SET updated_at = CURRENT_TIMESTAMP WHERE id = ?",
            (project_id,)
        )
        self.conn.commit()

    def get_project_name(self, project_id: int) -> str:
        cursor = self.conn.cursor()
        cursor.execute("SELECT name FROM projects WHERE id=?", (project_id,))
        row = cursor.fetchone()
        return row[0] if row else ""

    def rename_project(self, project_id: int, new_name: str) -> bool:
        cursor = self.conn.cursor()
        cursor.execute(
            "UPDATE projects SET name=?, updated_at=CURRENT_TIMESTAMP WHERE id=?",
            (new_name, project_id)
        )
        self.conn.commit()
        return cursor.rowcount > 0

    def delete_project(self, project_id: int):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM projects WHERE id=?", (project_id,))
        self.conn.commit()

    # --- Nodos ---
    def add_node(self, project_id: int, name: str, parent_id: int = None):
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT INTO nodes (project_id, parent_id, name) VALUES (?, ?, ?)",
            (project_id, parent_id, name)
        )
        node_id = cursor.lastrowid
        # Set sort_order = id to maintain insertion order by default
        cursor.execute("UPDATE nodes SET sort_order = ? WHERE id = ?", (node_id, node_id))
        self._commit()
        return node_id

    def get_nodes(self, project_id: int):
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT id, parent_id, name FROM nodes WHERE project_id=? ORDER BY sort_order",
            (project_id,)
        )
        return cursor.fetchall()

    def move_node_up(self, node_id: int) -> bool:
        """Move a node up among its siblings by swapping sort_order with the previous sibling.
        Returns True if the node was moved, False if it's already first."""
        cursor = self.conn.cursor()
        # Get node info
        cursor.execute("SELECT parent_id, project_id, sort_order FROM nodes WHERE id=?", (node_id,))
        row = cursor.fetchone()
        if not row:
            return False
        parent_id, project_id, my_order = row

        # Find previous sibling (same parent, largest sort_order < mine)
        if parent_id is None:
            cursor.execute(
                "SELECT id, sort_order FROM nodes "
                "WHERE project_id=? AND parent_id IS NULL AND sort_order < ? "
                "ORDER BY sort_order DESC LIMIT 1",
                (project_id, my_order)
            )
        else:
            cursor.execute(
                "SELECT id, sort_order FROM nodes "
                "WHERE parent_id=? AND sort_order < ? "
                "ORDER BY sort_order DESC LIMIT 1",
                (parent_id, my_order)
            )
        prev = cursor.fetchone()
        if not prev:
            return False  # Already first

        prev_id, prev_order = prev
        # Swap sort_order values
        cursor.execute("UPDATE nodes SET sort_order=? WHERE id=?", (prev_order, node_id))
        cursor.execute("UPDATE nodes SET sort_order=? WHERE id=?", (my_order, prev_id))
        self.conn.commit()
        return True

    def delete_node(self, node_id: int):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM nodes WHERE id=?", (node_id,))
        self.conn.commit()

    def rename_node(self, node_id: int, new_name: str) -> bool:
        cursor = self.conn.cursor()
        cursor.execute("UPDATE nodes SET name=? WHERE id=?", (new_name, node_id))
        self._commit()
        return cursor.rowcount > 0

    # --- Parámetros ---
    # Campos internos que nunca deben guardarse en la DB
    # __selected_option_specs__ SÍ se permite porque es necesario para materiales
    # __nodes_dataframe__ y __elements_dataframe__ SÍ se permiten para datos tabulares
    INTERNAL_FIELDS = {"_node_type", "_original_name"}
    
    # Campos especiales que empiezan con __ pero SÍ deben guardarse
    ALLOWED_DUNDER_FIELDS = {
        "__selected_option_specs__",
        "__nodes_dataframe__",
        "__elements_dataframe__",
        "__parts_dataframe__",
        "__segments_dataframe__",
        "__transforms_dataframe__",
        "__set_nodes_list__",
        "__set_parts_list__",
        "__set_nodes_count__",
        "__set_parts_count__",
        "__segment_count__",
        "__node_count__",
        "__element_count__",
        "__parameters_series__",     # *PARAMETER keywords (legacy compat)
        "__parameters_table__",      # *PARAMETER_EXPRESSION keywords (legacy compat)
        "__parameter_count__",
        "__raw_content__",           # DEFINE_TABLE raw keyword content
        "__original_name__",         # DEFINE_TABLE original keyword name
        "__table_points__",          # DEFINE_TABLE value/lcid data
        "__user_comment__",          # Keyword comment (PyDyna user_comment)
    }

    def _is_internal_field(self, key: str) -> bool:
        """Verifica si un campo es interno y no debe guardarse."""
        # Campos específicos prohibidos
        if key in self.INTERNAL_FIELDS:
            return True
        # Campos especiales permitidos
        if key in self.ALLOWED_DUNDER_FIELDS:
            return False
        # Allow __tablecard_<prop>__ markers and __tablecard_<prop>_data__ storage
        if key.startswith('__tablecard_') and key.endswith('__'):
            return False
        # Campos que empiezan con _ son internos
        if key.startswith("_"):
            return True
        return False

    def add_param(self, node_id: int, key: str, value):
        # Filtrar campos internos
        if self._is_internal_field(key):
            return None
        # Convert DataFrame to JSON (fallback when HDF5 not available)
        if hasattr(value, 'to_json') and hasattr(value, 'columns'):
            value = value.to_json(orient='split')
        elif isinstance(value, (list, dict)):
            value = json.dumps(value)
        # Handle None value - don't convert to string "None"
        if value is None:
            value = ""
        else:
            value = str(value)
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT INTO node_params (node_id, key, value) VALUES (?, ?, ?)",
            (node_id, key, value)
        )
        self._commit()
        return cursor.lastrowid

    def upsert_param(self, node_id: int, key: str, value):
        """Inserta o actualiza un parámetro usando ON CONFLICT REPLACE."""
        # Filtrar campos internos
        if self._is_internal_field(key):
            return None
        # Convert DataFrame to JSON (fallback when HDF5 not available)
        if hasattr(value, 'to_json') and hasattr(value, 'columns'):
            value = value.to_json(orient='split')
        elif isinstance(value, (list, dict)):
            value = json.dumps(value)
        # Handle None value - don't convert to string "None"
        if value is None:
            value = ""
        else:
            value = str(value)
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT INTO node_params (node_id, key, value) VALUES (?, ?, ?) "
            "ON CONFLICT(node_id, key) DO UPDATE SET value=excluded.value",
            (node_id, key, value)
        )
        self._commit()
        return cursor.lastrowid

    def get_params(self, node_id: int) -> dict:
        cursor = self.conn.cursor()
        cursor.execute("SELECT key, value FROM node_params WHERE node_id=?", (node_id,))
        rows = cursor.fetchall()
        result = {}
        for key, value in rows:
            try:
                parsed = json.loads(value)
                result[key] = parsed
            except Exception:
                result[key] = value
        return result

    def update_param(self, node_id: int, key: str, value):
        # Filtrar campos internos
        if self._is_internal_field(key):
            return
        # Convert DataFrame to JSON (fallback when HDF5 not available)
        if hasattr(value, 'to_json') and hasattr(value, 'columns'):
            value = value.to_json(orient='split')
        elif isinstance(value, (list, dict)):
            value = json.dumps(value)
        # Handle None value - don't convert to string "None"
        if value is None:
            value = ""
        else:
            value = str(value)
        cursor = self.conn.cursor()
        cursor.execute(
            "UPDATE node_params SET value=? WHERE node_id=? AND key=?",
            (value, node_id, key)
        )
        if cursor.rowcount == 0:
            cursor.execute(
                "INSERT INTO node_params (node_id, key, value) VALUES (?, ?, ?)",
                (node_id, key, value)
            )
        self.conn.commit()

    def delete_params(self, node_id: int):
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM node_params WHERE node_id=?", (node_id,))
        self.conn.commit()

    def delete_param(self, node_id: int, key: str):
        """Elimina un parámetro individual asociado a un nodo."""
        cursor = self.conn.cursor()
        cursor.execute("DELETE FROM node_params WHERE node_id=? AND key=?", (node_id, key))
        self.conn.commit()

    def cleanup_internal_fields(self) -> int:
        """
        Elimina todos los campos internos (_node_type, _original_name, etc.) 
        de la tabla node_params. Retorna el número de registros eliminados.
        Ejecutar una vez para limpiar datos históricos.
        """
        cursor = self.conn.cursor()
        # Eliminar campos específicos conocidos
        cursor.execute(
            "DELETE FROM node_params WHERE key IN (?, ?)",
            ("_node_type", "_original_name")
        )
        count1 = cursor.rowcount
        # Eliminar cualquier otro campo que empiece con _ excepto __selected_option_specs__
        cursor.execute(
            "DELETE FROM node_params WHERE key LIKE '\\_%' ESCAPE '\\' "
            "AND key NOT LIKE '\\_\\_%' ESCAPE '\\'"
        )
        count2 = cursor.rowcount
        self.conn.commit()
        return count1 + count2

    # --- Helpers ---
    def execute_insert(self, query: str, params: tuple = ()) -> int:
        if not self.conn:
            raise RuntimeError("Database not connected")
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        self.conn.commit()
        return cursor.lastrowid

    def execute_query_one(self, query: str, params: tuple = ()):
        if not self.conn:
            raise RuntimeError("Database not connected")
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        return cursor.fetchone()

    def execute_query_all(self, query: str, params: tuple = ()):
        if not self.conn:
            raise RuntimeError("Database not connected")
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        return cursor.fetchall()

    def execute_non_query(self, query: str, params: tuple = ()):
        if not self.conn:
            raise RuntimeError("Database not connected")
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        self.conn.commit()

    # --- Batch Operations (Optimized) ---
    def add_params_batch(self, node_id: int, params: dict) -> int:
        """
        Add multiple parameters in a single transaction (much faster).
        
        Args:
            node_id: Node ID to add parameters to
            params: Dictionary of key-value pairs
            
        Returns:
            Number of parameters added
        """
        if not self.conn:
            raise RuntimeError("Database not connected")
        
        cursor = self.conn.cursor()
        count = 0
        
        # Prepare data, filtering internal fields
        data = []
        for key, value in params.items():
            if self._is_internal_field(key):
                continue
            if isinstance(value, (list, dict)):
                value = json.dumps(value)
            # Handle None value - don't convert to string "None"
            if value is None:
                value = ""
            else:
                value = str(value)
            data.append((node_id, key, value))
        
        if data:
            cursor.executemany(
                "INSERT OR REPLACE INTO node_params (node_id, key, value) VALUES (?, ?, ?)",
                data
            )
            count = len(data)
        
        self.conn.commit()
        return count

    def update_params_batch(self, node_id: int, params: dict) -> int:
        """
        Update multiple parameters in a single transaction.
        
        Args:
            node_id: Node ID
            params: Dictionary of key-value pairs to update
            
        Returns:
            Number of parameters updated
        """
        if not self.conn:
            raise RuntimeError("Database not connected")
        
        cursor = self.conn.cursor()
        count = 0
        
        for key, value in params.items():
            if self._is_internal_field(key):
                continue
            if isinstance(value, (list, dict)):
                value = json.dumps(value)
            # Handle None value - don't convert to string "None"
            if value is None:
                value = ""
            else:
                value = str(value)
            cursor.execute(
                "INSERT OR REPLACE INTO node_params (node_id, key, value) VALUES (?, ?, ?)",
                (node_id, key, value)
            )
            count += 1
        
        self.conn.commit()
        return count

    def get_nodes_with_params(self, project_id: int) -> list:
        """
        Get all nodes with their parameters in a single optimized query.
        Reduces N+1 query problem.
        
        Args:
            project_id: Project ID
            
        Returns:
            List of (node_id, parent_id, name, params_dict) tuples
        """
        if not self.conn:
            raise RuntimeError("Database not connected")
        
        cursor = self.conn.cursor()
        
        # Get all nodes
        cursor.execute(
            "SELECT id, parent_id, name FROM nodes WHERE project_id=?",
            (project_id,)
        )
        nodes = cursor.fetchall()
        
        if not nodes:
            return []
        
        # Get all params for these nodes in one query
        node_ids = [n[0] for n in nodes]
        placeholders = ','.join('?' * len(node_ids))
        
        cursor.execute(
            f"SELECT node_id, key, value FROM node_params WHERE node_id IN ({placeholders})",
            node_ids
        )
        
        # Build params dict per node
        params_by_node = {}
        for node_id, key, value in cursor.fetchall():
            if node_id not in params_by_node:
                params_by_node[node_id] = {}
            try:
                parsed = json.loads(value)
                params_by_node[node_id][key] = parsed
            except Exception:
                params_by_node[node_id][key] = value
        
        # Combine results
        result = []
        for node_id, parent_id, name in nodes:
            params = params_by_node.get(node_id, {})
            result.append((node_id, parent_id, name, params))
        
        return result

    def copy_node_with_params(self, node_id: int, new_parent_id: int = None, 
                               new_name: str = None) -> int:
        """
        Copy a node and all its parameters efficiently.
        
        Args:
            node_id: Source node ID
            new_parent_id: Parent for the new node (None = same as source)
            new_name: Name for new node (None = same as source)
            
        Returns:
            New node ID
        """
        if not self.conn:
            raise RuntimeError("Database not connected")
        
        cursor = self.conn.cursor()
        
        # Get source node
        cursor.execute(
            "SELECT project_id, parent_id, name FROM nodes WHERE id=?",
            (node_id,)
        )
        row = cursor.fetchone()
        if not row:
            raise ValueError(f"Node {node_id} not found")
        
        project_id, parent_id, name = row
        
        # Create new node
        cursor.execute(
            "INSERT INTO nodes (project_id, parent_id, name) VALUES (?, ?, ?)",
            (project_id, new_parent_id if new_parent_id is not None else parent_id,
             new_name if new_name else name)
        )
        new_node_id = cursor.lastrowid
        
        # Copy params
        cursor.execute(
            """
            INSERT INTO node_params (node_id, key, value)
            SELECT ?, key, value FROM node_params WHERE node_id=?
            """,
            (new_node_id, node_id)
        )
        
        self.conn.commit()
        return new_node_id

    # --- Limpieza ---
    def prune_orphans(self, project_id: int | None = None):
        """Elimina datos huérfanos para evitar acumulativos que no aparecen en el árbol."""
        if not self.conn:
            raise RuntimeError("Database not connected")
        cursor = self.conn.cursor()

        # 1) Eliminar parámetros cuyo node_id ya no exista
        cursor.execute("DELETE FROM node_params WHERE node_id NOT IN (SELECT id FROM nodes)")

        # 2) Eliminar nodos cuyo parent_id apunte a un nodo inexistente (si no es root)
        cursor.execute(
            "DELETE FROM nodes WHERE parent_id IS NOT NULL AND parent_id NOT IN (SELECT id FROM nodes)"
        )

        self.conn.commit()

    # --- Búsqueda ---
    def search_nodes(self, project_id: int, search_text: str, exact_match: bool = False) -> list:
        """
        Busca nodos que coincidan con el texto de búsqueda.

        Búsqueda en dos planos:
          1. ``nodes.name``  — nombre completo del nodo en el árbol.
          2. ``node_params.value`` para keys "searchable" — TITLE, heading,
             filename, __user_comment__, __original_name__. Ver la constante
             ``SEARCHABLE_PARAM_KEYS`` y el partial-index
             ``idx_np_searchable_value``: ambos deben coincidir o el planner
             no usa el índice.

        La búsqueda en ``node_params.key`` (nombre del campo) se eliminó: el
        usuario nunca busca por el nombre del parámetro (``nid``, ``pid``,
        ``mid``…), solo por su valor. Esto y la restricción de keys reduce
        el escaneo de millones de filas a unos pocos miles.

        Args:
            project_id: ID del proyecto donde buscar.
            search_text: Texto a buscar.
            exact_match: Si True, coincidencia exacta. Si False, parcial
                (contiene), siempre case-insensitive.

        Returns:
            Lista de node_ids que coinciden con la búsqueda.
        """
        if not self.conn:
            raise RuntimeError("Database not connected")
        if not search_text or not search_text.strip():
            return []

        cursor = self.conn.cursor()
        search_value = search_text.strip()

        # Build the "key IN (...)" placeholder list dynamically so we keep a
        # single source of truth (SEARCHABLE_PARAM_KEYS) for both the index
        # and the query.
        key_placeholders = ",".join("?" * len(SEARCHABLE_PARAM_KEYS))

        if exact_match:
            # ── Exact, case-insensitive ──────────────────────────────────
            cursor.execute(
                "SELECT id FROM nodes "
                "WHERE project_id = ? AND name = ? COLLATE NOCASE",
                (project_id, search_value),
            )
            node_ids = set(row[0] for row in cursor.fetchall())

            cursor.execute(
                f"SELECT np.node_id FROM node_params np "
                f"JOIN nodes n ON np.node_id = n.id "
                f"WHERE n.project_id = ? "
                f"  AND np.key IN ({key_placeholders}) "
                f"  AND np.value = ? COLLATE NOCASE",
                (project_id, *SEARCHABLE_PARAM_KEYS, search_value),
            )
            node_ids.update(row[0] for row in cursor.fetchall())
        else:
            # ── Partial (LIKE %text%), case-insensitive ──────────────────
            search_pattern = f"%{search_value}%"

            cursor.execute(
                "SELECT id FROM nodes "
                "WHERE project_id = ? AND name LIKE ? COLLATE NOCASE",
                (project_id, search_pattern),
            )
            node_ids = set(row[0] for row in cursor.fetchall())

            cursor.execute(
                f"SELECT np.node_id FROM node_params np "
                f"JOIN nodes n ON np.node_id = n.id "
                f"WHERE n.project_id = ? "
                f"  AND np.key IN ({key_placeholders}) "
                f"  AND np.value LIKE ? COLLATE NOCASE",
                (project_id, *SEARCHABLE_PARAM_KEYS, search_pattern),
            )
            node_ids.update(row[0] for row in cursor.fetchall())

        return list(node_ids)


class PostgresStrategy(DBStrategy):
    def __init__(self, uri: str):
        self.uri = uri
        self.conn = None

    def connect(self):
        pass

    def close(self):
        if self.conn:
            self.conn.close()
            self.conn = None

    def migrate(self):
        pass


class DBManager:
    def __init__(self, strategy: DBStrategy):
        self.strategy = strategy

    def start(self):
        conn = self.strategy.connect()
        self.strategy.migrate()
        return conn

    def stop(self):
        self.strategy.close()


class HybridDBManager:
    """
    Enhanced database manager with hybrid SQLite + HDF5 storage for massive data.
    
    This manager routes data to the appropriate storage backend:
    - SQLite: For metadata, small parameters, and hierarchical data
    - HDF5: For massive numerical arrays (nodes, elements, sets, curves)
    
    Usage:
        from core.db.db_manager import HybridDBManager
        
        manager = HybridDBManager("projects/myproject")
        manager.start()
        
        # Add a mesh keyword with massive data
        manager.add_keyword(project_id, parent_id, "*NODE", {
            "nodes": [[1, 0.0, 0.0, 0.0], [2, 1.0, 0.0, 0.0], ...]  # millions of rows
        })
        
        # Data is automatically routed to HDF5 for arrays
        # Query with optional memory-mapping for huge datasets
        data = manager.get_keyword_data(node_id, memory_mapped=True)
    """
    
    def __init__(self, db_path: Path, enable_hdf5: bool = True, enable_cache: bool = True):
        """
        Initialize the hybrid database manager.
        
        Args:
            db_path: Path to SQLite database
            enable_hdf5: Enable HDF5 storage for massive data (default True)
            enable_cache: Enable LRU cache for frequently accessed data (default True)
        """
        self.db_path = Path(db_path)
        self.enable_hdf5 = enable_hdf5
        self.enable_cache = enable_cache
        
        # Core SQLite strategy
        self.strategy = SQLiteStrategy(self.db_path)
        
        # Optional HDF5 manager
        self.hdf5_manager = None
        self._hdf5_available = False
        
        # Optional cache manager
        self.cache_manager = None
        self._cache_available = False
        
        self._initialized = False

    def start(self):
        """Initialize all components."""
        # Start SQLite
        conn = self.strategy.connect()
        self.strategy.migrate()
        
        # Initialize HDF5 if enabled
        if self.enable_hdf5:
            try:
                from .hdf5_manager import HDF5Manager
                hdf5_dir = self.db_path.parent / "hdf5_data"
                self.hdf5_manager = HDF5Manager(hdf5_dir)
                self._hdf5_available = True
            except ImportError:
                print("Warning: HDF5 support not available (h5py not installed)")
                self._hdf5_available = False
        
        # Initialize cache if enabled
        if self.enable_cache:
            try:
                from .cache_manager import get_cache_manager
                self.cache_manager = get_cache_manager()
                self._cache_available = True
            except ImportError:
                self._cache_available = False
        
        self._initialized = True
        return conn

    def stop(self):
        """Close all connections and flush cache."""
        if self._cache_available and self.cache_manager:
            self.cache_manager.clear_all()
        
        if self._hdf5_available and self.hdf5_manager:
            self.hdf5_manager.close_all()
        
        self.strategy.close()
        self._initialized = False

    def _should_use_hdf5(self, keyword_name: str, field_name: str, value) -> bool:
        """
        Determine if a value should be stored in HDF5.
        
        Args:
            keyword_name: LS-DYNA keyword name (e.g., "*NODE")
            field_name: Field name within the keyword
            value: The value to store
            
        Returns:
            True if value should go to HDF5
        """
        if not self._hdf5_available:
            return False
        
        # Use module-level function for routing
        try:
            from .massive_data_config import should_use_hdf5
            return should_use_hdf5(keyword_name, field_name, value)
        except ImportError:
            pass
        
        # Fallback: check if it's a large array
        if isinstance(value, (list, tuple)):
            return len(value) > 100
        return False

    def _get_cache_key(self, node_id: int, field_name: str = None) -> str:
        """Generate a cache key."""
        if field_name:
            return f"node:{node_id}:{field_name}"
        return f"node:{node_id}"

    # --- Project operations (delegated to SQLite) ---
    def add_project(self, name: str, user: str = "default") -> int:
        return self.strategy.add_project(name, user)

    def get_projects(self):
        """Get all projects."""
        return self.strategy.get_projects()

    def get_project_name(self, project_id: int) -> str:
        """Get project name by ID."""
        return self.strategy.get_project_name(project_id)
    
    def touch_project(self, project_id: int):
        """Update the updated_at timestamp for a project."""
        return self.strategy.touch_project(project_id)

    def delete_project(self, project_id: int):
        # Also clean up HDF5 data for this project
        if self._hdf5_available and self.hdf5_manager:
            self.hdf5_manager.delete_project_data(project_id)
        return self.strategy.delete_project(project_id)

    # --- Node operations ---
    def add_node(self, project_id: int, name: str, parent_id: int = None) -> int:
        """Add a node to the tree."""
        return self.strategy.add_node(project_id, name, parent_id)

    def get_nodes(self, project_id: int):
        """Get all nodes for a project."""
        return self.strategy.get_nodes(project_id)

    def delete_node(self, node_id: int):
        # Clear cache for this node
        if self._cache_available:
            self.cache_manager.invalidate_node(node_id)
        
        return self.strategy.delete_node(node_id)

    def rename_node(self, node_id: int, new_name: str) -> bool:
        """Rename a node."""
        return self.strategy.rename_node(node_id, new_name)

    # --- Parameter operations (hybrid routing) ---
    def add_param(self, node_id: int, key: str, value, keyword_name: str = None, 
                  project_id: int = None):
        """
        Add a parameter with automatic storage routing.
        
        Args:
            node_id: Node ID
            key: Parameter key
            value: Parameter value
            keyword_name: Optional keyword name for routing decisions
            project_id: Required for HDF5 storage
        """
        # Determine storage backend
        if self._should_use_hdf5(keyword_name, key, value):
            if project_id is None:
                # Need project_id for HDF5 - fallback to SQLite
                return self.strategy.add_param(node_id, key, value)
            
            # Determine data type and store in HDF5
            try:
                from .massive_data_config import get_keyword_category, get_set_type
                category = get_keyword_category(keyword_name)
                
                if category.value == "mesh" and key in ["nodes", "__nodes_dataframe__"]:
                    self.hdf5_manager.write_nodes(project_id, node_id, value)
                    ref = {"_hdf5_ref": "nodes", "_project_id": project_id, "_node_id": node_id,
                           "_count": len(value) if hasattr(value, '__len__') else 0}
                           
                elif category.value == "mesh" and key in ["elements", "__elements_dataframe__"]:
                    from .massive_data_config import get_element_type_from_keyword
                    elem_type = get_element_type_from_keyword(keyword_name)
                    self.hdf5_manager.write_elements(project_id, node_id, value, elem_type)
                    ref = {"_hdf5_ref": "elements", "_project_id": project_id, "_node_id": node_id,
                           "_elem_type": elem_type, "_count": len(value) if hasattr(value, '__len__') else 0}
                           
                elif category.value == "set":
                    set_type = get_set_type(keyword_name) or "node"
                    # For sets, extract set_id from params or use node_id as set_id
                    set_id = node_id  # Use node_id as unique identifier
                    if isinstance(value, (list, tuple)):
                        self.hdf5_manager.write_set(project_id, node_id, set_type, set_id, value)
                        ref = {"_hdf5_ref": "set", "_project_id": project_id, "_node_id": node_id,
                               "_set_type": set_type, "_set_id": set_id,
                               "_count": len(value) if hasattr(value, '__len__') else 0}
                    else:
                        return self.strategy.add_param(node_id, key, value)
                        
                elif category.value == "curve":
                    # For curves, value should be [[a1,o1], [a1,o1], ...]
                    curve_id = node_id  # Use node_id as curve_id
                    if isinstance(value, (list, tuple)) and len(value) > 0:
                        if isinstance(value[0], (list, tuple)) and len(value[0]) >= 2:
                            a1_data = [row[0] for row in value]
                            o1_data = [row[1] for row in value]
                            self.hdf5_manager.write_curve(project_id, node_id, curve_id, a1_data, o1_data)
                            ref = {"_hdf5_ref": "curve", "_project_id": project_id, "_node_id": node_id,
                                   "_curve_id": curve_id, "_count": len(value)}
                        else:
                            return self.strategy.add_param(node_id, key, value)
                    else:
                        return self.strategy.add_param(node_id, key, value)
                else:
                    # Fallback to SQLite for unknown types
                    return self.strategy.add_param(node_id, key, value)
                
                # Store reference in SQLite
                return self.strategy.add_param(node_id, key, ref)
                
            except ImportError:
                return self.strategy.add_param(node_id, key, value)
        else:
            # Store directly in SQLite
            return self.strategy.add_param(node_id, key, value)

    def get_params(self, node_id: int) -> dict:
        """Get all parameters for a node."""
        # Check cache first
        if self._cache_available:
            cached = self.cache_manager.get_params(node_id)
            if cached is not None:
                return cached
        
        params = self.strategy.get_params(node_id)
        
        # Resolve HDF5 references
        if self._hdf5_available:
            for key, value in list(params.items()):
                if isinstance(value, dict) and "_hdf5_ref" in value:
                    ref_type = value["_hdf5_ref"]
                    project_id = value.get("_project_id")
                    stored_node_id = value.get("_node_id", node_id)
                    
                    try:
                        if ref_type == "nodes":
                            params[key] = self.hdf5_manager.read_nodes(project_id, stored_node_id)
                        elif ref_type == "elements":
                            elem_type = value.get("_elem_type", "solid")
                            params[key] = self.hdf5_manager.read_elements(project_id, stored_node_id, elem_type)
                        elif ref_type == "set":
                            set_type = value.get("_set_type", "node")
                            set_id = value.get("_set_id", stored_node_id)
                            params[key] = self.hdf5_manager.read_set(project_id, set_type, set_id)
                        elif ref_type == "curve":
                            curve_id = value.get("_curve_id", stored_node_id)
                            a1, o1 = self.hdf5_manager.read_curve(project_id, curve_id)
                            # Return as list of tuples for compatibility
                            params[key] = list(zip(a1.tolist(), o1.tolist()))
                    except (KeyError, ValueError):
                        pass  # Keep the reference if can't read
        
        # Cache the result
        if self._cache_available:
            self.cache_manager.put_params(node_id, params)
        
        return params

    def update_param(self, node_id: int, key: str, value):
        """Update a parameter."""
        # Invalidate cache
        if self._cache_available:
            self.cache_manager.invalidate_node(node_id)
        
        # Use upsert which handles both insert and update
        return self.strategy.upsert_param(node_id, key, value)

    def delete_params(self, node_id: int):
        """Delete all parameters for a node."""
        # Clear cache
        if self._cache_available:
            self.cache_manager.invalidate_node(node_id)
        
        return self.strategy.delete_params(node_id)

    def delete_param(self, node_id: int, key: str):
        """Delete a single parameter."""
        # Clear cache
        if self._cache_available:
            self.cache_manager.invalidate_node(node_id)
        
        return self.strategy.delete_param(node_id, key)

    # --- Bulk operations (optimized) ---
    def add_keyword(self, project_id: int, keyword_name: str, params: dict,
                    parent_id: int = None) -> int:
        """
        Add a complete keyword with all parameters using optimized batch insert.
        
        Args:
            project_id: Project ID
            keyword_name: Keyword name (e.g., "*NODE", "*ELEMENT_SHELL")
            params: All parameters for the keyword
            parent_id: Optional parent node ID
            
        Returns:
            New node ID
        """
        # Create node
        node_id = self.strategy.add_node(project_id, keyword_name, parent_id)
        
        # Separate massive data from regular params
        regular_params = {}
        massive_params = {}
        
        for key, value in params.items():
            if self._should_use_hdf5(keyword_name, key, value):
                massive_params[key] = value
            else:
                regular_params[key] = value
        
        # Batch insert regular params to SQLite
        if regular_params:
            self.strategy.add_params_batch(node_id, regular_params)
        
        # Store massive data in HDF5
        for key, value in massive_params.items():
            self.add_param(node_id, key, value, keyword_name, project_id)
        
        return node_id

    def get_keyword_data(self, node_id: int, memory_mapped: bool = False) -> dict:
        """
        Get all data for a keyword node.
        
        Args:
            node_id: Node ID
            memory_mapped: Return HDF5 arrays as memory-mapped (for huge datasets)
                           Note: Currently not implemented, reserved for future optimization.
            
        Returns:
            Dictionary with all parameters
        """
        _ = memory_mapped  # Reserved for future HDF5 memory-mapping optimization
        return self.get_params(node_id)

    # --- Statistics and diagnostics ---
    def get_storage_stats(self) -> dict:
        """Get statistics about storage usage."""
        stats = {
            "sqlite_size_mb": self.db_path.stat().st_size / (1024 * 1024) if self.db_path.exists() else 0,
            "hdf5_available": self._hdf5_available,
            "cache_available": self._cache_available,
        }
        
        if self._cache_available and self.cache_manager:
            stats["cache_stats"] = self.cache_manager.get_stats()
        
        return stats

    def optimize(self):
        """Run optimization on all storage backends."""
        # SQLite VACUUM
        if self.strategy.conn:
            self.strategy.conn.execute("VACUUM")
        
        # Clear stale cache entries
        if self._cache_available:
            self.cache_manager.clear_all()


# End of file core/db/db_manager.py

# import sqlite3
# import json
# from pathlib import Path

# class DBStrategy:
#     def connect(self): ...
#     def close(self): ...
#     def migrate(self): ...

# class SQLiteStrategy(DBStrategy):
#     def __init__(self, db_path: Path):
#         self.db_path = db_path
#         self.conn = None

#     def connect(self):
#         self.conn = sqlite3.connect(self.db_path)
#         self.conn.execute("PRAGMA foreign_keys = ON;")  # activar cascada
#         return self.conn

#     def close(self):
#         if self.conn:
#             self.conn.close()
#             self.conn = None

#     def migrate(self):
#         cursor = self.conn.cursor()

#         # Tabla de proyectos
#         cursor.execute("""
#             CREATE TABLE IF NOT EXISTS projects (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 name TEXT NOT NULL,
#                 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
#             )
#         """)

#         # Tabla de nodos (jerarquía)
#         cursor.execute("""
#             CREATE TABLE IF NOT EXISTS nodes (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 project_id INTEGER NOT NULL,
#                 parent_id INTEGER,
#                 name TEXT NOT NULL,
#                 FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
#                 FOREIGN KEY(parent_id) REFERENCES nodes(id) ON DELETE CASCADE
#             )
#         """)

#         # Tabla de parámetros asociados a un nodo
#         cursor.execute("""
#             CREATE TABLE IF NOT EXISTS node_params (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 node_id INTEGER NOT NULL,
#                 key TEXT NOT NULL,
#                 value TEXT,
#                 FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE CASCADE,
#                 UNIQUE(node_id, key) ON CONFLICT REPLACE
#             )
#         """)

#         cursor.execute("""
#             CREATE INDEX IF NOT EXISTS idx_node_params_node_id
#             ON node_params(node_id)
#         """)

#         self.conn.commit()

#     # --- Proyectos ---
#     def add_project(self, name: str):
#         cursor = self.conn.cursor()
#         cursor.execute("INSERT INTO projects (name) VALUES (?)", (name,))
#         self.conn.commit()
#         return cursor.lastrowid

#     def get_projects(self):
#         cursor = self.conn.cursor()
#         cursor.execute("SELECT id, name, created_at FROM projects ORDER BY id DESC")
#         return cursor.fetchall()

#     def get_project_name(self, project_id: int) -> str:
#         cursor = self.conn.cursor()
#         cursor.execute("SELECT name FROM projects WHERE id=?", (project_id,))
#         row = cursor.fetchone()
#         return row[0] if row else ""

#     def rename_project(self, project_id: int, new_name: str) -> bool:
#         cursor = self.conn.cursor()
#         cursor.execute("UPDATE projects SET name=? WHERE id=?", (new_name, project_id))
#         self.conn.commit()
#         return cursor.rowcount > 0

#     def delete_project(self, project_id: int):
#         cursor = self.conn.cursor()
#         cursor.execute("DELETE FROM projects WHERE id=?", (project_id,))
#         self.conn.commit()

#     # --- Nodos ---
#     def add_node(self, project_id: int, name: str, parent_id: int = None):
#         cursor = self.conn.cursor()
#         cursor.execute(
#             "INSERT INTO nodes (project_id, parent_id, name) VALUES (?, ?, ?)",
#             (project_id, parent_id, name)
#         )
#         self.conn.commit()
#         return cursor.lastrowid

#     def get_nodes(self, project_id: int):
#         cursor = self.conn.cursor()
#         cursor.execute("SELECT id, parent_id, name FROM nodes WHERE project_id=?", (project_id,))
#         return cursor.fetchall()

#     def delete_node(self, node_id: int):
#         cursor = self.conn.cursor()
#         cursor.execute("DELETE FROM nodes WHERE id=?", (node_id,))
#         self.conn.commit()

#     def rename_node(self, node_id: int, new_name: str) -> bool:
#         cursor = self.conn.cursor()
#         cursor.execute("UPDATE nodes SET name=? WHERE id=?", (new_name, node_id))
#         self.conn.commit()
#         return cursor.rowcount > 0

#     # --- Parámetros ---
#     def add_param(self, node_id: int, key: str, value):
#         if isinstance(value, (list, dict)):
#             value = json.dumps(value)
#         cursor = self.conn.cursor()
#         cursor.execute(
#             "INSERT INTO node_params (node_id, key, value) VALUES (?, ?, ?)",
#             (node_id, key, str(value) if value is not None else "")
#         )
#         self.conn.commit()
#         return cursor.lastrowid

#     # --- Parámetros ---
#     def upsert_param(self, node_id: int, key: str, value):
#         """Inserta o actualiza un parámetro usando ON CONFLICT REPLACE."""
#         if isinstance(value, (list, dict)):
#             value = json.dumps(value)
#         cursor = self.conn.cursor()
#         cursor.execute(
#             "INSERT INTO node_params (node_id, key, value) VALUES (?, ?, ?) "
#             "ON CONFLICT(node_id, key) DO UPDATE SET value=excluded.value",
#             (node_id, key, str(value) if value is not None else "")
#         )
#         self.conn.commit()
#         return cursor.lastrowid

#     def get_params(self, node_id: int) -> dict:
#         cursor = self.conn.cursor()
#         cursor.execute("SELECT key, value FROM node_params WHERE node_id=?", (node_id,))
#         rows = cursor.fetchall()
#         result = {}
#         for key, value in rows:
#             try:
#                 parsed = json.loads(value)
#                 result[key] = parsed
#             except Exception:
#                 result[key] = value
#         return result

#     def update_param(self, node_id: int, key: str, value):
#         if isinstance(value, (list, dict)):
#             value = json.dumps(value)
#         cursor = self.conn.cursor()
#         cursor.execute(
#             "UPDATE node_params SET value=? WHERE node_id=? AND key=?",
#             (str(value) if value is not None else "", node_id, key)
#         )
#         if cursor.rowcount == 0:
#             # Si no existía, insertar
#             cursor.execute(
#                 "INSERT INTO node_params (node_id, key, value) VALUES (?, ?, ?)",
#                 (node_id, key, str(value) if value is not None else "")
#             )
#         self.conn.commit()

#     def delete_params(self, node_id: int):
#         cursor = self.conn.cursor()
#         cursor.execute("DELETE FROM node_params WHERE node_id=?", (node_id,))
#         self.conn.commit()

#     # --- Helpers ---
#     def execute_insert(self, query: str, params: tuple = ()) -> int:
#         if not self.conn:
#             raise RuntimeError("Database not connected")
#         cursor = self.conn.cursor()
#         cursor.execute(query, params)
#         self.conn.commit()
#         return cursor.lastrowid

#     def execute_query_one(self, query: str, params: tuple = ()):
#         if not self.conn:
#             raise RuntimeError("Database not connected")
#         cursor = self.conn.cursor()
#         cursor.execute(query, params)
#         return cursor.fetchone()

#     def execute_query_all(self, query: str, params: tuple = ()):
#         if not self.conn:
#             raise RuntimeError("Database not connected")
#         cursor = self.conn.cursor()
#         cursor.execute(query, params)
#         return cursor.fetchall()

#     def execute_non_query(self, query: str, params: tuple = ()):
#         if not self.conn:
#             raise RuntimeError("Database not connected")
#         cursor = self.conn.cursor()
#         cursor.execute(query, params)
#         self.conn.commit()


# class PostgresStrategy(DBStrategy):
#     def __init__(self, uri: str):
#         self.uri = uri
#         self.conn = None

#     def connect(self):
#         pass

#     def close(self):
#         if self.conn:
#             self.conn.close()
#             self.conn = None

#     def migrate(self):
#         pass


# class DBManager:
#     def __init__(self, strategy: DBStrategy):
#         self.strategy = strategy

#     def start(self):
#         conn = self.strategy.connect()
#         self.strategy.migrate()
#         return conn

#     def stop(self):
#         self.strategy.close()

# # End of file core/db/db_manager.py