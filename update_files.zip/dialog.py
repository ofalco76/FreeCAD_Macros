"""
Parts Array dialog + array geometry math.

The math (``build_circular_specs`` and helpers) is pure and Qt-free so it can
be unit-tested in isolation. The dialog collects the inputs and hands the
resulting ``KeywordSpec`` list to the host.

Transformation ordering follows the LS-DYNA manual (Vol. I, *DEFINE_TRANSFOR-
MATION): rows apply in file order, so we emit
``[MIRROR?] -> TRANSL(place) -> ROTATE(sweep) -> TRANSL(layer)?``. TRANSL must
precede ROTATE so the part is placed at the radius and then swept around the
axis (the reverse would collapse every copy onto one point).
"""

import math
import os
import sys

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QComboBox, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFileDialog, QFormLayout, QGroupBox, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QPushButton, QRadioButton, QScrollArea, QSizePolicy,
    QSpinBox, QTabWidget, QVBoxLayout, QWidget,
)

from core.tools.keyword_contract import KeywordSpec

MAX_LSDYNA_ID = 9_999_999_999
_TRANSFORM_COLS = ["option", "a1", "a2", "a3", "a4", "a5", "a6", "a7"]
_AXIS_VECTORS = {"X": (1.0, 0.0, 0.0), "Y": (0.0, 1.0, 0.0), "Z": (0.0, 0.0, 1.0)}


def _resource_img_dir():
    """Locate resources/img both in dev and in the frozen (PyInstaller) build."""
    here = os.path.dirname(os.path.abspath(__file__))
    bases = []
    if getattr(sys, "frozen", False):
        bases.append(getattr(sys, "_MEIPASS", here))
    # app root = two levels up from plugins/parts_array/
    bases.append(os.path.dirname(os.path.dirname(here)))
    for b in bases:
        d = os.path.join(b, "resources", "img")
        if os.path.isdir(d):
            return d
    return os.path.join(bases[-1], "resources", "img")


# ── pure vector helpers ──────────────────────────────────────────────────
def _sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def _dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def _scale(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def _norm(a):
    return math.sqrt(_dot(a, a))


def _unit(a):
    n = _norm(a)
    return (a[0] / n, a[1] / n, a[2] / n) if n > 1e-12 else (0.0, 0.0, 0.0)


def derived_radius(end, center, axis_vec):
    """Distance from the first-piece point to the rotation axis line."""
    d = _sub(end, center)
    axial = _dot(d, axis_vec)
    perp = (d[0] - axial * axis_vec[0], d[1] - axial * axis_vec[1], d[2] - axial * axis_vec[2])
    return _norm(perp)


# ── transform application (for the 3D preview) ────────────────────────────
def _rotate_about_axis(p, center, axis_unit, angle_deg):
    """Rotate point ``p`` by ``angle_deg`` about the line (center, axis_unit)
    using Rodrigues' formula."""
    th = math.radians(angle_deg)
    ax, ay, az = axis_unit
    vx, vy, vz = p[0] - center[0], p[1] - center[1], p[2] - center[2]
    c, s = math.cos(th), math.sin(th)
    kx = ay * vz - az * vy
    ky = az * vx - ax * vz
    kz = ax * vy - ay * vx
    kd = ax * vx + ay * vy + az * vz
    rx = vx * c + kx * s + ax * kd * (1 - c)
    ry = vy * c + ky * s + ay * kd * (1 - c)
    rz = vz * c + kz * s + az * kd * (1 - c)
    return (center[0] + rx, center[1] + ry, center[2] + rz)


def _reflect_point(p, plane_pt, normal):
    """Reflect point ``p`` about the plane through ``plane_pt`` with ``normal``."""
    n = _unit(normal)
    d = (p[0] - plane_pt[0]) * n[0] + (p[1] - plane_pt[1]) * n[1] + (p[2] - plane_pt[2]) * n[2]
    return (p[0] - 2 * d * n[0], p[1] - 2 * d * n[1], p[2] - 2 * d * n[2])


def _apply_rows_to_point(rows, p):
    """Apply transform ``rows`` ([option, a1..a7]) in file order to a 3D point."""
    x, y, z = float(p[0]), float(p[1]), float(p[2])
    for row in rows:
        opt = str(row[0]).upper()
        a = [float(v) for v in row[1:8]]
        if opt == "TRANSL":
            x, y, z = x + a[0], y + a[1], z + a[2]
        elif opt == "ROTATE":
            x, y, z = _rotate_about_axis(
                (x, y, z), (a[3], a[4], a[5]), _unit((a[0], a[1], a[2])), a[6]
            )
        elif opt == "MIRROR":
            x, y, z = _reflect_point(
                (x, y, z), (a[0], a[1], a[2]), (a[3] - a[0], a[4] - a[1], a[5] - a[2])
            )
    return (x, y, z)


def preview_points(specs, pivot, ref_vec):
    """From the generated DEFINE_TRANSFORMATION specs, return per-instance
    ``(positions, orientations)`` by applying each transform to the part pivot.

    The position is where the pivot lands; the orientation is the (normalized)
    image of ``ref_vec`` under the same transform — translations cancel, so it
    reflects only the rotation/mirror, i.e. how each copy is turned.
    """
    positions, orientations = [], []
    p_ref = (pivot[0] + ref_vec[0], pivot[1] + ref_vec[1], pivot[2] + ref_vec[2])
    for spec in specs:
        if spec.keyword != "DEFINE_TRANSFORMATION":
            continue
        rows = spec.params.get("__transforms_dataframe__", {}).get("data", [])
        p0 = _apply_rows_to_point(rows, pivot)
        p1 = _apply_rows_to_point(rows, p_ref)
        positions.append(p0)
        orientations.append(_unit(_sub(p1, p0)))
    return positions, orientations


def ring_angles(mode, count, pitch, span, closed_ring):
    """Angles (deg) of the copies in the circular ring for the chosen mode."""
    if mode == "count_pitch":
        if count < 1:
            raise ValueError("Count must be >= 1.")
        # Keep only the copies that fit within a single 360° revolution for the
        # given pitch; any extra would wrap past 360° and overlap existing ones.
        if abs(pitch) > 1e-9:
            max_fit = int((360.0 - 1e-9) / abs(pitch)) + 1
            count = min(count, max_fit)
        return [i * pitch for i in range(count)]
    if mode == "count_span":
        if count < 1:
            raise ValueError("Count must be >= 1.")
        if count == 1:
            return [0.0]
        divisor = count if closed_ring else (count - 1)
        step = span / divisor
        return [i * step for i in range(count)]
    if mode == "pitch_span":
        if abs(pitch) < 1e-9:
            raise ValueError("Pitch must be non-zero.")
        ratio = span / pitch
        if ratio < 0:
            raise ValueError(
                "In 'Pitch + Span' mode, pitch and span must have the same sign "
                "(both positive or both negative). To reverse the rotation "
                "direction, set both negative."
            )
        steps = round(ratio)
        if abs(ratio - steps) > 1e-6:
            raise ValueError("Span must be an integer multiple of the pitch.")
        full_circle = span != 0 and abs(span % 360.0) < 1e-6
        n = steps if full_circle else steps + 1
        return [i * pitch for i in range(n)]
    raise ValueError(f"Unknown ring mode: {mode}")


def _mirror_row(mirror):
    """Return the leading MIRROR transform row, or None when mirroring is off."""
    if mirror and mirror.get("enabled"):
        mp = mirror["plane_point"]
        mq = mirror["toward_point"]
        flag = 1.0 if mirror.get("mirror_csys") else 0.0
        return ["MIRROR", mp[0], mp[1], mp[2], mq[0], mq[1], mq[2], flag]
    return None


def _build_instance_specs(name_mask, instance_no, tranid, rows, part_filename, offset):
    """Build the (DEFINE_TRANSFORMATION, INCLUDE_TRANSFORM) spec pair for one
    instance from its transform ``rows`` (list of [option, a1..a7])."""
    transforms_df = {
        "columns": list(_TRANSFORM_COLS),
        "data": [[r[0]] + [float(x) for x in r[1:]] for r in rows],
    }
    define_spec = KeywordSpec(
        keyword="DEFINE_TRANSFORMATION",
        params={
            "tranid": tranid,
            # Canonical key used by the exporter and the transforms-aware paths.
            "__transforms_dataframe__": transforms_df,
            # Same rows under the generic TableCard key the parameter editor
            # reads, so the "Edit transforms" dialog shows the real rows.
            "__tablecard_transforms__": f"[{len(rows)} rows - Click to edit]",
            "__tablecard_transforms_data__": dict(transforms_df),
            # TITLE is an OptionCardSet → emits *DEFINE_TRANSFORMATION_TITLE.
            "__selected_option_specs__": ["TITLE"],
        },
        title=f"{name_mask} #{instance_no}",
    )
    include_spec = KeywordSpec(
        keyword="INCLUDE_TRANSFORM",
        params={
            "filename": part_filename,
            "idnoff": offset, "ideoff": offset, "idpoff": offset,
            "idmoff": offset, "idsoff": offset, "idfoff": offset,
            "iddoff": offset, "idroff": offset,
            "fctmas": 1.0, "fcttim": 1.0, "fctlen": 1.0,
            "fcttem": "1.0", "incout1": 1,
            "tranid": tranid,
        },
    )
    return define_spec, include_spec


def build_circular_specs(
    *,
    part_filename,
    name_mask,
    tranid_start,
    pivot,
    end,
    center,
    axis,
    ring_mode,
    count,
    pitch,
    span,
    closed_ring,
    axial_count,
    axial_spacing,
    use_director,
    director,
    mirror,
    offset_initial,
    offset_spacing,
):
    """Build the DEFINE_TRANSFORMATION + INCLUDE_TRANSFORM specs.

    Returns ``(specs, info)``. ``specs`` lists all DEFINE_TRANSFORMATION first,
    then all INCLUDE_TRANSFORM (the order the exporter writes them). ``info``
    carries derived values for the caller to display.

    ``offset_initial`` is the ID offset applied to the first instance.
    ``offset_spacing`` is the step between consecutive instances, so instance
    ``n`` (1-based) receives offset ``offset_initial + (n-1) * offset_spacing``.
    """
    if axis not in _AXIS_VECTORS:
        raise ValueError(f"Invalid axis: {axis}")
    if offset_initial <= 0:
        raise ValueError("The ID offset initial must be positive.")
    if offset_spacing <= 0:
        raise ValueError("The ID spacing offset must be positive.")

    angles = ring_angles(ring_mode, count, pitch, span, closed_ring)
    # In Count + Pitch the ring is capped to what fits in 360°; report if so.
    ring_capped_from = count if (ring_mode == "count_pitch" and len(angles) < count) else None
    n_vec = _AXIS_VECTORS[axis]
    t0 = _sub(end, pivot)                       # base placement (radial + base)
    layers = max(1, int(axial_count))
    layer_dir = _unit(director) if use_director else n_vec
    total = layers * len(angles)

    # 10-digit safety: the last instance offset must fit within LS-DYNA's limit.
    # Offset for instance n = offset_initial + n * offset_spacing (1-based),
    # so the highest offset is offset_initial + total * offset_spacing.
    if offset_initial + total * offset_spacing > MAX_LSDYNA_ID:
        raise ValueError(
            f"{total} instances with initial {offset_initial} and spacing "
            f"{offset_spacing} exceed LS-DYNA's 10-digit ID limit. "
            f"Reduce the instance count or adjust the offset values."
        )

    define_specs = []
    include_specs = []
    idx = 0
    for k in range(layers):
        layer_vec = _scale(layer_dir, k * axial_spacing)
        for theta in angles:
            tranid = tranid_start + idx
            instance_no = idx + 1

            rows = []
            mrow = _mirror_row(mirror)
            if mrow:
                rows.append(mrow)
            rows.append(["TRANSL", t0[0], t0[1], t0[2], 0.0, 0.0, 0.0, 0.0])
            rows.append(["ROTATE", n_vec[0], n_vec[1], n_vec[2],
                         center[0], center[1], center[2], float(theta)])
            if k > 0:
                rows.append(["TRANSL", layer_vec[0], layer_vec[1], layer_vec[2],
                             0.0, 0.0, 0.0, 0.0])

            d_spec, inc_spec = _build_instance_specs(
                name_mask, instance_no, tranid, rows,
                part_filename, offset_initial + instance_no * offset_spacing,
            )
            define_specs.append(d_spec)
            include_specs.append(inc_spec)
            idx += 1

    info = {
        "total": total,
        "ring_count": len(angles),
        "layers": layers,
        "last_angle": angles[-1] if angles else 0.0,
        "radius": derived_radius(end, center, n_vec),
        "max_offset": offset_initial + total * offset_spacing,
        "ring_capped_from": ring_capped_from,
    }
    return define_specs + include_specs, info


def build_rectangular_specs(
    *,
    part_filename,
    name_mask,
    tranid_start,
    pivot,
    end,
    n1,
    n2,
    s1,
    s2,
    dir1,
    dir2,
    axis,
    axial_count,
    axial_spacing,
    use_director,
    director,
    mirror,
    offset_initial,
    offset_spacing,
):
    """Build specs for a linear (grid) array along two in-plane director vectors
    plus the shared axial replication (Direction M).

    Each cell is a pure TRANSL (optionally preceded by MIRROR): the part is
    placed at ``End - Pivot`` and shifted by ``i*s1*û1 + j*s2*û2 + k*sm*ûM`` —
    no rotation. The two in-plane vectors are normalized (only direction
    matters; spacing sets the distance). The axial (M) direction is the custom
    director when ``use_director`` is set, otherwise the Rotation ``axis``.
    Total instances = n1 * n2 * M.

    ``offset_initial`` is the ID offset applied to the first instance.
    ``offset_spacing`` is the step between consecutive instances.
    """
    if offset_initial <= 0:
        raise ValueError("The ID offset initial must be positive.")
    if offset_spacing <= 0:
        raise ValueError("The ID spacing offset must be positive.")
    n1 = max(1, int(n1))
    n2 = max(1, int(n2))
    nm = max(1, int(axial_count))

    # In-plane directions with more than one copy need a usable (non-zero) vector.
    for label, n, vec in (("1", n1, dir1), ("2", n2, dir2)):
        if n > 1 and _norm(vec) < 1e-9:
            raise ValueError(
                f"Direction {label} has count {n} but a null director vector "
                f"(0,0,0). Define a direction or set its count to 1."
            )

    # Axial (M) direction: explicit director or the rotation axis.
    layer_dir = _unit(director) if use_director else _AXIS_VECTORS.get(axis)
    if nm > 1 and (layer_dir is None or _norm(layer_dir) < 1e-9):
        raise ValueError(
            "Axial replication has Count (M) > 1 but no usable direction. "
            "Enable a custom director vector or pick a Rotation axis."
        )

    total = n1 * n2 * nm
    # Offset for instance n = offset_initial + n * offset_spacing (1-based).
    if offset_initial + total * offset_spacing > MAX_LSDYNA_ID:
        raise ValueError(
            f"{total} instances with initial {offset_initial} and spacing "
            f"{offset_spacing} exceed LS-DYNA's 10-digit ID limit. "
            f"Reduce the instance count or adjust the offset values."
        )

    t0 = _sub(end, pivot)  # base placement (End - Pivot)
    u1, u2 = _unit(dir1), _unit(dir2)
    sm = axial_spacing
    define_specs = []
    include_specs = []
    idx = 0
    for k in range(nm):                       # axial layers (Direction M)
        ok = _scale(layer_dir, k * sm) if layer_dir else (0.0, 0.0, 0.0)
        for i in range(n1):
            for j in range(n2):
                tranid = tranid_start + idx
                instance_no = idx + 1

                o1 = _scale(u1, i * s1)
                o2 = _scale(u2, j * s2)
                tx = t0[0] + o1[0] + o2[0] + ok[0]
                ty = t0[1] + o1[1] + o2[1] + ok[1]
                tz = t0[2] + o1[2] + o2[2] + ok[2]

                rows = []
                mrow = _mirror_row(mirror)
                if mrow:
                    rows.append(mrow)
                rows.append(["TRANSL", tx, ty, tz, 0.0, 0.0, 0.0, 0.0])

                d_spec, inc_spec = _build_instance_specs(
                    name_mask, instance_no, tranid, rows,
                    part_filename, offset_initial + instance_no * offset_spacing,
                )
                define_specs.append(d_spec)
                include_specs.append(inc_spec)
                idx += 1

    info = {
        "total": total,
        "grid": (n1, n2, nm),
        "max_offset": offset_initial + total * offset_spacing,
    }
    return define_specs + include_specs, info


# ── dialog ────────────────────────────────────────────────────────────────
def _xyz_row(default=(0.0, 0.0, 0.0)):
    """Three compact, labelled QDoubleSpinBox in a horizontal layout — each X/Y/Z
    label sits right beside its (fixed-width) field, left-aligned, matching the
    Linear Array direction rows. Returns (layout, spins)."""
    lay = QHBoxLayout()
    lay.setContentsMargins(0, 0, 0, 0)
    spins = []
    for i, label in enumerate(("X", "Y", "Z")):
        lay.addWidget(QLabel(label))
        sp = QDoubleSpinBox()
        sp.setRange(-1.0e9, 1.0e9)
        sp.setDecimals(4)
        sp.setValue(float(default[i]))
        sp.setFixedWidth(90)
        lay.addWidget(sp)
        spins.append(sp)
    lay.addStretch(1)
    return lay, spins


class PartsArrayDialog(QDialog):
    """Dialog to configure and inject a circular or rectangular array of an imported part."""

    # Same width as the other official plugin dialogs (unit_converter,
    # velocity_calculator). The ring-mode reference image is scaled down so the
    # Pattern Array content fits this width without a horizontal scroll bar.
    DIALOG_WIDTH = 900
    DIALOG_HEIGHT = 820

    def __init__(self, parent, host):
        super().__init__(parent)
        self.host = host
        self._part_stats = None
        self.setWindowTitle("Parts Array")
        self.setFixedSize(self.DIALOG_WIDTH, self.DIALOG_HEIGHT)

        root = QVBoxLayout(self)
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_setup_tab(), "Setup")
        self.tabs.addTab(self._build_pattern_tab(), "Pattern Array")
        self.tabs.addTab(self._build_preview_tab(), "Preview")
        root.addWidget(self.tabs)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Generate")
        buttons.accepted.connect(self._on_generate)
        buttons.rejected.connect(self.reject)
        root.addWidget(buttons)

        self._update_derived_radius()
        self._update_pattern_enabled()
        self._update_pattern_image()
        # Update ring image whenever the Pattern Array tab becomes active
        # (the label only reports its real width once the tab is painted).
        self.tabs.currentChanged.connect(self._on_tab_changed)

        # Auto-adjust offset_initial whenever the total instance count or the
        # spacing changes, so the leading digit of offset_initial is always
        # preserved across all instances.
        for _sig in (
            self.count_spin.valueChanged,
            self.pitch_spin.valueChanged,
            self.span_spin.valueChanged,
            self.closed_check.stateChanged,
            self.rb_count_pitch.toggled,
            self.axial_count_spin.valueChanged,
            self.rect_dirs["1"]["count"].valueChanged,
            self.rect_dirs["2"]["count"].valueChanged,
            self.pattern_circular.toggled,
        ):
            _sig.connect(self._auto_update_initial_offset)
        self.offset_spacing_edit.textChanged.connect(self._auto_update_initial_offset)

        # Always render this dialog with the 'Modern' theme (never 'Modern
        # Header'). apply_dialog_theme hardcodes DIALOG_THEME = "Modern", so it
        # overrides whatever theme the main window is using.
        try:
            from ui.styles import apply_dialog_theme
            apply_dialog_theme(self)
        except Exception:
            pass

    # ── Tab 2: Pattern Array (Circular + Linear group boxes) ─────────────
    def _build_pattern_tab(self):
        """Single tab holding both pattern definitions, each in its own group
        box: 'Circular Array' on top and 'Linear Array' below."""
        content = QWidget()
        outer = QVBoxLayout(content)

        self._lin_group = QGroupBox("Linear Array")
        lg = QVBoxLayout(self._lin_group)
        lg.setContentsMargins(6, 6, 6, 6)
        lg.addWidget(self._build_rectangular_tab())
        outer.addWidget(self._lin_group)

        self._circ_group = QGroupBox("Circular Array")
        cg = QVBoxLayout(self._circ_group)
        cg.setContentsMargins(6, 6, 6, 6)
        cg.addWidget(self._build_circular_tab())
        outer.addWidget(self._circ_group)

        # Axial replication (Direction M) is common to both patterns.
        self._axial_group = self._build_axial_group()
        outer.addWidget(self._axial_group)

        outer.addStretch(1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(content)
        return scroll

    # ── Tab 1: Setup ─────────────────────────────────────────────────────
    def _build_setup_tab(self):
        w = QWidget()
        vbox = QVBoxLayout(w)
        form_holder = QWidget()
        form = QFormLayout(form_holder)

        file_row = QHBoxLayout()
        file_row.setContentsMargins(0, 0, 0, 0)
        self.part_edit = QLineEdit()
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._on_browse)
        file_row.addWidget(self.part_edit)
        file_row.addWidget(browse)
        form.addRow("Part file:", file_row)

        self.mask_edit = QLineEdit()
        self.mask_edit.setPlaceholderText("e.g. bolt_dummy")
        form.addRow("Name mask:", self.mask_edit)

        self.tranid_spin = QSpinBox()
        self.tranid_spin.setRange(1, 2_000_000_000)
        self.tranid_spin.setValue(1)
        self.tranid_spin.setFixedWidth(130)
        form.addRow("Transformation start ID:", self.tranid_spin)

        pivot_lay, self.pivot_spins = _xyz_row()
        form.addRow("Pivot point (P0):", pivot_lay)
        end_lay, self.end_spins = _xyz_row()
        for sp in self.end_spins:
            sp.valueChanged.connect(self._update_derived_radius)
        form.addRow("End point (P1)(1st Item):", end_lay)

        self.offset_edit = QLineEdit("1000000")
        form.addRow("ID offset initial:", self.offset_edit)

        offset_spacing_row = QHBoxLayout()
        offset_spacing_row.setContentsMargins(0, 0, 0, 0)
        self.offset_spacing_edit = QLineEdit("1000000")
        inspect = QPushButton("Inspect part")
        inspect.clicked.connect(self._on_inspect)
        offset_spacing_row.addWidget(self.offset_spacing_edit)
        offset_spacing_row.addWidget(inspect)
        form.addRow("ID spacing offset:", offset_spacing_row)

        self.inspect_label = QLabel("")
        self.inspect_label.setWordWrap(True)
        form.addRow("", self.inspect_label)

        vbox.addWidget(form_holder)

        # Mirror option — full-width, same as pattern_group below.
        self.mirror_group = QGroupBox("Mirror imported part")
        self.mirror_group.setCheckable(True)
        self.mirror_group.setChecked(False)
        mform = QFormLayout(self.mirror_group)
        mp_lay, self.mirror_plane_spins = _xyz_row()
        mq_lay, self.mirror_toward_spins = _xyz_row((1.0, 0.0, 0.0))
        mform.addRow("Plane point:", mp_lay)
        mform.addRow("Normal toward:", mq_lay)
        self.mirror_csys_check = QCheckBox("Also mirror coordinate system (a7 = 1)")
        mform.addRow("", self.mirror_csys_check)
        vbox.addWidget(self.mirror_group)

        # Pattern type — third group box: the two options stacked on the left
        # (Linear Array on top, Circular Array below), left-aligned, with the
        # matching preview image on the right. The image swaps with the
        # selection and is rescaled to fill its area on resize.
        self.pattern_group = QGroupBox("Pattern type")
        pt_lay = QHBoxLayout(self.pattern_group)

        radios_col = QVBoxLayout()
        self.pattern_rectangular = QRadioButton("Linear Array")
        self.pattern_circular = QRadioButton("Circular Array")
        self.pattern_circular.setChecked(True)
        self.pattern_circular.toggled.connect(self._on_pattern_changed)
        radios_col.addWidget(self.pattern_rectangular)
        radios_col.addWidget(self.pattern_circular)
        radios_col.addStretch(1)
        pt_lay.addLayout(radios_col)

        img_dir = _resource_img_dir()
        self._img_circular = QPixmap(os.path.join(img_dir, "circular_pattern.png"))
        self._img_linear = QPixmap(os.path.join(img_dir, "linear_pattern.png"))
        self.pattern_image = QLabel()
        self.pattern_image.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pattern_image.setMinimumHeight(240)
        self.pattern_image.setSizePolicy(
            QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding
        )
        pt_lay.addWidget(self.pattern_image, stretch=1)

        vbox.addWidget(self.pattern_group, stretch=1)

        return w

    def _on_pattern_changed(self):
        """React to the pattern-type radio: enable the matching group box and
        swap the preview image. Stays on the Setup tab (no tab jump)."""
        self._update_pattern_enabled()
        self._update_pattern_image()

    def _update_pattern_enabled(self):
        """Grey out the group box that does not match the selected pattern, so
        it is clear which one 'Generate' will use."""
        is_circular = self.pattern_circular.isChecked()
        if hasattr(self, "_circ_group"):
            self._circ_group.setEnabled(is_circular)
        if hasattr(self, "_lin_group"):
            self._lin_group.setEnabled(not is_circular)

    def _update_pattern_image(self):
        """Show the circular or linear preview, scaled to fill the label while
        keeping aspect ratio."""
        if not hasattr(self, "pattern_image"):
            return
        pm = self._img_circular if self.pattern_circular.isChecked() else self._img_linear
        if pm is None or pm.isNull():
            self.pattern_image.clear()
            return
        target = self.pattern_image.size()
        if target.width() <= 1 or target.height() <= 1:
            # Not laid out yet — scale to a sane size (never the full-resolution
            # pixmap, which would blow up the layout). showEvent/resizeEvent
            # refine to the real label area once the dialog is shown.
            self.pattern_image.setPixmap(pm.scaledToHeight(
                self.pattern_image.minimumHeight(),
                Qt.TransformationMode.SmoothTransformation,
            ))
            return
        self.pattern_image.setPixmap(pm.scaled(
            target,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        ))

    def showEvent(self, event):
        super().showEvent(event)
        self._update_pattern_image()
        # Defer ring image: the Pattern Array tab may not be visible yet at
        # show time, so the label width is still 0. Two deferred passes
        # (0 ms + 50 ms) cover both fast and slow layout passes.
        QTimer.singleShot(0,  self._update_ring_image)
        QTimer.singleShot(50, self._update_ring_image)

    def _on_tab_changed(self, index: int):
        """Pattern Array tab: rescale the ring image. Preview tab: (lazily)
        build the matplotlib canvas and render the current configuration."""
        if index == 1:  # Pattern Array tab
            QTimer.singleShot(0, self._update_ring_image)
        elif index == 2:  # Preview tab
            self._ensure_preview_canvas()
            QTimer.singleShot(0, self._refresh_preview)

    # ── Tab 3: Preview (matplotlib 3D) ───────────────────────────────────
    def _build_preview_tab(self):
        """Placeholder container; the matplotlib canvas is created lazily the
        first time the tab is shown (keeps the dialog fast to open)."""
        w = QWidget()
        self._preview_layout = QVBoxLayout(w)

        hint = QLabel(
            "3D preview of the instance positions (each marker = where the End "
            "point lands) and orientation arrows."
        )
        hint.setWordWrap(True)
        self._preview_layout.addWidget(hint)

        # ── View + Grid controls row (always visible, same style as velocity) ──
        ctrl_row = QHBoxLayout()
        ctrl_row.setContentsMargins(0, 2, 0, 2)
        ctrl_row.addWidget(QLabel("View:"))
        self._preview_view_combo = QComboBox()
        self._preview_view_combo.addItems(
            ["3D Isometric", "Top (XY)", "Front (XZ)", "Side (YZ)"]
        )
        self._preview_view_combo.setToolTip("Select view projection")
        ctrl_row.addWidget(self._preview_view_combo)
        ctrl_row.addSpacing(15)
        self._preview_grid_check = QCheckBox("Grid")
        self._preview_grid_check.setChecked(True)
        ctrl_row.addWidget(self._preview_grid_check)
        self._preview_grid_spin = QSpinBox()
        self._preview_grid_spin.setRange(2, 20)
        self._preview_grid_spin.setValue(5)
        self._preview_grid_spin.setToolTip("Grid divisions")
        self._preview_grid_spin.setFixedWidth(55)
        ctrl_row.addWidget(self._preview_grid_spin)
        ctrl_row.addSpacing(15)
        self._preview_toolbar_check = QCheckBox("Toolbar")
        self._preview_toolbar_check.setChecked(False)
        self._preview_toolbar_check.setToolTip("Show / hide the matplotlib navigation toolbar")
        ctrl_row.addWidget(self._preview_toolbar_check)
        ctrl_row.addStretch(1)
        self._preview_layout.addLayout(ctrl_row)

        self._preview_canvas = None  # built on first activation
        return w

    def _ensure_preview_canvas(self):
        if self._preview_canvas is not None:
            return
        try:
            from matplotlib.backends.backend_qtagg import FigureCanvas
            from matplotlib.figure import Figure
            import mpl_toolkits.mplot3d  # noqa: F401 (registers '3d' projection)
        except Exception as exc:  # pragma: no cover - missing matplotlib
            err = QLabel(f"Matplotlib not available: {exc}")
            err.setWordWrap(True)
            self._preview_layout.addWidget(err)
            return
        self._preview_fig = Figure(figsize=(5, 4), dpi=100)
        self._preview_canvas = FigureCanvas(self._preview_fig)
        from matplotlib.backends.backend_qtagg import NavigationToolbar2QT
        self._preview_toolbar = NavigationToolbar2QT(self._preview_canvas, self)
        self._preview_toolbar.setVisible(False)  # hidden by default
        self._preview_layout.addWidget(self._preview_toolbar)
        self._preview_layout.addWidget(self._preview_canvas, stretch=1)
        refresh = QPushButton("Refresh preview")
        refresh.clicked.connect(self._refresh_preview)
        self._preview_layout.addWidget(refresh)
        # Connect view/grid/toolbar controls now that the canvas exists.
        self._preview_view_combo.currentIndexChanged.connect(self._refresh_preview)
        self._preview_grid_check.stateChanged.connect(self._refresh_preview)
        self._preview_grid_spin.valueChanged.connect(self._refresh_preview)
        self._preview_toolbar_check.stateChanged.connect(
            lambda state: self._preview_toolbar.setVisible(bool(state))
        )

    def _refresh_preview(self):
        if self._preview_canvas is None:
            return
        view = self._preview_view_combo.currentText()
        show_grid = self._preview_grid_check.isChecked()
        divisions = self._preview_grid_spin.value()
        is_3d = (view == "3D Isometric")

        self._preview_fig.clear()
        if is_3d:
            ax = self._preview_fig.add_subplot(111, projection="3d")
        else:
            ax = self._preview_fig.add_subplot(111)

        try:
            is_circular = self.pattern_circular.isChecked()
            if is_circular:
                cfg = self._collect_circular_config()
                specs, _info = build_circular_specs(**cfg)
                axis_vec = _AXIS_VECTORS[cfg["axis"]]
                ref = (0.0, 0.0, 1.0) if cfg["axis"] != "Z" else (1.0, 0.0, 0.0)
            else:
                cfg = self._collect_rectangular_config()
                specs, _info = build_rectangular_specs(**cfg)
                axis_vec = None
                ref = (1.0, 0.0, 0.0)
            pivot = cfg["pivot"]
            positions, orientations = preview_points(specs, pivot, ref)
        except ValueError as exc:
            _kw = dict(transform=ax.transAxes, ha="center", va="center", color="#b00")
            if is_3d:
                ax.text2D(0.5, 0.5, str(exc), **_kw)
            else:
                ax.text(0.5, 0.5, str(exc), **_kw)
            self._preview_canvas.draw()
            return
        except Exception as exc:  # pragma: no cover - defensive
            msg = f"Preview error: {exc}"
            _kw = dict(transform=ax.transAxes, ha="center", va="center", color="#b00")
            if is_3d:
                ax.text2D(0.5, 0.5, msg, **_kw)
            else:
                ax.text(0.5, 0.5, msg, **_kw)
            self._preview_canvas.draw()
            return

        if not positions:
            _kw = dict(transform=ax.transAxes, ha="center", va="center")
            if is_3d:
                ax.text2D(0.5, 0.5, "No instances", **_kw)
            else:
                ax.text(0.5, 0.5, "No instances", **_kw)
            self._preview_canvas.draw()
            return

        xs = [p[0] for p in positions]
        ys = [p[1] for p in positions]
        zs = [p[2] for p in positions]
        n = len(positions)
        span = max(max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs), 1.0)

        # Interference detection.
        tol = max(1e-6, span * 0.005)
        buckets = {}
        for i, p in enumerate(positions):
            key = (round(p[0] / tol), round(p[1] / tol), round(p[2] / tol))
            buckets.setdefault(key, []).append(i)
        overlap = sorted(i for ids in buckets.values() if len(ids) > 1 for i in ids)
        title = (
            f"{n} instances \u2014 \u26a0 {len(overlap)} overlapping (yellow)"
            if overlap else f"{n} instances"
        )

        if is_3d:
            ax.grid(False)
            ax.scatter(xs, ys, zs, c="red", s=30, depthshade=True)
            if overlap:
                ax.scatter(
                    [xs[i] for i in overlap], [ys[i] for i in overlap],
                    [zs[i] for i in overlap],
                    facecolors="yellow", edgecolors="black", s=110,
                    linewidths=1.2, depthshade=False, zorder=5,
                )
            L = span * 0.08
            ax.quiver(xs, ys, zs,
                      [o[0] for o in orientations],
                      [o[1] for o in orientations],
                      [o[2] for o in orientations],
                      length=L, color="#0066cc", normalize=True, linewidth=0.8)
            if axis_vec is not None:
                c = cfg["center"]
                ax.scatter([c[0]], [c[1]], [c[2]], c="black", marker="x", s=40)
                half = span * 0.6
                ax.plot(
                    [c[0] - axis_vec[0] * half, c[0] + axis_vec[0] * half],
                    [c[1] - axis_vec[1] * half, c[1] + axis_vec[1] * half],
                    [c[2] - axis_vec[2] * half, c[2] + axis_vec[2] * half],
                    color="#888", linestyle="--", linewidth=1,
                )
            ax.set_xlabel("X", fontsize=10, color="red")
            ax.set_ylabel("Y", fontsize=10, color="green")
            ax.set_zlabel("Z", fontsize=10, color="blue")
            ax.set_title(title)
            self._set_equal_aspect(ax, xs, ys, zs)
            # Apply tick marks matching the grid divisions.
            import numpy as np
            xl = ax.get_xlim(); yl = ax.get_ylim(); zl = ax.get_zlim()
            xt = np.linspace(xl[0], xl[1], divisions + 1)
            yt = np.linspace(yl[0], yl[1], divisions + 1)
            zt = np.linspace(zl[0], zl[1], divisions + 1)
            ax.set_xticks(xt); ax.set_xticklabels([f"{v:.3g}" for v in xt], fontsize=7)
            ax.set_yticks(yt); ax.set_yticklabels([f"{v:.3g}" for v in yt], fontsize=7)
            ax.set_zticks(zt); ax.set_zticklabels([f"{v:.3g}" for v in zt], fontsize=7)
            if show_grid:
                self._draw_preview_grid(ax, xs, ys, zs, divisions)
            # Instance numbers (skip when too many to keep the plot readable).
            if n <= 200:
                off = span * 0.03
                for idx, (x, y, z) in enumerate(positions):
                    ax.text(x + off, y + off, z + off, str(idx + 1),
                            fontsize=6, color="#222", ha="left", va="bottom")
        else:
            # 2D projection
            if view == "Top (XY)":
                pa, pb = xs, ys
                la, lb = ("X", "red"), ("Y", "green")
            elif view == "Front (XZ)":
                pa, pb = xs, zs
                la, lb = ("X", "red"), ("Z", "blue")
            else:  # Side (YZ)
                pa, pb = ys, zs
                la, lb = ("Y", "green"), ("Z", "blue")

            ax.scatter(pa, pb, c="red", s=30, zorder=3)
            if overlap:
                ax.scatter(
                    [pa[i] for i in overlap], [pb[i] for i in overlap],
                    facecolors="yellow", edgecolors="black", s=110,
                    linewidths=1.2, zorder=5,
                )
            L2 = span * 0.06
            ou = [o[0] for o in orientations]
            ov = [o[1] if view != "Side (YZ)" else o[1] for o in orientations]
            if view == "Top (XY)":
                ou = [o[0] for o in orientations]
                ov = [o[1] for o in orientations]
            elif view == "Front (XZ)":
                ou = [o[0] for o in orientations]
                ov = [o[2] for o in orientations]
            else:
                ou = [o[1] for o in orientations]
                ov = [o[2] for o in orientations]
            ax.quiver(pa, pb, ou, ov, scale=1.0 / L2, scale_units="xy",
                      angles="xy", color="#0066cc", linewidth=0.8, width=0.003)
            ax.axhline(0, color="#888", linewidth=0.5, linestyle="--")
            ax.axvline(0, color="#888", linewidth=0.5, linestyle="--")
            ax.set_xlabel(la[0], fontsize=10, color=la[1], fontweight="bold")
            ax.set_ylabel(lb[0], fontsize=10, color=lb[1], fontweight="bold")
            ax.set_title(f"{title} — {view}")
            ax.set_aspect("equal", adjustable="datalim")
            # Apply tick marks matching the grid divisions.
            import numpy as np
            ax.autoscale_view()
            xl = ax.get_xlim(); yl = ax.get_ylim()
            xt = np.linspace(xl[0], xl[1], divisions + 1)
            yt = np.linspace(yl[0], yl[1], divisions + 1)
            ax.set_xticks(xt); ax.set_xticklabels([f"{v:.3g}" for v in xt], fontsize=8)
            ax.set_yticks(yt); ax.set_yticklabels([f"{v:.3g}" for v in yt], fontsize=8)
            ax.grid(show_grid, alpha=0.4, linewidth=0.7, color="#404040")
            # Instance numbers (skip when too many to keep the plot readable).
            if n <= 200:
                off = span * 0.03
                for idx, (a, b) in enumerate(zip(pa, pb)):
                    ax.text(a + off, b + off, str(idx + 1),
                            fontsize=6, color="#222", ha="left", va="bottom", zorder=6)

        import warnings
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                self._preview_fig.tight_layout(pad=0.5)
        except Exception:
            pass
        self._preview_canvas.draw()

    @staticmethod
    def _draw_preview_grid(ax, xs, ys, zs, divisions):
        """Draw a subtle 3D grid on the XY, XZ, and YZ planes, centered on the
        data and scaled to fit the scene (same style as velocity_calculator)."""
        import numpy as np
        cx = (max(xs) + min(xs)) / 2
        cy = (max(ys) + min(ys)) / 2
        cz = (max(zs) + min(zs)) / 2
        r = max(max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs), 1.0) / 2 * 1.15
        gl = np.linspace(-r, r, divisions + 1)
        kw3 = dict(linewidth=0.4)
        for v in gl:
            ax.plot([cx + v, cx + v], [cy - r, cy + r], [cz, cz], color="gray", alpha=0.15, **kw3)
            ax.plot([cx - r, cx + r], [cy + v, cy + v], [cz, cz], color="gray", alpha=0.15, **kw3)
            ax.plot([cx + v, cx + v], [cy, cy], [cz - r, cz + r], color="gray", alpha=0.10, **kw3)
            ax.plot([cx - r, cx + r], [cy, cy], [cz + v, cz + v], color="gray", alpha=0.10, **kw3)
            ax.plot([cx, cx], [cy + v, cy + v], [cz - r, cz + r], color="gray", alpha=0.10, **kw3)
            ax.plot([cx, cx], [cy - r, cy + r], [cz + v, cz + v], color="gray", alpha=0.10, **kw3)

    @staticmethod
    def _set_equal_aspect(ax, xs, ys, zs):
        """Equal aspect so circles are not distorted (matplotlib 3D needs the
        ranges set manually)."""
        try:
            ax.set_box_aspect((1, 1, 1))
        except Exception:
            pass
        cx, cy, cz = (sum(xs) / len(xs), sum(ys) / len(ys), sum(zs) / len(zs))
        r = max(
            max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs), 1.0
        ) / 2.0 * 1.1
        ax.set_xlim(cx - r, cx + r)
        ax.set_ylim(cy - r, cy + r)
        ax.set_zlim(cz - r, cz + r)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_pattern_image()
        self._update_ring_image()

    def _update_ring_image(self):
        """Rescale the ring-mode reference diagram to fit the label area
        (width × height) while keeping the aspect ratio, so the image is
        always fully visible and never clipped."""
        if not hasattr(self, "ring_mode_image") or not hasattr(self, "_ring_src"):
            return
        if self._ring_src.isNull():
            return
        w = self.ring_mode_image.width()
        h = self.ring_mode_image.height()
        if w <= 1:
            # Not laid out yet — use the fixed display height as reference
            self.ring_mode_image.setPixmap(
                self._ring_src.scaledToHeight(
                    180, Qt.TransformationMode.SmoothTransformation
                )
            )
            return
        # Scale to fill the available area while keeping aspect ratio so the
        # image is always fully visible (never overflows width or height).
        target_h = (h - 4) if h > 1 else 196
        self.ring_mode_image.setPixmap(
            self._ring_src.scaled(
                max(1, w - 4), max(1, target_h),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
        )

    # ── Tab 2: Circular ──────────────────────────────────────────────────
    def _build_circular_tab(self):
        w = QWidget()
        form = QFormLayout(w)

        center_lay, self.center_spins = _xyz_row()
        for sp in self.center_spins:
            sp.valueChanged.connect(self._update_derived_radius)
        form.addRow("Rotation center:", center_lay)

        self.axis_combo = QComboBox()
        self.axis_combo.addItems(["X", "Y", "Z"])
        self.axis_combo.currentIndexChanged.connect(self._update_derived_radius)
        form.addRow("Rotation axis:", self.axis_combo)

        self.radius_label = QLabel("0.0")
        form.addRow("Radius (derived):", self.radius_label)

        # Ring definition (radios + count/pitch/span/closed) on the left, with
        # the reference diagram of the three modes spanning the block on the right.
        self.mode_group = QButtonGroup(self)
        self.rb_count_pitch = QRadioButton("Count + Pitch")
        self.rb_count_span = QRadioButton("Count + Span")
        self.rb_pitch_span = QRadioButton("Pitch + Span")
        self.rb_count_pitch.setChecked(True)
        for rb in (self.rb_count_pitch, self.rb_count_span, self.rb_pitch_span):
            self.mode_group.addButton(rb)
            rb.toggled.connect(self._update_mode_enabled)

        ring_form = QFormLayout()
        radios = QVBoxLayout()
        radios.addWidget(self.rb_count_pitch)
        radios.addWidget(self.rb_count_span)
        radios.addWidget(self.rb_pitch_span)
        ring_form.addRow("Ring mode:", radios)

        self.count_spin = QSpinBox()
        self.count_spin.setRange(1, 100000)
        self.count_spin.setValue(12)
        self.count_spin.setFixedWidth(90)
        ring_form.addRow("Count (N):", self.count_spin)

        self.pitch_spin = QDoubleSpinBox()
        self.pitch_spin.setRange(-3600.0, 3600.0)
        self.pitch_spin.setDecimals(4)
        self.pitch_spin.setValue(30.0)
        self.pitch_spin.setFixedWidth(110)
        ring_form.addRow("Pitch angle (deg):", self.pitch_spin)

        self.span_spin = QDoubleSpinBox()
        self.span_spin.setRange(-3600.0, 3600.0)
        self.span_spin.setDecimals(4)
        self.span_spin.setValue(360.0)
        self.span_spin.setFixedWidth(110)
        ring_form.addRow("Span angle (deg):", self.span_spin)

        self.closed_check = QCheckBox("Closed ring (pitch = span / N)")
        self.closed_check.setChecked(True)
        # Span the row so the checkbox is left-aligned with the labels (not
        # indented in the field column).
        ring_form.addRow(self.closed_check)

        ring_block = QHBoxLayout()
        ring_block.addLayout(ring_form)
        ring_block.addSpacing(16)
        self._ring_src = QPixmap(os.path.join(_resource_img_dir(), "circular_pattern_option.png"))
        self.ring_mode_image = QLabel()
        self.ring_mode_image.setAlignment(
            Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft
        )
        # Ignored width policy: the label takes whatever width the layout gives
        # it (without forcing the dialog wider). With stretch=1 it fills the
        # space from the controls to the group's right edge, so its right edge
        # lines up with the Rotation axis combo. _update_ring_image rescales the
        # pixmap (aspect kept) to that width on show/resize.
        self.ring_mode_image.setSizePolicy(
            QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed
        )
        self.ring_mode_image.setFixedHeight(200)
        if not self._ring_src.isNull():
            self.ring_mode_image.setPixmap(
                self._ring_src.scaledToHeight(180, Qt.TransformationMode.SmoothTransformation)
            )
        ring_block.addWidget(self.ring_mode_image, stretch=1)
        form.addRow(ring_block)

        self._update_mode_enabled()
        return w

    def _build_axial_group(self):
        """Common 'Axial replication' group, shared by both patterns. Stacks the
        base pattern M times along the Rotation axis (chosen in the Circular
        group) or, when 'Custom director vector' is on, along an explicit
        vector. M = 1 means no replication."""
        group = QGroupBox("Axial replication")
        agrid = QFormLayout(group)

        self.axial_count_spin = QSpinBox()
        self.axial_count_spin.setRange(1, 100000)
        self.axial_count_spin.setValue(1)
        self.axial_count_spin.setFixedWidth(90)
        self.axial_count_spin.valueChanged.connect(self._update_rect_total)
        agrid.addRow("Count (M):", self.axial_count_spin)

        self.axial_spacing_spin = QDoubleSpinBox()
        self.axial_spacing_spin.setRange(-1.0e9, 1.0e9)
        self.axial_spacing_spin.setDecimals(4)
        self.axial_spacing_spin.setValue(0.0)
        self.axial_spacing_spin.setFixedWidth(110)
        agrid.addRow("Spacing:", self.axial_spacing_spin)

        self.director_check = QCheckBox("Custom director vector (else uses Rotation axis)")
        self.director_check.toggled.connect(self._update_director_enabled)
        agrid.addRow("", self.director_check)
        dir_lay, self.director_spins = _xyz_row((0.0, 0.0, 1.0))
        agrid.addRow("Director:", dir_lay)

        self._update_director_enabled()
        return group

    def _update_director_enabled(self):
        on = self.director_check.isChecked()
        for sp in self.director_spins:
            sp.setEnabled(on)

    def _build_rectangular_tab(self):
        w = QWidget()
        form = QFormLayout(w)

        info = QLabel(
            "Grid of copies by translation along two vector-defined directions. "
            "For each direction: vector (only the direction matters, it is "
            "normalized),\nnumber of copies (including the original) and spacing. "
            "Set count to 1 to skip a direction. The third (M) direction is the "
            "shared 'Axial replication' below."
        )
        info.setWordWrap(True)
        form.addRow(info)

        # Two independent in-plane directions (each = vector + count + spacing).
        # The third direction (M) is the common Axial replication group.
        self.rect_dirs = {}
        dir_defaults = {
            "1": ((1.0, 0.0, 0.0), 3, 100.0),
            "2": ((0.0, 1.0, 0.0), 3, 100.0),
        }
        for key in ("1", "2"):
            vec_default, count_default, spacing_default = dir_defaults[key]
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            vec_spins = []
            for axis_i, axis_label in enumerate(("X", "Y", "Z")):
                row.addWidget(QLabel(axis_label))
                sp = QDoubleSpinBox()
                sp.setRange(-1.0e9, 1.0e9)
                sp.setDecimals(4)
                sp.setValue(vec_default[axis_i])
                sp.setFixedWidth(90)
                row.addWidget(sp)
                vec_spins.append(sp)
            count_spin = QSpinBox()
            count_spin.setRange(1, 100000)
            count_spin.setValue(count_default)
            count_spin.setFixedWidth(90)
            spacing_spin = QDoubleSpinBox()
            spacing_spin.setRange(-1.0e9, 1.0e9)
            spacing_spin.setDecimals(4)
            spacing_spin.setValue(spacing_default)
            spacing_spin.setFixedWidth(110)
            row.addSpacing(16)
            row.addWidget(QLabel("count"))
            row.addWidget(count_spin)
            row.addSpacing(16)
            row.addWidget(QLabel("spacing"))
            row.addWidget(spacing_spin)
            # Trailing stretch absorbs the leftover width so each label sits
            # right beside its field (matches the Circular Array rows).
            row.addStretch(1)
            count_spin.valueChanged.connect(self._update_rect_total)
            self.rect_dirs[key] = {
                "vec": vec_spins, "count": count_spin, "spacing": spacing_spin,
            }
            label = "Direction M:" if key == "M" else f"Direction {key}:"
            form.addRow(label, row)

        self.rect_total_label = QLabel("")
        form.addRow("Total instances:", self.rect_total_label)
        self._update_rect_total()

        return w

    def _update_rect_total(self):
        try:
            total = 1
            for d in self.rect_dirs.values():
                total *= max(1, d["count"].value())
            # Include the shared axial replication (Direction M) if built.
            if hasattr(self, "axial_count_spin"):
                total *= max(1, self.axial_count_spin.value())
            self.rect_total_label.setText(str(total))
        except Exception:
            pass

    # ── interactions ─────────────────────────────────────────────────────
    def _on_browse(self):
        start = self.host.active_project_dir() or ""
        path, _ = QFileDialog.getOpenFileName(
            self, "Select part file", start,
            "LS-DYNA keyword files (*.k *.key *.dyn);;All files (*)",
        )
        if path:
            self.part_edit.setText(path)
            if not self.mask_edit.text().strip():
                self.mask_edit.setText(os.path.splitext(os.path.basename(path))[0])

    def _on_inspect(self):
        path = self.part_edit.text().strip()
        if not path:
            QMessageBox.information(self, "Inspect part", "Select a part file first.")
            return
        stats = self.host.inspect_part_file(path)
        self._part_stats = stats
        if stats.max_id <= 0:
            self.inspect_label.setText("No nodes/elements found in the file.")
            QTimer.singleShot(0,  self._update_pattern_image)
            QTimer.singleShot(50, self._update_pattern_image)
            return
        block = 10 ** len(str(stats.max_id))
        self.offset_spacing_edit.setText(str(block))

        # If the suggested spacing >= the current initial offset the leading
        # digits of offset_initial would be lost in the first instance already.
        # Bump offset_initial by one order of magnitude at a time until it is
        # strictly greater than the spacing, guaranteeing the prefix is
        # preserved and there is no overlap between consecutive instances.
        initial_bumped = False
        try:
            current_initial = int(self.offset_edit.text().strip())
        except ValueError:
            current_initial = block
        if block >= current_initial:
            new_initial = current_initial
            while new_initial <= block:
                new_initial *= 10
            self.offset_edit.setText(str(new_initial))
            initial_bumped = True

        msg = (
            f"Nodes: {stats.node_count} (min {stats.min_node}, max {stats.max_node}) · "
            f"Elements: {stats.element_count} (min {stats.min_element}, max {stats.max_element}). "
            f"Suggested ID spacing offset: {block}."
        )
        if initial_bumped:
            msg += (
                f"  ⚠ Spacing ({block:,}) ≥ initial offset — "
                f"initial offset automatically increased to {int(self.offset_edit.text()):,} "
                f"to preserve the ID prefix and avoid overlaps."
            )
        if not stats.starts_at_one:
            msg += ("  ⚠ Numbering does not start at 1 — renumbering the part "
                    "is recommended for more reliable ID control.")
        self.inspect_label.setText(msg)
        # The inspect label may have changed height; defer image rescale so Qt
        # has finished the layout pass before we query the label's new size.
        QTimer.singleShot(0,  self._update_pattern_image)
        QTimer.singleShot(50, self._update_pattern_image)

    def _update_mode_enabled(self):
        count_pitch = self.rb_count_pitch.isChecked()
        count_span = self.rb_count_span.isChecked()
        pitch_span = self.rb_pitch_span.isChecked()
        self.count_spin.setEnabled(count_pitch or count_span)
        self.pitch_spin.setEnabled(count_pitch or pitch_span)
        self.span_spin.setEnabled(count_span or pitch_span)
        self.closed_check.setEnabled(count_span)

    def _update_derived_radius(self):
        try:
            end = tuple(sp.value() for sp in self.end_spins)
            center = tuple(sp.value() for sp in self.center_spins)
            axis_vec = _AXIS_VECTORS[self.axis_combo.currentText()]
            self.radius_label.setText(f"{derived_radius(end, center, axis_vec):.4f}")
        except Exception:
            pass

    # ── generate ─────────────────────────────────────────────────────────
    def _collect_setup(self):
        """Common Tab 1 (Setup) fields shared by both pattern types."""
        part_path = self.part_edit.text().strip()
        if not part_path:
            raise ValueError("Select a part file.")
        mask = self.mask_edit.text().strip() or os.path.splitext(os.path.basename(part_path))[0]
        try:
            offset_initial = int(self.offset_edit.text().strip())
        except ValueError:
            raise ValueError("The ID offset initial must be an integer.")
        try:
            offset_spacing = int(self.offset_spacing_edit.text().strip())
        except ValueError:
            raise ValueError("The ID spacing offset must be an integer.")

        mirror = {
            "enabled": self.mirror_group.isChecked(),
            "plane_point": tuple(sp.value() for sp in self.mirror_plane_spins),
            "toward_point": tuple(sp.value() for sp in self.mirror_toward_spins),
            "mirror_csys": self.mirror_csys_check.isChecked(),
        }
        return dict(
            part_filename=os.path.basename(part_path),
            name_mask=mask,
            tranid_start=self.tranid_spin.value(),
            pivot=tuple(sp.value() for sp in self.pivot_spins),
            end=tuple(sp.value() for sp in self.end_spins),
            mirror=mirror,
            offset_initial=offset_initial,
            offset_spacing=offset_spacing,
        )

    def _collect_circular_config(self):
        if self.rb_count_pitch.isChecked():
            mode = "count_pitch"
        elif self.rb_count_span.isChecked():
            mode = "count_span"
        else:
            mode = "pitch_span"
        cfg = self._collect_setup()
        cfg.update(
            center=tuple(sp.value() for sp in self.center_spins),
            axis=self.axis_combo.currentText(),
            ring_mode=mode,
            count=self.count_spin.value(),
            pitch=self.pitch_spin.value(),
            span=self.span_spin.value(),
            closed_ring=self.closed_check.isChecked(),
            axial_count=self.axial_count_spin.value(),
            axial_spacing=self.axial_spacing_spin.value(),
            use_director=self.director_check.isChecked(),
            director=tuple(sp.value() for sp in self.director_spins),
        )
        return cfg

    def _collect_rectangular_config(self):
        def vec(key):
            return tuple(sp.value() for sp in self.rect_dirs[key]["vec"])
        cfg = self._collect_setup()
        cfg.update(
            n1=self.rect_dirs["1"]["count"].value(),
            n2=self.rect_dirs["2"]["count"].value(),
            s1=self.rect_dirs["1"]["spacing"].value(),
            s2=self.rect_dirs["2"]["spacing"].value(),
            dir1=vec("1"),
            dir2=vec("2"),
            # Shared axial replication (Direction M).
            axis=self.axis_combo.currentText(),
            axial_count=self.axial_count_spin.value(),
            axial_spacing=self.axial_spacing_spin.value(),
            use_director=self.director_check.isChecked(),
            director=tuple(sp.value() for sp in self.director_spins),
        )
        return cfg

    def _build_id_summary(self, cfg, info):
        """Human-readable summary of tranids, ID offsets and part ID ranges,
        shown for confirmation before injecting."""
        total = info["total"]
        start = cfg["tranid_start"]
        initial = cfg["offset_initial"]
        spacing = cfg["offset_spacing"]
        last_offset = initial + total * spacing
        lines = [
            f"Instances: {total}",
            f"Transformation IDs (tranid): {start} … {start + total - 1}",
            f"ID offset initial: {initial:,},  spacing: {spacing:,}  →  offsets {initial + spacing:,} … {last_offset:,}",
        ]
        stats = self._part_stats
        if stats is not None and stats.max_id > 0:
            highest = last_offset + stats.max_id
            lines.append(
                f"Part IDs — nodes {stats.min_node}…{stats.max_node}, "
                f"elements {stats.min_element}…{stats.max_element}"
            )
            lines.append(f"Highest resulting ID ≈ {highest:,} (limit 9,999,999,999)")
            if not stats.starts_at_one:
                lines.append("⚠ Part numbering does not start at 1 — renumber recommended.")
            if spacing <= stats.max_id:
                lines.append("⚠ ID spacing ≤ part max ID — IDs may collide!")
        else:
            lines.append("⚠ Part not inspected — offsets not checked against the "
                         "part's IDs. Use 'Inspect part' in Setup.")
        return "\n".join(lines)

    def _maybe_copy_part_file(self):
        """Offer to copy the selected part next to the main deck, since the
        INCLUDE_TRANSFORM references it by file name (resolved relative to the
        main deck by LS-DYNA)."""
        src = self.part_edit.text().strip()
        if not src or not os.path.isfile(src):
            return
        dest_dir = self.host.active_project_dir()
        if not dest_dir or not os.path.isdir(dest_dir):
            return
        dest = os.path.join(dest_dir, os.path.basename(src))
        if os.path.abspath(src) == os.path.abspath(dest) or os.path.isfile(dest):
            return  # already alongside the deck
        ans = QMessageBox.question(
            self, "Copy part file",
            f"INCLUDE_TRANSFORM references '{os.path.basename(src)}' by name, "
            f"resolved relative to the main deck.\n\n"
            f"Copy the part file into the project folder?\n{dest_dir}",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
        )
        if ans == QMessageBox.Yes:
            try:
                import shutil
                shutil.copy2(src, dest)
            except Exception as exc:
                QMessageBox.warning(self, "Copy part file", f"Could not copy: {exc}")

    def _compute_total_from_ui(self) -> int:
        """Return the current total instance count directly from the UI widgets.
        Used to keep offset_initial in sync as the user edits the form.
        """
        axial = max(1, self.axial_count_spin.value())
        if self.pattern_circular.isChecked():
            if self.rb_count_pitch.isChecked():
                mode = "count_pitch"
            elif self.rb_count_span.isChecked():
                mode = "count_span"
            else:
                mode = "pitch_span"
            angles = ring_angles(
                mode,
                self.count_spin.value(),
                self.pitch_spin.value(),
                self.span_spin.value(),
                self.closed_check.isChecked(),
            )
            return max(1, len(angles)) * axial
        else:
            n1 = max(1, self.rect_dirs["1"]["count"].value())
            n2 = max(1, self.rect_dirs["2"]["count"].value())
            return n1 * n2 * axial

    def _auto_update_initial_offset(self, *_):
        """Live-update offset_initial so its leading digit is never altered by
        any instance offset.  Called whenever a count, mode, or spacing widget
        changes.  Always tracks the minimum safe power of 10 — reduces as well
        as increases when the total instance count changes.  Silent: only
        updates the field, no dialog.
        """
        try:
            spacing = int(self.offset_spacing_edit.text().strip())
            if spacing <= 0:
                return
            total = self._compute_total_from_ui()
        except (ValueError, AttributeError):
            return
        # Minimum safe power of 10: offset_initial > total * spacing.
        new_initial = 1
        while new_initial <= total * spacing:
            new_initial *= 10
        try:
            current = int(self.offset_edit.text().strip())
        except ValueError:
            current = None
        if new_initial != current:
            self.offset_edit.setText(str(new_initial))

    def _ensure_initial_prefix_safe(self, total: int):
        """Guarantee that none of the instance offsets change the leading digit
        of offset_initial.

        The safe condition is ``offset_initial > total * offset_spacing``:
        when this holds the last offset is ``offset_initial + total*spacing
        < 2 * offset_initial``, and because offset_initial is (or becomes) a
        power of 10 every resulting offset still starts with the same digit.

        If the condition fails, offset_initial is raised to the smallest power
        of 10 strictly greater than ``total * offset_spacing`` and the UI
        field is updated immediately.

        Returns ``(adjusted, old_initial, new_initial)``.
        """
        try:
            initial = int(self.offset_edit.text().strip())
            spacing = int(self.offset_spacing_edit.text().strip())
        except ValueError:
            return False, 0, 0
        if initial > total * spacing:
            return False, initial, initial   # already safe
        # Find smallest power of 10 strictly greater than total * spacing.
        new_initial = 1
        while new_initial <= total * spacing:
            new_initial *= 10
        self.offset_edit.setText(str(new_initial))
        return True, initial, new_initial

    def _on_generate(self):
        is_circular = self.pattern_circular.isChecked()
        try:
            if is_circular:
                cfg = self._collect_circular_config()
                specs, info = build_circular_specs(**cfg)
            else:
                cfg = self._collect_rectangular_config()
                specs, info = build_rectangular_specs(**cfg)
        except ValueError as exc:
            QMessageBox.warning(self, "Parts Array", str(exc))
            return
        except Exception as exc:  # pragma: no cover - defensive
            QMessageBox.critical(self, "Parts Array", f"Unexpected error: {exc}")
            return

        # Ensure offset_initial preserves its leading digit across all
        # instances (including axial replication). If the current value would
        # cause the prefix to change, bump it to the safe power of 10 and
        # rebuild the specs with the corrected value.
        adjusted, old_initial, new_initial = self._ensure_initial_prefix_safe(info["total"])
        if adjusted:
            try:
                if is_circular:
                    cfg = self._collect_circular_config()
                    specs, info = build_circular_specs(**cfg)
                else:
                    cfg = self._collect_rectangular_config()
                    specs, info = build_rectangular_specs(**cfg)
            except ValueError as exc:
                QMessageBox.warning(self, "Parts Array", str(exc))
                return

        # ID summary + confirmation before injecting.
        summary = self._build_id_summary(cfg, info)
        if adjusted:
            summary = (
                f"⚠ ID offset initial automatically adjusted: {old_initial:,} → {new_initial:,}\n"
                f"   ({info['total']} items × spacing {cfg['offset_spacing']:,} would have "
                f"changed the leading digit of the initial offset.)\n\n"
            ) + summary
        if QMessageBox.question(
            self, "Parts Array — confirm",
            f"About to inject this array:\n\n{summary}\n\nProceed?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
        ) != QMessageBox.Yes:
            return

        # Offer to place the part file next to the main deck.
        self._maybe_copy_part_file()

        result = self.host.apply_keywords(specs, group_label=None)
        if not result.success:
            QMessageBox.warning(self, "Parts Array", result.message)
            return

        if is_circular:
            cap_note = ""
            capped = info.get("ring_capped_from")
            if capped:
                cap_note = (
                    f"\n\n⚠ Count reduced from {capped} to {info['ring_count']}: "
                    f"only {info['ring_count']} copies fit in 360° at that pitch."
                )
            detail = (
                f"Instances: {info['total']} "
                f"(ring {info['ring_count']} × layers {info['layers']})\n"
                f"Radius: {info['radius']:.4f} · Last angle: {info['last_angle']:.2f}°"
                f"{cap_note}"
            )
        else:
            gx, gy, gz = info["grid"]
            detail = f"Instances: {info['total']}  (grid {gx} × {gy} × {gz})"

        QMessageBox.information(self, "Parts Array", f"{result.message}\n\n{detail}")
        self.accept()
