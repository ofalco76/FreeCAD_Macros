# ui/tree_view.py
from PySide6.QtWidgets import (
    QWidget, QTreeWidget, QTreeWidgetItem, QTableWidgetItem, QListWidgetItem,
    QToolBar, QVBoxLayout, QInputDialog, QMessageBox, QComboBox, QHBoxLayout, QLabel,
    QCheckBox, QLineEdit, QDialog, QDialogButtonBox, QPushButton,
)
from PySide6.QtGui import QAction, QIcon, QPainter, QPen, QColor, QPolygon, QFont, QBrush, QLinearGradient
from PySide6.QtCore import Qt, Signal, QPoint, QRect, QSize

from ui.styles import TOOLBAR_STYLE, TREE_STYLES, get_tree_style, TREE_STYLE_MODERN_HEADER, get_resource_path, apply_dialog_theme
from ui.keywords_view import KeywordsView
from core.validators.id_validator import get_duplicate_validator
from core.adapters import pydyna
import json

def get_record_info(params: dict) -> str:
    """
    Get info string for a record node (id_value + title/heading).
    Used for the Info column in the tree view.
    
    Format: "<id_field>=<id_value> | <title/heading>"
    Examples:
        - "mid=5 | Steel Material"
        - "id=10 | Aluminum"
        - "pid=3"
    
    Args:
        params: Dictionary of parameter name -> value
        
    Returns:
        Info string for the record (empty string if no info available)
    """
    if not params:
        return ""
    
    def is_valid_value(val) -> bool:
        """Check if value is valid (not None, not 'None' string, not empty)."""
        if val is None:
            return False
        str_val = str(val).strip().lower()
        return str_val and str_val != 'none'
    
    parts = []
    
    # Get the primary ID field value using validator logic
    validator = get_duplicate_validator()
    primary_field, primary_value = validator.get_primary_id_from_params(params)
    
    # Only add ID info if both field and value exist and value is valid
    if primary_field and is_valid_value(primary_value):
        # Simplify field name for display (e.g., "ID.id" -> "id", "mid" -> "mid")
        display_field = primary_field.split('.')[-1] if '.' in primary_field else primary_field
        parts.append(f"{display_field}={primary_value}")
    
    # Look for title/heading in params
    title = None
    # Check OptionCardSet title fields first
    for key in ['ID.heading', 'TITLE.heading', 'TITLE.title', 'ID.title']:
        if key in params and is_valid_value(params.get(key)):
            title = str(params[key]).strip()
            break
    
    # Check regular title/heading fields
    if not title:
        for key in ['heading', 'title', 'name', 'HEADING', 'TITLE', 'NAME']:
            if key in params and is_valid_value(params.get(key)):
                title = str(params[key]).strip()
                break
    
    if title:
        # Truncate long titles
        if len(title) > 40:
            title = title[:37] + "..."
        parts.append(title)
    
    # Look for filename parameter (for INCLUDE keywords, etc.)
    filename = None
    for key in ['filename', 'FILENAME', 'Filename', 'file', 'FILE']:
        if key in params and is_valid_value(params.get(key)):
            filename = str(params[key]).strip()
            break
    
    if filename:
        # Truncate long filenames, show only the basename if too long
        if len(filename) > 50:
            # Try to show just the filename without full path
            import os
            basename = os.path.basename(filename)
            if len(basename) <= 50:
                filename = basename
            else:
                filename = basename[:47] + "..."
        parts.append(filename)

    # For PARAMETER keywords: show first prmr1 (name) and val1 (value) from the tablecard
    if not parts and '__tablecard_parameters_data__' in params:
        try:
            import json as _json
            raw = params['__tablecard_parameters_data__']
            # get_params auto-parses JSON strings to dicts; handle both cases
            tc = raw if isinstance(raw, dict) else _json.loads(raw)
            cols = tc.get('columns', [])
            data = tc.get('data', [])
            if data and cols:
                row = dict(zip(cols, data[0]))
                prmr = str(row.get('prmr1', row.get('prmr', ''))).strip()
                val  = str(row.get('val1',  row.get('val',  ''))).strip()
                if is_valid_value(prmr):
                    parts.append(prmr)
                if is_valid_value(val):
                    parts.append(val)
        except Exception:
            pass

    return " | ".join(parts)


class StyledTreeWidget(QTreeWidget):
    """
    Custom QTreeWidget that draws branch indicators programmatically.
    Supports different styles: arrows, plusminus, or default system style.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.indicator_style = "default"  # "default", "arrows", "plusminus"
        self.indicator_color = QColor("#606060")
        self.line_color = QColor("#a0a0a0")
        self.draw_lines = True
        self.dark_mode = False
        
    def set_indicator_style(self, style: str, dark_mode: bool = False):
        """Set the branch indicator style."""
        self.indicator_style = style
        self.dark_mode = dark_mode
        if dark_mode:
            self.indicator_color = QColor("#b0b0b0")
            self.line_color = QColor("#606060")
        else:
            self.indicator_color = QColor("#505050")
            self.line_color = QColor("#c0c0c0")
        self.viewport().update()
    
    def drawBranches(self, painter: QPainter, rect: QRect, index):
        """Override to draw custom branch indicators."""
        if self.indicator_style == "default":
            # Use default Qt rendering
            super().drawBranches(painter, rect, index)
            return
        
        item = self.itemFromIndex(index)
        if not item:
            super().drawBranches(painter, rect, index)
            return
        
        # Draw connection lines if enabled
        if self.draw_lines:
            self._draw_branch_lines(painter, rect, index)
        
        # Draw expand/collapse indicator if item has children
        if item.childCount() > 0:
            self._draw_indicator(painter, rect, item.isExpanded())
        
    def _draw_branch_lines(self, painter: QPainter, rect: QRect, index):
        """Draw the branch connection lines."""
        painter.save()
        pen = QPen(self.line_color)
        pen.setStyle(Qt.DotLine)
        painter.setPen(pen)
        
        indent = self.indentation()
        item = self.itemFromIndex(index)
        
        # Vertical line for siblings
        if index.row() < index.model().rowCount(index.parent()) - 1:
            # Has siblings below
            x = rect.right() - indent // 2
            painter.drawLine(x, rect.top(), x, rect.bottom())
        
        # Horizontal line to item
        x = rect.right() - indent // 2
        y = rect.center().y()
        painter.drawLine(x, y, rect.right(), y)
        
        painter.restore()
    
    def _draw_indicator(self, painter: QPainter, rect: QRect, expanded: bool):
        """Draw the expand/collapse indicator."""
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Calculate indicator position (centered in the branch area)
        size = 9
        indent = self.indentation()
        x = rect.right() - indent // 2 - size // 2
        y = rect.center().y() - size // 2
        
        if self.indicator_style == "plusminus":
            self._draw_plusminus(painter, x, y, size, expanded)
        else:  # arrows
            self._draw_arrow(painter, x, y, size, expanded)
        
        painter.restore()
    
    def _draw_plusminus(self, painter: QPainter, x: int, y: int, size: int, expanded: bool):
        """Draw [+] or [-] indicator."""
        # Draw box
        pen = QPen(self.indicator_color)
        pen.setWidth(1)
        painter.setPen(pen)
        painter.setBrush(QColor("#ffffff") if not self.dark_mode else QColor("#2d2d2d"))
        painter.drawRect(x, y, size, size)
        
        # Draw minus (horizontal line)
        margin = 2
        cy = y + size // 2
        painter.drawLine(x + margin, cy, x + size - margin, cy)
        
        # Draw plus (vertical line) if collapsed
        if not expanded:
            cx = x + size // 2
            painter.drawLine(cx, y + margin, cx, y + size - margin)
    
    def _draw_arrow(self, painter: QPainter, x: int, y: int, size: int, expanded: bool):
        """Draw arrow indicator (▶ or ▼)."""
        painter.setPen(Qt.NoPen)
        painter.setBrush(self.indicator_color)
        
        if expanded:
            # Down arrow ▼
            points = [
                QPoint(x, y + 2),
                QPoint(x + size, y + 2),
                QPoint(x + size // 2, y + size - 1)
            ]
        else:
            # Right arrow ▶
            points = [
                QPoint(x + 2, y),
                QPoint(x + size - 1, y + size // 2),
                QPoint(x + 2, y + size)
            ]
        
        painter.drawPolygon(QPolygon(points))


class TreeView(QWidget):
    rootSelected = Signal(int, str)  # Emits (root_id, root_name)
    rootNodeRenamed = Signal(int, str, str)  # Emits (root_id, old_name, new_name)
    def __init__(self, tree_vm, tabs_view):
        super().__init__()
        self.tree_vm = tree_vm
        self.project_vm = tree_vm.project_vm
        self.tabs_view = tabs_view
        self.project_id = None
        self._is_refreshing = False  # Flag to indicate if we're refreshing (vs initial load)
        self._pending_selection_id = None  # Node ID to select after refresh
        self._editing_old_name = None  # Store old name when editing starts
        self._expand_only_node_id = None  # Node ID to expand after import (instead of expandAll)
        self._setup_ui()

        # --- Connect ViewModel signals ---
        self.tree_vm.treeUpdated.connect(self._on_tree_updated)
        self.tree_vm.nodeAdded.connect(self._on_node_added)
        self.tree_vm.nodeRemoved.connect(self._on_node_removed)
        self.tree_vm.nodeRenamed.connect(self._on_node_renamed)
        self.tree_vm.nodeParamsReady.connect(self._update_keywords_view)
        self.tree_vm.structureChanged.connect(self._on_structure_changed)
        self.tree_vm.errorOccurred.connect(self._on_error)

        # --- Connect to unit system values_converted signal ---
        # When unit system changes and values are converted, refresh current node
        from config.unit_system_config import get_unit_config
        unit_config = get_unit_config()
        unit_config.values_converted.connect(self._on_values_converted)

        # --- Connect UI signals ---
        self.tree.itemChanged.connect(self._on_item_changed)   # Fixed
        self.tree.itemDoubleClicked.connect(self._on_item_double_clicked)  # Capture old name
        self.tree.currentItemChanged.connect(self.on_tree_selection)
        # Auto-show the Info column whenever a record node becomes visible
        # — either by expanding its keyword parent or by the user navigating
        # the tree. Skipped silently if the column is already shown.
        self.tree.itemExpanded.connect(self._on_item_expanded)
        if self.tabs_view:
            self.tabs_view.currentChanged.connect(self.on_tab_selection)

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)  # Same as Project Manager

        # Tree widget - use custom StyledTreeWidget
        self.tree = StyledTreeWidget()
        self.tree.setColumnCount(3)
        self.tree.setHeaderLabels(["Deck Model Manager", "Count", "Info"])
        # Set bold font for the header
        header = self.tree.header()
        header_font = header.font()
        header_font.setBold(True)
        header.setFont(header_font)
        # Adjust column widths
        self.tree.setColumnWidth(0, 220)  # Main column
        self.tree.setColumnWidth(1, 50)   # Children count column - minimum width for "Count"
        self.tree.setColumnWidth(2, 200)  # Info column (id_value + title)
        # Set minimum width for Count column
        header.setMinimumSectionSize(50)
        self.tree.setToolTip(
            "Deck Model Manager: Hierarchical view of keywords in the project.\n"
            "Select a node to view/edit its parameters in the table.\n"
            "Use toolbar to add, remove, rename, or reorganize nodes."
        )

        # Toolbar
        self.toolbar_tree = QToolBar("Tree actions")
        self.toolbar_tree.setStyleSheet(TOOLBAR_STYLE)
        self.toolbar_tree.setIconSize(QSize(24, 24))

        self._create_toolbar_tree(self.toolbar_tree)

        # Style selector
        style_layout = QHBoxLayout()
        style_label = QLabel("Style:")
        self.style_combo = QComboBox()
        self.style_combo.addItems(list(TREE_STYLES.keys()))
        self.style_combo.setCurrentText("Default")
        self.style_combo.currentTextChanged.connect(self._on_style_changed)
        self.style_combo.setToolTip("Select visual style for the tree view")
        self.style_combo.setFixedWidth(100)
        
        # Info column visibility checkbox
        self.info_checkbox = QCheckBox("Info")
        self.info_checkbox.setChecked(False)  # Hidden by default
        self.info_checkbox.setToolTip("Show/hide the Info column (id_value + title)")
        self.info_checkbox.stateChanged.connect(self._on_info_checkbox_changed)
        
        style_layout.addWidget(style_label)
        style_layout.addWidget(self.style_combo)
        style_layout.addWidget(self.info_checkbox)
        style_layout.addStretch()
        
        # Initially hide Info column
        self.tree.setColumnHidden(2, True)

        layout.addWidget(self.toolbar_tree)
        layout.addLayout(style_layout)
        layout.addWidget(self.tree)

    def _on_style_changed(self, style_name: str):
        """Handle style selection change."""
        # Apply QSS stylesheet
        style = get_tree_style(style_name)
        self.tree.setStyleSheet(style)
        
        # Configure custom branch indicators based on style
        dark_mode = style_name in ("Dark", "VS Code")
        
        if style_name == "Default":
            self.tree.set_indicator_style("default", dark_mode)
        elif style_name in ("Classic", "Lines"):
            self.tree.set_indicator_style("plusminus", dark_mode)
        elif style_name in ("Modern",):
            self.tree.set_indicator_style("arrows", dark_mode)
        elif style_name in ("Dark", "VS Code"):
            self.tree.set_indicator_style("plusminus", dark_mode)
        else:
            self.tree.set_indicator_style("default", dark_mode)

    def _on_info_checkbox_changed(self, state: int):
        """Handle Info checkbox state change - show/hide Info column."""
        # state: 0 = unchecked, 2 = checked
        self.tree.setColumnHidden(2, state == 0)

    def _create_toolbar_tree(self, toolbar_tree):
        add_action = QAction(QIcon(get_resource_path("resources/icons/add_node.ico")), "Add", self)
        add_action.setToolTip(
            "Add Node\n"
            "Add a new parent node will be added to the model structure."
        )
        
        remove_action = QAction(QIcon(get_resource_path("resources/icons/del_node.ico")), "Remove", self)
        remove_action.setToolTip(
            "Remove Node\n"
            "Delete the selected node and all its children\n"
            "from the project tree."
        )
        
        self.rename_action = QAction(QIcon(get_resource_path("resources/icons/rename_node.ico")), "Rename Root", self)
        self.rename_action.setToolTip(
            "Rename Node\n"
            "Change the name of the selected root node."
        )
        
        expand_action = QAction(QIcon(get_resource_path("resources/icons/expand_tree.ico")), "Expand", self)
        expand_action.setToolTip(
            "Expand All\n"
            "Expand all nodes in the tree to show\n"
            "the complete hierarchy."
        )
        
        collapse_action = QAction(QIcon(get_resource_path("resources/icons/collapse_tree.ico")), "Collapse", self)
        collapse_action.setToolTip(
            "Collapse All\n"
            "Collapse all nodes in the tree to show\n"
            "only root level items."
        )
        
        filter_action = QAction(QIcon(get_resource_path("resources/icons/filter_node.ico")), "Filter", self)
        filter_action.setToolTip(
            "Filter Nodes\n"
            "Filter nodes in the tree view."
        )

        move_up_action = QAction(QIcon(get_resource_path("resources/icons/up_node.ico")), "Move Up", self)
        move_up_action.setToolTip(
            "Move Up\n"
            "Move the selected node before its previous\n"
            "sibling, keeping all its children intact."
        )

        toolbar_tree.addAction(add_action)
        toolbar_tree.addAction(remove_action)
        toolbar_tree.addAction(self.rename_action)
        toolbar_tree.addAction(move_up_action)
        toolbar_tree.addAction(expand_action)
        toolbar_tree.addAction(collapse_action)
        toolbar_tree.addAction(filter_action)
        
        add_action.triggered.connect(self.add_node)
        remove_action.triggered.connect(self._request_remove_node)
        self.rename_action.triggered.connect(self._request_rename_node)
        move_up_action.triggered.connect(self._request_move_node_up)
        expand_action.triggered.connect(self.tree.expandAll)
        collapse_action.triggered.connect(self.tree.collapseAll)
        filter_action.triggered.connect(self._on_filter_clicked)

    def _on_filter_clicked(self):
        """Handle filter button click - show search dialog and expand matching nodes."""
        if self.project_id is None:
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status("Open a project before searching.")
            return
        
        # Create custom search dialog
        dialog = QDialog(self)
        dialog.setWindowTitle("Search in Tree")
        dialog.setMinimumWidth(350)
        
        layout = QVBoxLayout(dialog)
        
        # Search input
        input_label = QLabel("Enter search text:")
        layout.addWidget(input_label)
        
        search_input = QLineEdit()
        search_input.setPlaceholderText("Search in node names, parameter names and values...")
        layout.addWidget(search_input)
        
        # Exact match checkbox
        exact_match_cb = QCheckBox("Exact match (uncheck for partial/contains search)")
        exact_match_cb.setChecked(False)  # Default: partial search
        layout.addWidget(exact_match_cb)
        
        # Buttons layout
        btn_layout = QHBoxLayout()
        
        # Search button
        search_btn = QPushButton("Search")
        search_btn.clicked.connect(lambda: self._do_search(search_input.text(), exact_match_cb.isChecked()))
        btn_layout.addWidget(search_btn)
        
        # Clear marks button
        clear_btn = QPushButton("Clear Marks")
        clear_btn.clicked.connect(lambda: self._clear_search_marks())
        btn_layout.addWidget(clear_btn)
        
        # Close button
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(dialog.close)
        btn_layout.addWidget(close_btn)
        
        layout.addLayout(btn_layout)
        
        # Connect Enter key to search
        search_input.returnPressed.connect(lambda: self._do_search(search_input.text(), exact_match_cb.isChecked()))
        
        # Clear marks when dialog is closed
        dialog.finished.connect(lambda: self._clear_search_marks())
        
        # Focus on input
        search_input.setFocus()
        
        # Show dialog (non-modal so user can interact with tree)
        apply_dialog_theme(dialog)
        dialog.show()
    
    def _do_search(self, search_text: str, exact_match: bool):
        """Execute the search with given parameters."""
        if search_text.strip():
            self._search_and_expand(search_text.strip(), exact_match)
    
    def _clear_search_marks(self):
        """Clear all search marks (bold font and background) from the tree.

        Each ``setFont`` / ``setData`` call triggers a QTreeWidget repaint, so
        with hundreds of marks the naive loop took ~40 s. Wrapping the bulk
        update in ``setUpdatesEnabled(False)`` collapses that into a single
        repaint at the end. Use a try/finally so a midway exception still
        re-enables painting.
        """
        if hasattr(self, '_marked_items') and self._marked_items:
            self.tree.setUpdatesEnabled(False)
            try:
                for item, original_bg in self._marked_items:
                    try:
                        # Reset font to normal (only column 0)
                        font = item.font(0)
                        font.setBold(False)
                        item.setFont(0, font)
                        # Restore original background for column 0
                        item.setData(0, Qt.BackgroundRole, original_bg)
                    except RuntimeError:
                        pass  # Item may have been deleted
                self._marked_items = []
            finally:
                self.tree.setUpdatesEnabled(True)
        main_window = self.window()
        if hasattr(main_window, "show_status"):
            main_window.show_status("Search marks cleared")
    
    def _search_and_expand(self, search_text: str, exact_match: bool = False):
        """Search for nodes matching the text and expand the tree to show them.

        Performance notes:
          - ``matching_node_ids`` is converted to a ``set`` so the per-tree-
            item membership check is O(1) instead of O(M). On a 20 K-node tree
            with 200 matches that turns 4 M list scans into 20 K hash lookups.
          - The tree walk is iterative; ``_expand_to_item`` shortcuts using
            a "seen parents" set so a chain of common ancestors is expanded
            once, not once per match.
          - All visual mutations (mark/expand/scroll) happen inside a single
            ``setUpdatesEnabled(False/True)`` window so the QTreeWidget paints
            exactly once.
        """
        # Clear previous marks first
        self._clear_search_marks()

        # Get matching node IDs from database
        strategy = getattr(self.project_vm, "db_manager", None)
        strategy = getattr(strategy, "strategy", None)

        if not strategy or not hasattr(strategy, "search_nodes"):
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status("Search not available.")
            return

        matching_node_ids = strategy.search_nodes(self.project_id, search_text, exact_match)

        if not matching_node_ids:
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                match_type = "exact" if exact_match else "partial"
                main_window.show_status(f"No results found for '{search_text}' ({match_type} match)")
            return

        # ── Tree walk: O(N) membership tests via set, O(M) parent expansion
        # via "already expanded" memo. ───────────────────────────────────
        match_set = set(matching_node_ids)
        expanded_parents: set = set()

        self.tree.setUpdatesEnabled(False)
        try:
            found_items: list = []
            self._find_and_expand_nodes(
                self.tree.invisibleRootItem(),
                match_set,
                found_items,
                expanded_parents,
            )

            # Mark found items — store with original background for restoration.
            # Create gradient brush (pistachio yellow-green to darker green).
            gradient = QLinearGradient(0, 0, 200, 0)  # Horizontal gradient
            gradient.setColorAt(0.0, QColor("#D4E157"))  # Pistachio yellow-green (lime)
            gradient.setColorAt(1.0, QColor("#4CAF50"))  # Darker green
            highlight_brush = QBrush(gradient)

            self._marked_items = []

            for item in found_items:
                original_bg = item.data(0, Qt.BackgroundRole)
                self._marked_items.append((item, original_bg))
                font = item.font(0)
                font.setBold(True)
                item.setFont(0, font)
                item.setBackground(0, highlight_brush)

            if found_items:
                self.tree.setCurrentItem(found_items[0])
                self.tree.scrollToItem(found_items[0])
                # Auto-show the Info column when at least one match is a
                # record node (depth ≥ 3 — root/family/keyword/record). The
                # Info column carries id_value + title text, so revealing
                # it makes the match context immediately visible without
                # the user toggling the checkbox manually.
                for it in found_items:
                    depth = 0
                    a = it.parent()
                    while a is not None:
                        depth += 1
                        a = a.parent()
                        if depth >= 3:
                            break
                    if depth >= 3:
                        if not self.info_checkbox.isChecked():
                            self.info_checkbox.setChecked(True)
                        break
        finally:
            self.tree.setUpdatesEnabled(True)

        if found_items:
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                match_type = "exact" if exact_match else "partial"
                main_window.show_status(
                    f"Found {len(found_items)} node(s) matching '{search_text}' ({match_type} match)"
                )

    def _find_and_expand_nodes(self, parent_item, match_set: set, found_items: list,
                                expanded_parents: set):
        """Recursively find nodes whose id ∈ *match_set* and expand parents.

        ``match_set`` is a set for O(1) membership. ``expanded_parents``
        memoises which QTreeWidgetItem ancestors have already been expanded
        so a chain of shared ancestors is only walked once across the whole
        search.
        """
        for i in range(parent_item.childCount()):
            child = parent_item.child(i)
            node_id = child.data(0, Qt.UserRole)

            if node_id in match_set:
                self._expand_to_item(child, expanded_parents)
                found_items.append(child)

            self._find_and_expand_nodes(child, match_set, found_items, expanded_parents)

    def _expand_to_item(self, item, expanded_parents: set | None = None):
        """Expand all parent nodes to make the item visible.

        ``expanded_parents`` (optional) memoises ancestors already expanded
        during the current search pass so common ancestor chains aren't
        re-walked once per match. When called outside a search (e.g.
        ``_on_values_converted``) it can be omitted and the function falls
        back to the simple walk.
        """
        parent = item.parent()
        if expanded_parents is None:
            while parent:
                parent.setExpanded(True)
                parent = parent.parent()
            return
        while parent:
            pid = id(parent)
            if pid in expanded_parents:
                # Every further ancestor has already been processed in this
                # search pass — short-circuit.
                return
            parent.setExpanded(True)
            expanded_parents.add(pid)
            parent = parent.parent()
    
    def _expand_node_by_id(self, node_id: int):
        """Find a node by its ID and expand it (plus its children one level deep).
        
        Args:
            node_id: The database node ID to find and expand
        """
        def find_item(parent_item, target_id):
            for i in range(parent_item.childCount() if parent_item else self.tree.topLevelItemCount()):
                item = parent_item.child(i) if parent_item else self.tree.topLevelItem(i)
                item_id = item.data(0, Qt.UserRole)
                if item_id == target_id:
                    return item
                # Search recursively in children
                found = find_item(item, target_id)
                if found:
                    return found
            return None
        
        item = find_item(None, node_id)
        if item:
            # Expand this item and its immediate children
            item.setExpanded(True)
            for i in range(item.childCount()):
                item.child(i).setExpanded(True)
            # Scroll to make it visible
            self.tree.scrollToItem(item)

    def _get_expansion_state(self) -> set:
        """Get the set of node IDs that are currently expanded."""
        expanded_ids = set()
        
        def collect_expanded(item):
            if item.isExpanded():
                node_id = item.data(0, Qt.UserRole)
                if node_id is not None:
                    expanded_ids.add(node_id)
            for i in range(item.childCount()):
                collect_expanded(item.child(i))
        
        for i in range(self.tree.topLevelItemCount()):
            collect_expanded(self.tree.topLevelItem(i))
        
        return expanded_ids

    def _restore_expansion_state(self, expanded_ids: set):
        """Restore expansion state from a set of node IDs."""
        def restore_expanded(item):
            node_id = item.data(0, Qt.UserRole)
            if node_id is not None and node_id in expanded_ids:
                item.setExpanded(True)
            for i in range(item.childCount()):
                restore_expanded(item.child(i))
        
        for i in range(self.tree.topLevelItemCount()):
            restore_expanded(self.tree.topLevelItem(i))

    def refresh_tree(self, select_node_id: int = None):
        """Refresh the tree while preserving expansion state and selection."""
        if self.project_id is None:
            return
        
        # Get current selection if no specific node requested
        if select_node_id is None:
            current_item = self.tree.currentItem()
            if current_item:
                select_node_id = current_item.data(0, Qt.UserRole)
        
        # Save expansion state
        expanded_ids = self._get_expansion_state()
        
        # Mark as refreshing to avoid expandAll in _on_tree_updated
        self._is_refreshing = True
        self._pending_selection_id = select_node_id
        self._pending_expansion_ids = expanded_ids
        
        # Reload tree
        self.tree_vm.load_tree(self.project_id)

    # -------------------------------
    # Public methods for main.py
    def load_project(self, project_id: int, expand_node_id: int = None):
        """Load a project into the tree and sync tabs.
        
        Args:
            project_id: The project ID to load
            expand_node_id: If provided, only expand this specific node (e.g., after import).
                           If None, expand all nodes (initial load behavior).
        """
        self.project_id = project_id
        
        # Store expand_node_id for use in _on_tree_updated
        self._expand_only_node_id = expand_node_id
        self._is_refreshing = expand_node_id is not None  # Prevent expandAll if we have a specific node to expand
        
        self.tree_vm.load_tree(project_id)

        if self.tabs_view:
            self.tabs_view.clear_tabs()
            nodes = self.tree_vm.project_vm.get_nodes(project_id)
            for node_id, parent_id, name in nodes:
                if parent_id is None:  # only root nodes
                    self.tabs_view.add_tab(name)
        
        # If we have a specific node to expand (after import), expand only that one
        if expand_node_id is not None:
            self._expand_node_by_id(expand_node_id)

    def clear_tree(self):
        """Clear the tree and reset the active project."""
        self.tree.clear()
        self.project_id = None
        self.tree_vm.active_project_id = None

    # -------------------------------
    # Add root node
    def add_node(self):
        if self.project_id is None:
            # QMessageBox.warning(self, "No Project", "Open a project before adding nodes.")
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status("Open a project before adding nodes.")

            return

        name, ok = QInputDialog.getText(self, "Add Node", "Enter node name:")
        if ok and name.strip():
            if self._node_exists(name):
                # QMessageBox.warning(self, "Duplicate", f"Node '{name}' already exists")
                main_window = self.window()
                if hasattr(main_window, "show_status"):
                    main_window.show_status(f"Node '{name}' already exists")                
                return
            
            # Save expansion state before adding (to avoid expandAll)
            expanded_ids = self._get_expansion_state()
            self._is_refreshing = True
            self._pending_expansion_ids = expanded_ids
            
            # Mark that we want to select the new node by name after refresh
            self._pending_selection_name = name.strip()
            
            # Add the node
            self.tree_vm.add_node(name.strip(), parent_id=None)

    def _node_exists(self, name: str) -> bool:
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.text(0).strip().lower() == name.strip().lower():
                return True
        return False

    def add_root_node(self, name: str) -> bool:
        """Add a root node programmatically (without user input).
        
        Args:
            name: Name of the root node to add
            
        Returns:
            True if node was added, False if it already exists or failed
        """
        if self.project_id is None:
            return False
        
        if self._node_exists(name):
            return False  # Already exists
        
        # Save expansion state before adding (to avoid expandAll)
        expanded_ids = self._get_expansion_state()
        self._is_refreshing = True
        self._pending_expansion_ids = expanded_ids
        self._pending_selection_id = None
        
        node_id = self.tree_vm.add_node(name.strip(), parent_id=None)
        return node_id is not None

    def _request_move_node_up(self):
        """Move the selected node up among its siblings."""
        item = self.tree.currentItem()
        if not item:
            return

        node_id = item.data(0, Qt.UserRole)
        if not node_id:
            return

        # Save expansion and selection state for refresh
        expanded_ids = self._get_expansion_state()
        self._is_refreshing = True
        self._pending_expansion_ids = expanded_ids
        self._pending_selection_id = node_id

        success = self.tree_vm.move_node_up(node_id)
        if not success:
            self._is_refreshing = False
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status("Node is already first among its siblings.")

    def _request_remove_node(self):
        item = self.tree.currentItem()
        if not item:
            return

        node_id = item.data(0, Qt.UserRole)
        if not node_id:
            return

        project_id = self.project_id
        nodes = self.tree_vm.project_vm.get_nodes(project_id)
        node_map = {nid: (pid, nname) for nid, pid, nname in nodes}

        # Collect the entire subtree (including the node itself)
        descendants = []
        stack = [node_id]
        while stack:
            cur = stack.pop()
            descendants.append(cur)
            children = [nid for nid, pid, _ in nodes if pid == cur]
            stack.extend(children)

        # Confirmation dialog
        record_name = node_map.get(node_id, (None, ""))[1]
        reply = QMessageBox.question(
            self,
            "Delete node",
            f"'{record_name}' and {len(descendants)-1} children will be deleted. Continue?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status("Deletion cancelled")
            return

        # Delete from DB (FK cascade removes children and parameters)
        try:
            self.project_vm.delete_node(node_id)
        except Exception as e:
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status(f"Error deleting {record_name}: {e}")
            return

        # If it was root, remove associated tab
        parent_id = node_map.get(node_id, (None, None))[0]
        if parent_id is None and self.tabs_view:
            self.tabs_view.remove_tab_by_name(record_name)

        # Remove ancestors left without children (except root)
        # Evaluated after DB deletion
        ancestors_chain = []
        cur = parent_id
        while cur is not None:
            ancestors_chain.append(cur)
            cur = node_map.get(cur, (None, None))[0]

        # Track deleted ancestors to determine surviving parent
        deleted_ancestors = set()
        
        # Recount nodes after deletion
        nodes_after = self.tree_vm.project_vm.get_nodes(project_id)
        for anc_id in ancestors_chain:
            if anc_id is None:
                continue
            anc_parent = next((pid for nid, pid, _ in nodes_after if nid == anc_id), None)
            # Skip root
            if anc_parent is None:
                continue
            has_children = any(pid == anc_id for _, pid, _ in nodes_after)
            if not has_children:
                try:
                    self.project_vm.delete_node(anc_id)
                    deleted_ancestors.add(anc_id)
                except Exception:
                    pass
                else:
                    # Update list after deleting this ancestor
                    nodes_after = self.tree_vm.project_vm.get_nodes(project_id)

        # Determine surviving parent (first ancestor not deleted)
        surviving_parent_id = None
        for anc_id in ancestors_chain:
            if anc_id not in deleted_ancestors:
                surviving_parent_id = anc_id
                break

        # Refresh tree and select surviving parent
        self.refresh_tree(select_node_id=surviving_parent_id)

        # Show confirmation in the status bar
        main_window = self.window()
        if hasattr(main_window, "show_status"):
            main_window.show_status(f"Deleted '{record_name}' and {len(descendants)-1} children")

    # def _request_rename_node(self):
    #     item = self.tree.currentItem()
    #     if item and item.parent() is None:
    #         old_name = item.text(0)
    #         new_name, ok = QInputDialog.getText(self, "Rename Node", "Enter new name:", text=old_name)
    #         if ok and new_name.strip():
    #             node_id = item.data(0, Qt.UserRole)
    #             self.tree_vm.rename_node(node_id, new_name.strip())

    # -------------------------------
    # Methods for keywords (TabsView)
    def add_keyword_node(self, tab_root: str, family: str, keyword: str, params: dict):
        """Add a leaf node (record) under the tab/family/keyword hierarchy and store parameters in the DB.
        
        Tree structure: tab_root → family → keyword → ID:xxx
        Info column shows: id_value | title/heading
        """
        record_id = self.add_keyword_node_no_refresh(tab_root, family, keyword, params)
        if record_id:
            # Refresh tree (preserves expansion) and select the new record
            self.refresh_tree(select_node_id=record_id)
        return record_id

    def add_keyword_node_no_refresh(self, tab_root: str, family: str, keyword: str, params: dict) -> int | None:
        """Add a leaf node without refreshing the tree. Returns the record_id or None.
        
        Use this for batch operations, then call refresh_tree() once at the end.
        """
        if self.project_id is None:
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status("Open a project before adding nodes.")
            return None

        # Create tab_root, family and keyword hierarchy if missing
        root_id = self._find_or_create_node(tab_root, None)
        family_id = self._find_or_create_node(family, root_id)
        keyword_id = self._find_or_create_node(keyword, family_id)

        # Create the leaf node (record) directly without triggering tree refresh
        record_id = self.tree_vm.project_vm.add_node(f"ID:{keyword_id}", keyword_id, self.project_id)
        if not record_id:
            return None

        # Save parameters on the leaf node
        self.tree_vm.project_vm.add_params(record_id, params)
        
        # Update node name to use real record_id
        self.tree_vm.project_vm.update_node_name(record_id, f"ID:{record_id}")

        return record_id

    def add_keyword_node_with_id(self, tab_root: str, family: str, keyword: str, params: dict, use_id: int) -> int | None:
        """Add a leaf node using a specific ID (for related materials).
        
        This creates a node with name ID:xxx where xxx is the provided use_id,
        allowing related materials (EOS, CURVE) to share the same ID as their parent MAT.
        
        Args:
            tab_root: Root tab name
            family: Family name (EOS, DEFINE, etc.)
            keyword: Keyword type
            params: Parameters to save
            use_id: The ID to use for the node name (typically the parent MAT's record_id)
            
        Returns:
            The record_id or None
        """
        if self.project_id is None:
            return None

        # Create tab_root, family and keyword hierarchy if missing
        root_id = self._find_or_create_node(tab_root, None)
        family_id = self._find_or_create_node(family, root_id)
        keyword_id = self._find_or_create_node(keyword, family_id)

        # Create the leaf node with the specified ID in the name
        record_id = self.tree_vm.project_vm.add_node(f"ID:{use_id}", keyword_id, self.project_id)
        if not record_id:
            return None
        
        # Save parameters on the leaf node
        self.tree_vm.project_vm.add_params(record_id, params)

        return record_id


    def update_keyword_node(self, family: str, keyword: str, params: dict):
        """Update parameters only on leaf nodes (records)."""
        item = self.tree.currentItem()
        if not item:
            return

        # Only leaf nodes (no children) should store parameters
        if item.childCount() > 0:
            return

        node_id = item.data(0, Qt.UserRole)
        if node_id:
            # Use update_params to overwrite values without duplicating
            self.tree_vm.project_vm.update_params(node_id, params)

            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status(f"Params updated for node {node_id}")


    def delete_keyword_node(self, family_name: str, keyword: str):
        """Remove a leaf node and its parameters from the DB."""
        item = self._find_keyword_item(family_name, keyword)
        if not item:
            return

        node_id = item.data(0, Qt.UserRole)
        self.project_vm.delete_params(node_id)
        self.project_vm.delete_node(node_id)

        parent = item.parent()
        if parent:
            parent.removeChild(item)


    def _find_or_create_node(self, name: str, parent_id: int | None) -> int:
        """Find existing node or create new one. Always fetches fresh data from DB."""
        # Always get fresh nodes from DB to avoid stale data
        nodes = self.tree_vm.project_vm.get_nodes(self.project_id)
        name_lower = name.strip().lower()
        
        for nid, pid, nname in nodes:
            nname_lower = str(nname).strip().lower()
            parent_matches = (pid is None and parent_id is None) or (pid == parent_id)
            if parent_matches and nname_lower == name_lower:
                return nid
        
        # Node not found, create it without triggering full tree refresh
        new_id = self.tree_vm.project_vm.add_node(name.strip(), parent_id, self.project_id)
        return new_id

    def _select_tree_item_by_id(self, node_id: int):
        def find_item_recursive(parent):
            for i in range(parent.childCount()):
                child = parent.child(i)
                if child.data(0, Qt.UserRole) == node_id:
                    return child
                found = find_item_recursive(child)
                if found:
                    return found
            return None

        for i in range(self.tree.topLevelItemCount()):
            top = self.tree.topLevelItem(i)
            if top.data(0, Qt.UserRole) == node_id:
                self.tree.setCurrentItem(top)
                return
            found = find_item_recursive(top)
            if found:
                self.tree.setCurrentItem(found)
                return

    def select_node_by_id(self, node_id: int):
        """Public helper to select a node by id if present in the tree."""
        self._select_tree_item_by_id(node_id)

    def _select_tree_item_by_name(self, name: str):
        """Select a tree item by its name (used for newly added root nodes)."""
        target_name = name.strip().lower()
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.text(0).strip().lower() == target_name:
                self.tree.setCurrentItem(item)
                return

    # -------------------------------
    # Slots reacting to VM signals
    def _on_structure_changed(self, project_id):
        """Re-sync parameter tabs with the project roots, then refresh the tree.

        Tabs are created per root node (see ``load_project``). After a bulk
        injection a new root (e.g. 'main') may exist without a tab, so its
        records would find no tab and show no parameters. Add any missing tab
        (idempotent — ``add_tab`` does not dedupe) and refresh preserving state.
        """
        self.project_id = project_id
        if self.tabs_view:
            existing = {self.tabs_view.tabText(i) for i in range(self.tabs_view.count())}
            try:
                nodes = self.tree_vm.project_vm.get_nodes(project_id)
            except Exception:
                nodes = []
            for node_id, parent_id, name in nodes:
                if parent_id is None and name not in existing:
                    self.tabs_view.add_tab(name)
                    existing.add(name)
        # Pick up any node that the host wants selected after the rebuild
        # (set via reload_structure(select_node_id=...)).
        select_id = getattr(self.tree_vm, '_pending_select_after_reload', None)
        self.tree_vm._pending_select_after_reload = None
        self.refresh_tree(select_node_id=select_id)

    def _on_tree_updated(self, nodes):
        self.tree.clear()
        node_dict = {}
        
        # First pass: count direct children for each node
        children_count = {}
        for nid, parent_id, name in nodes:
            if parent_id is not None:
                children_count[parent_id] = children_count.get(parent_id, 0) + 1
        
        # Second pass: create items with child count and info
        for nid, parent_id, name in nodes:
            count = children_count.get(nid, 0)
            # Show count only if node has children, otherwise empty
            count_text = str(count) if count > 0 else ""
            
            # Get info for leaf nodes (records with params)
            # Use summarize_massive=True to avoid loading large DataFrames
            info_text = ""
            if count == 0:  # Leaf node
                params = self.tree_vm.project_vm.get_params(nid, summarize_massive=True)
                if params:
                    info_text = get_record_info(params)
            
            item = QTreeWidgetItem([name, count_text, info_text])
            item.setData(0, Qt.UserRole, nid)
            # Center align the count column
            item.setTextAlignment(1, Qt.AlignCenter)
            # Set info column text color to blue
            if info_text:
                item.setForeground(2, QColor("#0066CC"))
            node_dict[nid] = (item, parent_id)

        for nid, (item, parent_id) in node_dict.items():
            if parent_id is None:
                self.tree.addTopLevelItem(item)
            else:
                parent_tuple = node_dict.get(parent_id)
                if parent_tuple:
                    parent_item, _ = parent_tuple
                    parent_item.addChild(item)

        # Handle expansion state based on whether this is a refresh or initial load
        if self._is_refreshing:
            # Restore previous expansion state
            if hasattr(self, '_pending_expansion_ids'):
                self._restore_expansion_state(self._pending_expansion_ids)
                del self._pending_expansion_ids
            
            # Restore selection by ID
            if hasattr(self, '_pending_selection_id') and self._pending_selection_id is not None:
                self._select_tree_item_by_id(self._pending_selection_id)
                # Expand to make selected item visible
                current = self.tree.currentItem()
                if current:
                    self._expand_to_item(current)
                self._pending_selection_id = None
            
            # Select newly added node by name (for add_node)
            if hasattr(self, '_pending_selection_name') and self._pending_selection_name is not None:
                self._select_tree_item_by_name(self._pending_selection_name)
                self._pending_selection_name = None
            
            self._is_refreshing = False
        else:
            # Initial load - expand all
            self.tree.expandAll()
        
        # Validate and mark duplicate IDs
        self.validate_and_mark_duplicates()

    def validate_and_mark_duplicates(self):
        """
        Validate all nodes for duplicate IDs and mark them in red in the tree.
        Also validates duplicate source names (root nodes).
        This checks:
        - For nodes with 'ID.id' parameter (OptionCardSet): validates that value
        - For nodes without 'ID.id': validates the first parameter containing 'id'
        - For root nodes: validates that names are unique
        """
        if self.project_id is None:
            return
        
        validator = get_duplicate_validator()
        validator.set_project_vm(self.tree_vm.project_vm)
        
        # Get duplicate nodes (by ID)
        duplicate_map = validator.validate_project(self.project_id)
        
        # Get duplicate source names (root nodes)
        duplicate_sources = self._get_duplicate_source_names()
        
        # Reset all node colors first
        self._reset_tree_colors()
        
        # Mark duplicate nodes in red (by ID)
        if duplicate_map:
            self._mark_duplicate_nodes(duplicate_map)
        
        # Mark duplicate sources in orange
        if duplicate_sources:
            self._mark_duplicate_sources(duplicate_sources)
    
    def _get_duplicate_source_names(self) -> dict:
        """
        Find root nodes (sources) with duplicate names.
        
        Returns:
            Dictionary mapping node_id to the duplicate name for all duplicated roots
        """
        duplicates = {}
        name_to_nodes = {}  # name -> [(node_id, item), ...]
        
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            name = item.text(0).strip().lower()
            node_id = item.data(0, Qt.UserRole)
            
            if name not in name_to_nodes:
                name_to_nodes[name] = []
            name_to_nodes[name].append((node_id, item.text(0)))
        
        # Find names that appear more than once
        for name, nodes in name_to_nodes.items():
            if len(nodes) > 1:
                for node_id, original_name in nodes:
                    duplicates[node_id] = original_name
        
        return duplicates
    
    def get_duplicate_sources(self) -> list:
        """
        Public method to get list of duplicate source names.
        Used by export validation.
        
        Returns:
            List of duplicate source names
        """
        duplicates = self._get_duplicate_source_names()
        return list(set(duplicates.values()))
    
    def has_duplicate_sources(self) -> bool:
        """
        Check if there are any duplicate source names.
        
        Returns:
            True if duplicates exist
        """
        return len(self._get_duplicate_source_names()) > 0
    
    def _reset_tree_colors(self):
        """Reset all tree node colors and tooltips to default."""
        def reset_item(item):
            # Reset foreground to default (black or system default)
            item.setForeground(0, QColor())  # Empty QColor resets to default
            item.setToolTip(0, "")  # Clear tooltip
            for i in range(item.childCount()):
                reset_item(item.child(i))
        
        # Block signals to prevent triggering _on_item_changed during color updates
        self.tree.blockSignals(True)
        try:
            for i in range(self.tree.topLevelItemCount()):
                reset_item(self.tree.topLevelItem(i))
        finally:
            self.tree.blockSignals(False)
    
    def _mark_duplicate_sources(self, duplicate_sources: dict):
        """
        Mark root nodes with duplicate names in orange.
        
        Args:
            duplicate_sources: Dictionary mapping node_id to duplicate source name
        """
        orange_color = QColor("#FF8C00")  # Dark orange
        
        # Block signals to prevent triggering _on_item_changed during color updates
        self.tree.blockSignals(True)
        try:
            for i in range(self.tree.topLevelItemCount()):
                item = self.tree.topLevelItem(i)
                node_id = item.data(0, Qt.UserRole)
                if node_id in duplicate_sources:
                    item.setForeground(0, orange_color)
                    item.setToolTip(0, f"⚠ Duplicate source name: '{duplicate_sources[node_id]}'\nRename before exporting to avoid file conflicts.")
        finally:
            self.tree.blockSignals(False)
    
    def _mark_duplicate_nodes(self, duplicate_map: dict):
        """
        Mark nodes with duplicate IDs in red.
        
        Args:
            duplicate_map: Dictionary mapping node_id to list of duplicate descriptions
        """
        red_color = QColor("#DC3545")  # Bootstrap danger red
        
        def mark_item(item):
            node_id = item.data(0, Qt.UserRole)
            if node_id in duplicate_map:
                item.setForeground(0, red_color)
                # Add tooltip with duplicate info
                dup_info = duplicate_map[node_id]
                tooltip = f"Duplicate ID: {', '.join(dup_info)}"
                item.setToolTip(0, tooltip)
            
            for i in range(item.childCount()):
                mark_item(item.child(i))
        
        # Block signals to prevent triggering _on_item_changed during color updates
        self.tree.blockSignals(True)
        try:
            for i in range(self.tree.topLevelItemCount()):
                mark_item(self.tree.topLevelItem(i))
        finally:
            self.tree.blockSignals(False)

    def _on_node_added(self, node_id, name):
        # If the added node is root, create the tab automatically
        if self.tabs_view and self.project_id is not None:
            # Check the DB to confirm it is root
            nodes = self.tree_vm.project_vm.get_nodes(self.project_id)
            for nid, parent_id, _ in nodes:
                if nid == node_id:
                    # If parent_id is None, it is a root node
                    if parent_id is None:
                        # Ensure the tab does not already exist
                        tab_exists = False
                        tab_index = -1
                        for i in range(self.tabs_view.count()):
                            if self.tabs_view.tabText(i).strip() == name.strip():
                                tab_exists = True
                                tab_index = i
                                break
                        
                        # If it does not exist, create the new tab
                        if not tab_exists:
                            self.tabs_view.add_tab(name.strip())
                            # Select the newly created tab
                            tab_index = self.tabs_view.count() - 1
                        
                        # Select the tab (whether new or existing)
                        if tab_index >= 0:
                            self.tabs_view.setCurrentIndex(tab_index)
                            
                            # Position the KeywordsView family_combo to match the node name
                            keywords_view = self.tabs_view.widget(tab_index)
                            if keywords_view and hasattr(keywords_view, "family_combo"):
                                target_family = name.strip().upper()
                                for i in range(keywords_view.family_combo.count()):
                                    if keywords_view.family_combo.itemText(i).strip().upper() == target_family:
                                        keywords_view.family_combo.setCurrentIndex(i)
                                        if hasattr(keywords_view, "_update_library_button_visibility"):
                                            keywords_view._update_library_button_visibility(name.strip())
                                        break
                    break

    def _on_node_removed(self, node_id):
        # QMessageBox.information(self, "Node Removed", f"Node id {node_id} removed")
        main_window = self.window()
        
        item = self.tree.currentItem()
        if item:
            # Recover the id directly from the item
            node_id = item.data(0, Qt.UserRole)
            if node_id:
                # If it is a root node (family), also remove the tab
                if item.parent() is None and self.tabs_view:
                    self.tabs_view.remove_tab_by_name(item.text(0))

                # Delete in the database
                self.project_vm.delete_node(node_id)

                # Refresh tree (preserve expansion state)
                self.refresh_tree()

        if hasattr(main_window, "show_status"):
            main_window.show_status(f"Node id {node_id} removed")

    def _on_node_renamed(self, node_id, new_name):

        def update_item_recursive(item):
            if item.data(0, Qt.UserRole) == node_id:
                item.setText(0, new_name)
                return True
            for i in range(item.childCount()):
                if update_item_recursive(item.child(i)):
                    return True
            return False

        # Use self.tree.topLevelItemCount() instead of self.topLevelItemCount()
        for i in range(self.tree.topLevelItemCount()):
            if update_item_recursive(self.tree.topLevelItem(i)):
                break

        # If it is root, also update the tab
        if self.tabs_view:
            nodes = self.tree_vm.project_vm.get_nodes(self.project_id)
            for nid, parent_id, nname in nodes:
                if nid == node_id and parent_id is None:
                    for i in range(self.tabs_view.count()):
                        if self.tabs_view.tabText(i).strip().lower() == nname.strip().lower():
                            self.tabs_view.setTabText(i, new_name)
                            break
                    break

        # Show notification in the status bar
        main_window = self.window()
        if hasattr(main_window, "statusBar"):
            main_window.statusBar.showMessage(f"Node {node_id} renamed to '{new_name}'", 5000)
        
        # Re-validate and update duplicate markers (colors)
        # This will remove orange color if duplicates are resolved
        self.validate_and_mark_duplicates()

        
    def edit_node(self, item: QTreeWidgetItem, new_name: str, old_name: str = None):
        """Called when the user edits the name of a node."""
        node_id = item.data(0, Qt.UserRole)
        is_root = item.parent() is None
        
        success = self.tree_vm.project_vm.rename_node(node_id, new_name.strip())

        if success:
            # Call method that refreshes tree, tabs, and status bar
            self._on_node_renamed(node_id, new_name.strip())
            # Emit signal for root node rename (to handle .k file rename)
            if is_root and old_name and old_name != new_name.strip():
                self.rootNodeRenamed.emit(node_id, old_name, new_name.strip())
        else:
            # If it fails, show a notice in the status bar
            main_window = self.window()
            if hasattr(main_window, "statusBar"):
                main_window.statusBar.showMessage("Could not rename the node", 5000)



    def _on_error(self, message):
        QMessageBox.warning(self, "Error", message)

    def _on_values_converted(self, count: int):
        """Handle when parameter values have been converted to a new unit system.
        
        Reloads the current node's parameters to show updated values.
        """
        current = self.tree.currentItem()
        if current:
            node_id = current.data(0, Qt.UserRole)
            if node_id:
                # Re-request node params to refresh the table with converted values
                self.tree_vm.request_node_params(node_id)

    # -------------------------------
    # Tree selection
    def on_tree_selection(self, current, _):
        if not current:
            self.rename_action.setEnabled(False)
            return

        # Reveal the Info column when the user lands on (or navigates past)
        # a record-level node — the id+title hint is most useful then.
        self._maybe_show_info_for_records(current)

        is_root = current.parent() is None
        self.rename_action.setEnabled(is_root)

        if is_root:
            node_id = current.data(0, Qt.UserRole)
            if node_id:
                self.rootSelected.emit(node_id, current.text(0))

        # ── Safety: immediately clear the parameter table on ANY tree navigation ──
        # This prevents stale data from the previous record persisting if
        # _update_keywords_view fails to run (e.g. request_node_params error)
        # or if _load_keyword_node_inner encounters an exception before
        # reaching its table-clear code.
        # Records will repopulate the table via _update_keywords_view.
        if self.tabs_view:
            tab_idx = self.tabs_view.currentIndex()
            if tab_idx >= 0:
                kw = self.tabs_view.widget(tab_idx)
                if kw and hasattr(kw, 'table_main'):
                    kw.table_main.setRowCount(0)
                    kw.table_main.setColumnCount(0)

        node_id = current.data(0, Qt.UserRole)
        if node_id:
            self.tree_vm.request_node_params(node_id)

    def _update_keywords_view(self, node_id, params):
        current = self.tree.currentItem()
        if not current or self.tabs_view is None:
            return

        # Detect tree depth to determine node type:
        # Level 0: Root/Tab node
        # Level 1: Family node  (e.g., "MAT", "DEFINE")
        # Level 2: Keyword node (e.g., "015_JOHNSON_COOK", "CURVE", "TABLE")
        # Level 3+: Record node (e.g., "ID:123")  ← only this shows params
        depth = 0
        ancestor = current.parent()
        while ancestor is not None:
            depth += 1
            ancestor = ancestor.parent()

        is_record = depth >= 3

        if not is_record:
            params = {}   # Non-record nodes never show parameter values
            node_id = None
        
        # Filter out internal metadata from display (fields starting with _ except special ones)
        # Keep: __selected_option_specs__, __*_dataframe__, __*_list__, __*_count__, __parameters_*__, __param_*__
        # Also keep: __raw_content__, __original_name__, __table_points__ for DEFINE_TABLE keywords
        if params:
            allowed_dunder = {
                "__selected_option_specs__", 
                "__nodes_dataframe__", 
                "__elements_dataframe__", 
                "__parts_dataframe__",
                "__segments_dataframe__",
                "__transforms_dataframe__",
                "__node_count__",
                "__element_count__",
                "__set_nodes_list__",
                "__set_parts_list__",
                "__set_nodes_count__",
                "__set_parts_count__",
                "__segment_count__",
                "__raw_content__",           # TABLE keywords raw content
                "__original_name__",         # TABLE keywords original keyword name
                "__table_points__",          # TABLE keywords data points
                "__user_comment__",          # Keyword comment (PyDyna user_comment)
            }
            def is_allowed(k):
                if not k.startswith("_"):
                    return True
                if k in allowed_dunder:
                    return True
                # Allow __tablecard_<prop>__ markers and __tablecard_<prop>_data__ storage
                if k.startswith('__tablecard_') and k.endswith('__'):
                    return True
                return False
            params = {k: v for k, v in params.items() if is_allowed(k)}

        # Detect family/keyword names based on tree structure (4 levels):
        # Level 0: Tab/root (05_materialcard)
        # Level 1: Family (MAT)
        # Level 2: Keyword (015_JOHNSON_COOK)
        # Level 3: Record (ID:xxx)
        
        if current.parent() is None:
            # Level 0: Root/Tab node
            root_name = current.text(0)
            family_name = ""
            keyword_name = ""
        elif current.parent().parent() is None:
            # Level 1: Family node (e.g., "MAT")
            family_name = current.text(0)
            root_name = current.parent().text(0)
            keyword_name = ""
        elif current.parent().parent().parent() is None:
            # Level 2: Keyword node (e.g., "015_JOHNSON_COOK")
            keyword_name = current.text(0)
            family_name = current.parent().text(0)
            root_name = current.parent().parent().text(0)
        else:
            # Level 3+: Record node (e.g., "ID:123")
            keyword_name = current.parent().text(0)
            family_name = current.parent().parent().text(0)
            root_name = current.parent().parent().parent().text(0)

        tab_index = self._find_tab_index_by_name(root_name)
        if tab_index < 0:
            return

        self.tabs_view.setCurrentIndex(tab_index)
        keywords_view = self.tabs_view.widget(tab_index)

        # Use robust repaint method, pass node_id for lazy loading of massive data
        self.load_keyword_node(family_name, keyword_name, params, keywords_view, node_id)
        # Enable buttons if the table has values
        self.tabs_view._update_buttons_state(keywords_view)


    def _find_tab_index_by_name(self, family_name: str) -> int:
        for i in range(self.tabs_view.count()):
            if self.tabs_view.tabText(i) == family_name:
                return i
        return -1

    def on_tab_selection(self, index: int):
        if index < 0:
            return
        family = self.tabs_view.tabText(index)
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.text(0) == family:
                self.tree.setCurrentItem(item)
                break

    # -------------------------------
    # Methods to populate KeywordsView
    def _fill_keywords_view(self, keywords_view, family_name, keyword_name, params: dict):
        # Select family (if applicable)
        if hasattr(keywords_view, "family_combo") and family_name:
            target_family = family_name.strip().upper()
            for i in range(keywords_view.family_combo.count()):
                if keywords_view.family_combo.itemText(i).strip().upper() == target_family:
                    keywords_view.family_combo.setCurrentIndex(i)
                    # Update Material Library button visibility
                    if hasattr(keywords_view, "_update_library_button_visibility"):
                        keywords_view._update_library_button_visibility(family_name)
                    break

        # Select keyword (if applicable)
        if hasattr(keywords_view, "keyword_combo") and keyword_name:
            target_keyword = keyword_name.strip().upper()
            for i in range(keywords_view.keyword_combo.count()):
                if keywords_view.keyword_combo.itemText(i).strip().upper() == target_keyword:
                    keywords_view.keyword_combo.setCurrentIndex(i)
                    break

        # Populate parameter table (overview)
        if hasattr(keywords_view, "table"):
            table = keywords_view.table
            table.clear()
            table.setRowCount(len(params))
            table.setColumnCount(2)
            table.setHorizontalHeaderLabels(["Parameter", "Value"])

            for row, (key, value) in enumerate(params.items()):
                key_item = QTableWidgetItem(str(key))
                key_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                table.setItem(row, 0, key_item)

                val_item = QTableWidgetItem("" if value is None else str(value))
                val_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
                table.setItem(row, 1, val_item)

    def _fill_record_table(self, keywords_view, family_name, keyword_name, params: dict):
        # Select family in combo
        if hasattr(keywords_view, "family_combo") and family_name:
            target_family = family_name.strip().upper()
            for i in range(keywords_view.family_combo.count()):
                if keywords_view.family_combo.itemText(i).strip().upper() == target_family:
                    keywords_view.family_combo.setCurrentIndex(i)
                    # Update Material Library button visibility
                    if hasattr(keywords_view, "_update_library_button_visibility"):
                        keywords_view._update_library_button_visibility(family_name)
                    break

        # Select keyword in combo
        if hasattr(keywords_view, "keyword_combo") and keyword_name:
            target_keyword = keyword_name.strip().upper()
            for i in range(keywords_view.keyword_combo.count()):
                if keywords_view.keyword_combo.itemText(i).strip().upper() == target_keyword:
                    keywords_view.keyword_combo.setCurrentIndex(i)
                    break

        # Populate record table (level 4)
        if hasattr(keywords_view, "table"):
            table = keywords_view.table
            table.clear()
            table.setRowCount(len(params))
            table.setColumnCount(2)
            table.setHorizontalHeaderLabels(["Parameter", "Value"])

            for row, (key, value) in enumerate(params.items()):
                key_item = QTableWidgetItem(str(key))
                key_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
                table.setItem(row, 0, key_item)

                val_item = QTableWidgetItem("" if value is None else str(value))
                val_item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled | Qt.ItemIsEditable)
                table.setItem(row, 1, val_item)

    def _request_rename_node(self):
        item = self.tree.currentItem()
        if not item:
            return

        # Only allow renaming root nodes
        if item.parent() is not None:
            # QMessageBox.warning(self, "Warning", "Only root nodes can be renamed.")
            main_window = self.window()
            if hasattr(main_window, "show_status"):
                main_window.show_status("Only root nodes can be renamed.")
            return

        old_name = item.text(0)
        node_id = item.data(0, Qt.UserRole)

        new_name, ok = QInputDialog.getText(
            self, "Rename Node", "Enter new name:", text=old_name
        )
        if ok and new_name.strip() and new_name.strip() != old_name:
            success = self.tree_vm.project_vm.rename_node(node_id, new_name.strip())
            if success:
                # Apply rename changes
                item.setText(0, new_name.strip())
                if self.tabs_view:
                    self.tabs_view.rename_tab(old_name, new_name.strip())
                # Emit signal for root node rename (to handle .k file rename)
                self.rootNodeRenamed.emit(node_id, old_name, new_name.strip())
            else:
                QMessageBox.warning(self, "Warning", "Could not rename the node.")

    def _maybe_show_info_for_records(self, item) -> None:
        """Auto-activate the 'Info' checkbox if *item* is a record (depth ≥ 3)
        or *item* is a keyword node whose direct children are records.

        The check is a no-op when the checkbox is already on, so it's safe
        to call from any high-frequency signal (itemExpanded, selection).

        Tree depth convention:
          0 = root/tab, 1 = family, 2 = keyword, 3+ = record
        An expanded item at depth ≥ 2 reveals records (or sub-records) so
        the Info column becomes useful. Same when a record itself becomes
        the current item.
        """
        if item is None:
            return
        if self.info_checkbox.isChecked():
            return
        depth = 0
        ancestor = item.parent()
        while ancestor is not None:
            depth += 1
            if depth >= 3:
                break
            ancestor = ancestor.parent()
        if depth >= 3:
            self.info_checkbox.setChecked(True)
            return
        if depth >= 2 and item.childCount() > 0:
            self.info_checkbox.setChecked(True)

    def _on_item_expanded(self, item) -> None:
        """itemExpanded handler — defer to the shared helper."""
        self._maybe_show_info_for_records(item)

    def _on_item_changed(self, item: QTreeWidgetItem, column: int):
        # QTreeWidget.itemChanged fires for ANY data role change on the item
        # — text, font, background, checkstate, etc. — not just user edits.
        # Treat it as a rename ONLY when an inline edit was actually initiated
        # (``_editing_old_name`` is set by ``_on_item_double_clicked``).
        #
        # Without this guard every setFont / setBackground during search
        # marking triggered a full DB rename_node + recursive tree rebuild +
        # nodes-table refetch + duplicate revalidation cascade. An 8-match
        # search took ~37 s for that reason; with the guard it's <100 ms.
        if self._editing_old_name is None:
            return
        new_name = item.text(column)
        old_name = self._editing_old_name
        self._editing_old_name = None  # Reset
        self.edit_node(item, new_name, old_name)

    def _on_item_double_clicked(self, item: QTreeWidgetItem, column: int):
        """Capture the old name when editing starts via double-click."""
        if column == 0:  # Only name column
            self._editing_old_name = item.text(0)


    def load_keyword_node(self, family_name: str, keyword_name: str, params: dict, keywords_view, node_id: int = None):
        """
        Load parameters into the main table and update the options list.
        - params is a flat dict: {"nsid": "123", "ID.id": "42", "__selected_option_specs__": "ID"}
        - node_id is used for lazy loading of massive data (nodes, elements, etc.)
        """
        # Handle special case where keyword_name is "GENERAL" (for Part, Node, etc.)
        # In these cases, the family_name is actually the keyword (PART, NODE)
        # and we need to swap them for proper class lookup
        if keyword_name and keyword_name.upper() == "GENERAL" and family_name:
            # The real keyword is the family_name (PART, NODE, etc.)
            actual_keyword = family_name
            # There's no real family in this case, but we keep family_name for combo selection
        else:
            actual_keyword = keyword_name
        
        # Select family and keyword in the combos.
        # If family_name/keyword_name are empty (root selection), clear selection.
        # Block signals on BOTH combos to prevent on_family_changed / on_keyword_changed
        # from repopulating the table when we only want to update combo display.
        keywords_view.family_combo.blockSignals(True)
        keywords_view.keyword_combo.blockSignals(True)
        try:
            self._load_keyword_node_inner(
                family_name, keyword_name, params, keywords_view, node_id, actual_keyword
            )
        finally:
            keywords_view.family_combo.blockSignals(False)
            keywords_view.keyword_combo.blockSignals(False)

    def _load_keyword_node_inner(
        self, family_name, keyword_name, params, keywords_view, node_id, actual_keyword
    ):
        """Inner implementation of load_keyword_node — called with combo signals blocked."""
        # ── FIRST: Clear the table and state immediately ──
        # This MUST happen before any combo manipulation, because combo code
        # can trigger exceptions (e.g. missing families, format errors) that
        # PySide6 swallows silently, leaving stale data from the previous node.
        keywords_view.table_main.clear()
        keywords_view.table_main.setRowCount(0)
        keywords_view.table_main.setColumnCount(4)
        keywords_view.table_main.setHorizontalHeaderLabels(["Parameter", "Value", "Units", "Description"])
        
        # Also reset state attributes that could carry over stale data
        keywords_view.loaded_params = {}
        keywords_view.main_params = {}
        keywords_view.option_list.clear()
        keywords_view.option_sets = []
        if hasattr(keywords_view, 'comment_edit'):
            keywords_view.comment_edit.clear()
        if hasattr(keywords_view, '_tablecard_meta'):
            keywords_view._tablecard_meta = {}

        # Family combo handling: show a non-editable placeholder when no family selected
        family_placeholder = "Select family..."
        if family_name:
            # Remove placeholder if present
            if keywords_view.family_combo.count() > 0 and keywords_view.family_combo.itemText(0) == family_placeholder:
                keywords_view.family_combo.removeItem(0)
            # Select the family if exists
            keywords_view.family_combo.setEditable(False)
            keywords_view.family_combo.setCurrentText(family_name)
            # Update Material Library button visibility (signal was blocked)
            keywords_view._update_library_button_visibility(family_name)
        else:
            # Ensure placeholder exists at index 0 and select it
            keywords_view.family_combo.setEditable(False)
            if keywords_view.family_combo.count() == 0 or keywords_view.family_combo.itemText(0) != family_placeholder:
                keywords_view.family_combo.insertItem(0, family_placeholder)
            keywords_view.family_combo.setCurrentIndex(0)

        # Keyword combo handling: keyword list depends on family; when no family selected show placeholder
        keyword_placeholder = "Select family first"
        if keyword_name:
            # Remove keyword placeholder if present
            if keywords_view.keyword_combo.count() > 0 and keywords_view.keyword_combo.itemText(0) == keyword_placeholder:
                keywords_view.keyword_combo.removeItem(0)
            keywords_view.keyword_combo.setEditable(False)
            keywords_view.keyword_combo.clear()
            keywords_view.keyword_map.clear()
            
            # Use the same formatting logic as on_family_changed
            # Case-insensitive lookup for family
            classes = []
            if hasattr(keywords_view, "families"):
                family_upper = family_name.strip().upper()
                for fam_key, fam_classes in keywords_view.families.items():
                    if fam_key.upper() == family_upper:
                        classes = fam_classes
                        break
            added_display_names = set()  # Prevent duplicates
            
            for cls in classes:
                if hasattr(cls, "subkeyword"):
                    subs = getattr(cls, "subkeyword")
                    if isinstance(subs, (list, tuple)):
                        for sub in subs:
                            display_name = keywords_view._format_keyword_display(cls, sub) if hasattr(keywords_view, "_format_keyword_display") else sub
                            if display_name not in added_display_names:
                                keywords_view.keyword_combo.addItem(display_name)
                                keywords_view.keyword_map[display_name] = cls
                                added_display_names.add(display_name)
                    else:
                        display_name = keywords_view._format_keyword_display(cls, str(subs)) if hasattr(keywords_view, "_format_keyword_display") else str(subs)
                        if display_name not in added_display_names:
                            keywords_view.keyword_combo.addItem(display_name)
                            keywords_view.keyword_map[display_name] = cls
                            added_display_names.add(display_name)
                else:
                    display_name = cls.__name__
                    if display_name not in added_display_names:
                        keywords_view.keyword_combo.addItem(display_name)
                        keywords_view.keyword_map[display_name] = cls
                        added_display_names.add(display_name)
            
            # Select the desired keyword (match by uppercase comparison)
            target_upper = keyword_name.strip().upper()
            for i in range(keywords_view.keyword_combo.count()):
                if keywords_view.keyword_combo.itemText(i).strip().upper() == target_upper:
                    keywords_view.keyword_combo.setCurrentIndex(i)
                    break
        else:
            # No specific keyword selected
            keywords_view.keyword_combo.setEditable(False)
            keywords_view.keyword_combo.clear()
            keywords_view.keyword_map.clear()
            
            if family_name:
                # Family is selected - populate keyword combo with available keywords for selection
                classes = []
                if hasattr(keywords_view, "families"):
                    family_upper = family_name.strip().upper()
                    for fam_key, fam_classes in keywords_view.families.items():
                        if fam_key.upper() == family_upper:
                            classes = fam_classes
                            break
                added_display_names = set()
                
                for cls in classes:
                    if hasattr(cls, "subkeyword"):
                        subs = getattr(cls, "subkeyword")
                        if isinstance(subs, (list, tuple)):
                            for sub in subs:
                                display_name = keywords_view._format_keyword_display(cls, sub) if hasattr(keywords_view, "_format_keyword_display") else sub
                                if display_name not in added_display_names:
                                    keywords_view.keyword_combo.addItem(display_name)
                                    keywords_view.keyword_map[display_name] = cls
                                    added_display_names.add(display_name)
                        else:
                            display_name = keywords_view._format_keyword_display(cls, str(subs)) if hasattr(keywords_view, "_format_keyword_display") else str(subs)
                            if display_name not in added_display_names:
                                keywords_view.keyword_combo.addItem(display_name)
                                keywords_view.keyword_map[display_name] = cls
                                added_display_names.add(display_name)
                    else:
                        display_name = cls.__name__
                        if display_name not in added_display_names:
                            keywords_view.keyword_combo.addItem(display_name)
                            keywords_view.keyword_map[display_name] = cls
                            added_display_names.add(display_name)
                
                # No keyword selected yet, set index to -1 to allow user to select
                keywords_view.keyword_combo.setCurrentIndex(-1)
            else:
                # No family selected - show placeholder
                keywords_view.keyword_combo.addItem(keyword_placeholder)
                keywords_view.keyword_combo.setCurrentIndex(0)

        # (Table was already cleared at the top of this method)

        # Store last load for orientation refresh without switching nodes
        if hasattr(keywords_view, "loaded_params"):
            processed_params = dict(params)
            
            # Remove internal marker keys (keep selected_option_specs, tablecard markers,
            # raw_content, original_name, table_points for DEFINE_TABLE keywords)
            table_keys = {'__raw_content__', '__original_name__', '__table_points__', '__user_comment__'}
            for key in list(processed_params.keys()):
                if key.startswith('__') and key.endswith('__'):
                    if key == '__selected_option_specs__':
                        continue
                    # Keep TABLE keyword fields
                    if key in table_keys:
                        continue
                    # Keep __tablecard_<prop>__ markers and __tablecard_<prop>_data__ storage
                    if key.startswith('__tablecard_') and key.endswith('__'):
                        continue
                    del processed_params[key]
            
            keywords_view.loaded_params = processed_params
        
        # Store original family/keyword for Update button state tracking
        if hasattr(keywords_view, "_original_family"):
            keywords_view._original_family = family_name
            keywords_view._original_keyword = keyword_name
        
        # Store node_id for lazy loading of massive data
        if hasattr(keywords_view, "_current_node_id"):
            keywords_view._current_node_id = node_id
        
        # Update "View All" button visibility based on DataFrame presence
        if hasattr(keywords_view, "_update_view_all_button"):
            keywords_view._update_view_all_button(params)

        # ── Non-record node: combos are set, table is cleared → stop here ──
        # When selecting root, family, or keyword nodes (non-records), we only
        # need to update the combos. Table and state were already cleared at the
        # top of this method.
        if node_id is None and not params:
            if hasattr(keywords_view, "_adjust_option_list_grid"):
                keywords_view._adjust_option_list_grid()
            return

        # Get keyword class to extract field order from definition
        # Case-insensitive lookup in keyword_map
        # Use actual_keyword (which may be family_name for GENERAL keywords like Part, Node)
        cls = None
        lookup_keyword = actual_keyword if actual_keyword else keyword_name
        if lookup_keyword:
            keyword_upper = lookup_keyword.strip().upper()
            for map_key, map_cls in keywords_view.keyword_map.items():
                if map_key.upper() == keyword_upper:
                    cls = map_cls
                    break
            
            # Fallback: normalized comparison (strip underscores) to handle
            # imported .k keywords stored as UPPER_SNAKE_CASE vs PascalCase
            # display names in keyword_map (e.g. "SURFACE_TO_SURFACE" from import
            # vs "ContactSurfaceToSurface" for classes without subkeyword).
            if cls is None and family_name:
                full_norm = (family_name.strip() + lookup_keyword.strip()).upper().replace('_', '').replace('-', '')
                for map_key, map_cls in keywords_view.keyword_map.items():
                    if map_key.upper().replace('_', '').replace('-', '') == full_norm:
                        cls = map_cls
                        break

            # If not found in keyword_map, try to import directly from PyDyna
            if cls is None:
                try:
                    full_norm = None
                    if family_name:
                        full_norm = (family_name.strip() + lookup_keyword.strip()).upper().replace('_', '').replace('-', '')
                    fuzzy_match = None
                    for attr_name in pydyna.list_keyword_names():
                        attr_upper = attr_name.upper()
                        if attr_upper == keyword_upper:
                            potential_cls = pydyna.get_keyword_class(attr_name)
                            if potential_cls and hasattr(potential_cls, 'keyword'):
                                cls = potential_cls
                                break
                        # Normalized fallback: family+keyword vs PascalCase name
                        if fuzzy_match is None and full_norm:
                            if attr_upper.replace('_', '').replace('-', '') == full_norm:
                                fuzzy_match = attr_name
                    if cls is None and fuzzy_match:
                        potential_cls = pydyna.get_keyword_class(fuzzy_match)
                        if potential_cls and hasattr(potential_cls, 'keyword'):
                            cls = potential_cls
                except Exception:
                    pass

        # If cls was found but combo has no item selected (imported .k name
        # didn't match any display name directly), find the matching combo
        # item via the class reference and sync _original_keyword so the
        # Update button comparison won't be blocked.
        if cls is not None and keyword_name:
            combo = keywords_view.keyword_combo
            if combo.currentIndex() < 0 or combo.currentText().strip().upper() != keyword_name.strip().upper():
                for i in range(combo.count()):
                    if keywords_view.keyword_map.get(combo.itemText(i)) is cls:
                        combo.setCurrentIndex(i)
                        if hasattr(keywords_view, '_original_keyword'):
                            keywords_view._original_keyword = combo.itemText(i)
                        break

        field_order = []
        card_info = {}  # Maps field_name -> card_index
        if cls:
            try:
                obj = cls()
                # First try _cards with _fields (standard keywords)
                if pydyna.has_cards(obj):
                    card_index = 0
                    multi_value_types = ('TableCard', 'SeriesCard', 'TableCardGroup')
                    for card in pydyna.get_cards(obj):
                        entry_type_name = pydyna.get_card_type_name(card)
                        if entry_type_name in multi_value_types:
                            # Multi-value card: TableCard / TableCardGroup / SeriesCard
                            tc_prop_name = keywords_view._find_tablecard_property(obj, card_index) if hasattr(keywords_view, '_find_tablecard_property') else None
                            if tc_prop_name and tc_prop_name not in ('curves', 'a1', 'o1'):
                                # Build column definitions
                                columns = []
                                if entry_type_name == 'SeriesCard':
                                    import dataclasses as _dc
                                    sc_type = pydyna.get_series_card_inner_type(card)
                                    sc_width = pydyna.get_series_card_element_width(card)
                                    if _dc.is_dataclass(sc_type):
                                        for f in _dc.fields(sc_type):
                                            columns.append({
                                                "name": f.name,
                                                "type": f.type,
                                                "default": 0 if f.type == int else 0.0 if f.type == float else '',
                                                "width": sc_width
                                            })
                                    else:
                                        sc_name = pydyna.get_series_card_name(card)
                                        columns.append({
                                            "name": sc_name,
                                            "type": sc_type,
                                            "default": 0 if sc_type == int else 0.0,
                                            "width": sc_width
                                        })
                                elif pydyna.has_card_fields(card):
                                    for field in pydyna.get_card_fields(card):
                                        col_type = field.type if hasattr(field, 'type') else float
                                        col_default = field.default if hasattr(field, 'default') else (0 if col_type == int else 0.0 if col_type == float else '')
                                        col_width = field.width if hasattr(field, 'width') else 10
                                        columns.append({
                                            "name": pydyna.get_field_name(field),
                                            "type": col_type,
                                            "default": col_default,
                                            "width": col_width
                                        })
                                elif entry_type_name == 'TableCardGroup':
                                    for child_card in pydyna.get_child_cards(card):
                                        if pydyna.has_card_fields(child_card):
                                            for field in pydyna.get_card_fields(child_card):
                                                col_type = field.type if hasattr(field, 'type') else float
                                                col_default = field.default if hasattr(field, 'default') else (0 if col_type == int else 0.0 if col_type == float else '')
                                                col_width = field.width if hasattr(field, 'width') else 10
                                                columns.append({
                                                    "name": pydyna.get_field_name(field),
                                                    "type": col_type,
                                                    "default": col_default,
                                                    "width": col_width
                                                })
                                if columns:
                                    if not hasattr(keywords_view, '_tablecard_meta'):
                                        keywords_view._tablecard_meta = {}
                                    keywords_view._tablecard_meta[tc_prop_name] = {
                                        "columns": columns,
                                        "card_index": card_index,
                                        "card_type": entry_type_name
                                    }
                                    marker_key = f"__tablecard_{tc_prop_name}__"
                                    field_order.append(marker_key)
                                    card_info[marker_key] = card_index
                            card_index += 1
                        elif pydyna.has_card_fields(card) and pydyna.card_has_get_value(card):
                            for field in pydyna.get_card_fields(card):
                                fname = pydyna.get_field_name(field)
                                field_order.append(fname)
                                card_info[fname] = card_index
                            card_index += 1
                        else:
                            card_index += 1
                
                # If no field_order from _cards, try DataFrame-based attributes
                # Keywords like Part, Node use DataFrame attributes (parts, nodes, elements)
                if not field_order:
                    for df_attr in ['parts', 'nodes', 'elements']:
                        if hasattr(obj, df_attr):
                            df = getattr(obj, df_attr)
                            if hasattr(df, 'columns'):
                                field_order = list(df.columns)
                                break
            except Exception:
                pass
        
        # Store card_info in keywords_view for table rendering
        keywords_view.card_info = card_info

        # Use processed_params if available
        params_to_use = keywords_view.loaded_params if hasattr(keywords_view, 'loaded_params') and keywords_view.loaded_params else params

        # Prepare main_params from DB values (keys without dot), preserving class definition order
        keywords_view.main_params = {}
        
        def is_tablecard_marker(k):
            """Check if key is a __tablecard_<prop>__ marker (not _data__)."""
            return (k.startswith('__tablecard_') and k.endswith('__') 
                    and not k.endswith('_data__'))

        # First add fields in class definition order
        for field_name in field_order:
            if field_name in params_to_use and field_name != "__selected_option_specs__":
                keywords_view.main_params[field_name] = params_to_use[field_name]
            elif is_tablecard_marker(field_name):
                # Always show tablecard markers from class definition, even when
                # the DB has no data (e.g. records saved before the tablecard
                # persistence fix).  This lets the user click the marker and
                # add data through the dialog, then save/update normally.
                keywords_view.main_params[field_name] = "[0 rows - Click to edit]"
        # Then add any remaining fields from DB that weren't in the class definition
        for key, value in params_to_use.items():
            if key == "__selected_option_specs__":
                continue
            # Skip internal dunder fields for display, EXCEPT tablecard markers
            if key.startswith("__") and key.endswith("__"):
                if is_tablecard_marker(key):
                    keywords_view.main_params[key] = value
                continue
            if "." not in key and key not in keywords_view.main_params:
                # Skip bare keys whose name matches a TableCard property that
                # already exists in the data (e.g. bare "parameters" alongside
                # __tablecard_parameters_data__).  These are leftover UI markers
                # stored by older versions and must not overwrite real entries.
                tc_marker = f"__tablecard_{key}__"
                tc_data = f"__tablecard_{key}_data__"
                if tc_marker in keywords_view.main_params or tc_marker in params_to_use or tc_data in params_to_use:
                    continue
                # Also skip any bare key whose value is a UI marker string
                # (e.g. "[0 curves - Click to edit]", "[0 points - Click to edit]")
                import re as _re
                if isinstance(value, str) and _re.match(r'^\[\d+ \w+ - Click to edit\]$', value):
                    continue
                keywords_view.main_params[key] = value

        # ── Expand TableCard DataFrames into inline rows ──────────────
        # Merge the __tablecard_*_data__ keys from params_to_use into
        # main_params temporarily so the shared helper can find them.
        _mp = dict(keywords_view.main_params)
        for k, v in params_to_use.items():
            if k.startswith("__tablecard_") and k.endswith("_data__") and k not in _mp:
                _mp[k] = v
        from ui.keywords_view import KeywordsView as _KV
        keywords_view.main_params = _KV._expand_tablecard_inline(_mp)

        # Options list: repopulate and mark selected ones
        keywords_view.option_list.clear()
        keywords_view.option_sets = []
        
        if not cls:
            # No class found, but we may still have params to show
            # Populate the table directly with main_params
            if keywords_view.main_params:
                keywords_view._populate_table(
                    keywords_view.table_main, 
                    keywords_view.main_params, 
                    horizontal=keywords_view.horizontal_checkbox.isChecked()
                )
            # Load user comment even without a PyDyna class
            if hasattr(keywords_view, 'comment_edit'):
                comment = (keywords_view.loaded_params or {}).get('__user_comment__', '')
                keywords_view.comment_edit.setPlainText(comment or '')
            return
        obj = cls()

        # Recover selected OptionSpecs from DB
        selected_specs = []
        if "__selected_option_specs__" in params:
            value = params["__selected_option_specs__"]
            # Handle both list (from import) and string (from manual creation)
            if isinstance(value, list):
                selected_specs = value
            elif isinstance(value, str):
                selected_specs = value.split(",") if value else []
            else:
                selected_specs = []

        for entry in pydyna.get_cards(obj) if pydyna.has_cards(obj) else []:
            if pydyna.is_option_card_set(entry):
                keywords_view.option_sets.append(entry)
                item_text = pydyna.get_option_name(entry)
                item = QListWidgetItem(item_text)
                keywords_view.option_list.addItem(item)

                # Mark if it was selected in DB
                if item_text in selected_specs:
                    item.setSelected(True)

                # Ensure this OptionSpec parameters show DB values
                prefix = item_text + "."
                for card in pydyna.get_option_inner_cards(entry):
                    for field in pydyna.get_card_fields(card):
                        key = f"{prefix}{field.name}"
                        if key in params:
                            value = params[key]
                            # Look for an existing row
                            found = False
                            for row in range(keywords_view.table_main.rowCount()):
                                if keywords_view.table_main.item(row, 0).text() == key:
                                    keywords_view.table_main.setItem(row, 1, QTableWidgetItem(str(value)))
                                    found = True
                                    break
                            if not found:
                                # If not present, add it
                                row = keywords_view.table_main.rowCount()
                                keywords_view.table_main.insertRow(row)
                                keywords_view.table_main.setItem(row, 0, QTableWidgetItem(key))
                                keywords_view.table_main.setItem(row, 1, QTableWidgetItem(str(value)))

        # Adjust cell sizes so all options are visible without resizing
        if hasattr(keywords_view, "_adjust_option_list_grid"):
            keywords_view._adjust_option_list_grid()

        # Populate table directly with all DB parameters, respecting current orientation
        def include_field(k):
            if k == "__selected_option_specs__":
                return False
            # Allow __tablecard_<prop>__ markers (but not _data__ storage keys)
            if k.startswith('__tablecard_') and k.endswith('__') and not k.endswith('_data__'):
                return True
            # Exclude other dunder fields
            if k.startswith("__") and k.endswith("__"):
                return False
            return True
        
        combined_from_db = {k: v for k, v in params_to_use.items() if include_field(k)}
        
        if hasattr(keywords_view, "_populate_from_loaded"):
            keywords_view._populate_from_loaded(
                horizontal=keywords_view.horizontal_checkbox.isChecked()
            )
        elif hasattr(keywords_view, "_populate_table"):
            keywords_view._populate_table(
                keywords_view.table_main,
                combined_from_db,
                horizontal=keywords_view.horizontal_checkbox.isChecked()
            )



    # def load_keyword_node(self, family_name: str, keyword_name: str, params: dict, keywords_view: KeywordsView):
    #     """Load parameters into the main table and update the options list."""
    #     keywords_view.family_combo.setCurrentText(family_name)
    #     keywords_view.keyword_combo.setCurrentText(keyword_name)

    #     # Main table: clear and populate with ALL parameters from the DB
    #     keywords_view.table_main.clear()
    #     keywords_view.table_main.setRowCount(0)
    #     keywords_view.table_main.setColumnCount(2)
    #     keywords_view.table_main.setHorizontalHeaderLabels(["Parameter", "Value"])
    #     for key, value in params.items():
    #         if key == "__selected_option_specs__":
    #             continue  # this field is not shown in the table
    #         row = keywords_view.table_main.rowCount()
    #         keywords_view.table_main.insertRow(row)
    #         keywords_view.table_main.setItem(row, 0, QTableWidgetItem(key))
    #         keywords_view.table_main.setItem(row, 1, QTableWidgetItem(str(value)))

    #     # Options list: repopulate and mark those with parameters
    #     keywords_view.option_list.clear()
    #     keywords_view.option_sets = []
    #     cls = keywords_view.keyword_map.get(keyword_name)
    #     if not cls:
    #         return
    #     obj = cls()

    #     # Recover selected OptionSpecs from DB
    #     selected_specs = params.get("__selected_option_specs__", "").split(",") if "__selected_option_specs__" in params else []

    #     for entry in getattr(obj, "_cards", []):
    #         if hasattr(entry, "cards") and hasattr(entry, "option_spec"):
    #             keywords_view.option_sets.append(entry)
    #             item_text = entry.option_spec.name
    #             item = QListWidgetItem(item_text)
    #             keywords_view.option_list.addItem(item)

    #             # Mark if it was selected in DB
    #             if item_text in selected_specs:
    #                 item.setSelected(True)

    #             # Ensure this OptionSpec parameters show DB values
    #             prefix = item_text + "."
    #             for card in entry.cards:
    #                 for field in card._fields:
    #                     key = f"{item_text}.{field.name}"
    #                     if key in params:
    #                         value = params[key]
    #                         # Look for an existing row
    #                         found = False
    #                         for row in range(keywords_view.table_main.rowCount()):
    #                             if keywords_view.table_main.item(row, 0).text() == key:
    #                                 keywords_view.table_main.setItem(row, 1, QTableWidgetItem(str(value)))
    #                                 found = True
    #                                 break
    #                         if not found:
    #                             # If not present, add it
    #                             row = keywords_view.table_main.rowCount()
    #                             keywords_view.table_main.insertRow(row)
    #                             keywords_view.table_main.setItem(row, 0, QTableWidgetItem(key))
    #                             keywords_view.table_main.setItem(row, 1, QTableWidgetItem(str(value)))

    def on_theme_changed(self, theme_name: str):
        """Handle theme change - apply tree style for Modern Header theme."""
        if theme_name == "Modern Header":
            # Apply Modern Header style to tree
            self.tree.setStyleSheet(TREE_STYLE_MODERN_HEADER)
        else:
            # Reapply current selected style from combo
            current_style = self.style_combo.currentText()
            style = get_tree_style(current_style)
            self.tree.setStyleSheet(style)


# End of file ui/tree_view.py