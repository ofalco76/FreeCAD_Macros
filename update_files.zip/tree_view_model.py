# view_models/tree_view_model.py
from PySide6.QtCore import QObject, Signal

class TreeViewModel(QObject):
    # --- Señales hacia la UI ---
    treeUpdated = Signal(list)        # lista de nodos [(id, parent_id, name)]
    nodeAdded = Signal(int, str)      # id, nombre
    nodeRemoved = Signal(int)         # id
    nodeRenamed = Signal(int, str)    # id, nuevo nombre
    nodeParamsReady = Signal(int, dict)  # id, parámetros
    structureChanged = Signal(int)    # project_id — roots/tree changed (e.g. plugin injection)
    errorOccurred = Signal(str)

    def __init__(self, project_vm):
        super().__init__()
        self.project_vm = project_vm
        self.active_project_id = None

    # --- Métodos expuestos a la vista ---
    def load_tree(self, project_id: int):
        """Carga todos los nodos de un proyecto y emite la señal treeUpdated."""
        try:
            self.active_project_id = project_id
            # Limpia huérfanos en DB para que solo existan los nodos visibles del árbol
            strategy = getattr(self.project_vm, "db_manager", None)
            strategy = getattr(strategy, "strategy", None)
            if strategy and hasattr(strategy, "prune_orphans"):
                strategy.prune_orphans(project_id)

            nodes = self.project_vm.get_nodes(project_id)
            self.treeUpdated.emit(nodes)
        except Exception as e:
            self.errorOccurred.emit(str(e))

    def reload_structure(self, project_id: int | None = None, select_node_id: int | None = None):
        """Signal that the tree structure changed (new roots / many nodes added).

        The view re-syncs the parameter tabs (one per root) and refreshes the
        tree preserving state. Used after bulk injections (e.g. plugins) where
        a plain ``load_tree`` would refresh the tree but leave the tabs — and
        therefore the parameter editor — out of sync with new root nodes.

        When ``select_node_id`` is given the tree will select that node after
        the rebuild, which triggers the parameters panel to populate.
        """
        pid = project_id or self.active_project_id
        if pid is not None:
            self._pending_select_after_reload = select_node_id
            self.structureChanged.emit(pid)

    def add_node(self, name: str, parent_id: int | None):
        """Añade un nodo y emite nodeAdded."""
        try:
            node_id = self.project_vm.add_node(name, parent_id, self.active_project_id)
            self.nodeAdded.emit(node_id, name)
            # Update project's updated_at timestamp
            self._touch_project()
            # refrescar árbol completo
            self.load_tree(self.active_project_id)
            return node_id
        except Exception as e:
            self.errorOccurred.emit(str(e))
            return None

    def delete_node(self, node_id: int):
        """Elimina un nodo y emite nodeRemoved."""
        try:
            self.project_vm.delete_node(node_id)
            self.nodeRemoved.emit(node_id)
            # Update project's updated_at timestamp
            self._touch_project()
            self.load_tree(self.active_project_id)
        except Exception as e:
            self.errorOccurred.emit(str(e))

    def rename_node(self, node_id: int, new_name: str):
        """Renombra un nodo y emite nodeRenamed."""
        try:
            success = self.project_vm.rename_node(node_id, new_name)
            if success:
                self.nodeRenamed.emit(node_id, new_name)
                # Update project's updated_at timestamp
                self._touch_project()
                self.load_tree(self.active_project_id)
            return success
        except Exception as e:
            self.errorOccurred.emit(str(e))
            return False
    
    def move_node_up(self, node_id: int) -> bool:
        """Move a node up among its siblings and refresh the tree."""
        try:
            success = self.project_vm.move_node_up(node_id)
            if success:
                self._touch_project()
                self.load_tree(self.active_project_id)
            return success
        except Exception as e:
            self.errorOccurred.emit(str(e))
            return False

    def _touch_project(self):
        """Update the updated_at timestamp for the active project."""
        if self.active_project_id:
            try:
                strategy = getattr(self.project_vm, "db_manager", None)
                strategy = getattr(strategy, "strategy", None)
                if strategy and hasattr(strategy, "touch_project"):
                    strategy.touch_project(self.active_project_id)
            except Exception:
                pass  # Silent fail - timestamp update is not critical

    def request_node_params(self, node_id: int, summarize_massive: bool = True):
        """
        Recupera parámetros de un nodo y emite nodeParamsReady.
        
        Args:
            node_id: ID del nodo
            summarize_massive: Si True, devuelve resúmenes para datos masivos (para UI)
        """
        try:
            params = self.project_vm.get_params(node_id, summarize_massive=summarize_massive)
            self.nodeParamsReady.emit(node_id, params or {})
        except Exception as e:
            self.errorOccurred.emit(str(e))

# end of file view_models/tree_view_model.py