# Bugfix: Plugin parts_array — 2026-05-26

## Contexto

Plugin `parts_array` ya implementado y funcionando. Al ejecutar "Generate" se detectaron dos bugs:

---

## Bug 1 — Nodo contenedor extra "Array: bolt_dummy" en el árbol

### Síntoma
Al inyectar keywords, aparecía un nodo intermedio `"Array: bolt_dummy"` bajo `main`.
Todos los nodos `DEFINE_TRANSFORMATION` e `INCLUDE_TRANSFORM` quedaban colgados dentro de ese contenedor en lugar de ir directamente bajo `main`.

### Causa raíz
`dialog.py` llamaba a `apply_keywords` pasando `group_label=cfg["name_mask"]`.
El `name_mask` (ej. `"bolt_dummy"`) es solo para el título de cada instancia (`"bolt_dummy #1"`, `"#2"`…).
Un `group_label` no vacío activa `_make_array_group` en `plugin_host.py`, que crea el contenedor.

### Fix
**Fichero:** `plugins/parts_array/dialog.py` — línea ~1412

```python
# ANTES
result = self.host.apply_keywords(specs, group_label=cfg["name_mask"])

# DESPUÉS
result = self.host.apply_keywords(specs, group_label=None)
```

---

## Bug 2 — Tabla de parámetros no se refresca tras la inyección

### Síntoma
Tras pulsar "Generate", el árbol se actualizaba (aparecían los nuevos nodos) pero la tabla de parámetros de la derecha seguía mostrando el contenido anterior o vacío.
Había que hacer clic manualmente en un nodo del árbol para ver sus parámetros.

### Causa raíz
Cadena del problema:
1. El diálogo es no-modal (`show()`, no `exec()`).
2. Al hacer clic en "Generate", el foco está en el diálogo → no hay ítem seleccionado en el árbol.
3. `refresh_tree()` captura `currentItem()` → `None` → `_pending_selection_id = None`.
4. Tras reconstruir el árbol, ningún nodo queda seleccionado.
5. Sin selección, `currentItemChanged` no se emite → `on_tree_selection` no se llama → `request_node_params` no se llama → tabla queda sin actualizar.

`ApplyResult` ya devolvía `created_node_ids` pero nadie los usaba para navegar.

### Fix — Cadena de 3 ficheros

#### `core/tools/plugin_host.py`
- `_refresh_tree` acepta nuevo parámetro `select_node_id: int | None = None`.
- `apply_keywords` pasa `created[0]` como `select_node_id`.

```python
# _refresh_tree actualizado
def _refresh_tree(self, pid: int, select_node_id: int | None = None) -> None:
    ...
    self.tree_vm.reload_structure(pid, select_node_id=select_node_id)

# apply_keywords: línea de llamada actualizada
first_id = created[0] if created else None
self._refresh_tree(pid, select_node_id=first_id)
```

#### `view_models/tree_view_model.py`
- `reload_structure` acepta `select_node_id: int | None = None`.
- Lo guarda en `self._pending_select_after_reload` antes de emitir `structureChanged`.

```python
def reload_structure(self, project_id=None, select_node_id=None):
    pid = project_id or self.active_project_id
    if pid is not None:
        self._pending_select_after_reload = select_node_id
        self.structureChanged.emit(pid)
```

#### `ui/tree_view.py`
- `_on_structure_changed` lee `_pending_select_after_reload` del `tree_vm` y lo pasa a `refresh_tree(select_node_id=...)`.

```python
def _on_structure_changed(self, project_id):
    ...
    select_id = getattr(self.tree_vm, '_pending_select_after_reload', None)
    self.tree_vm._pending_select_after_reload = None
    self.refresh_tree(select_node_id=select_id)
```

### Flujo resultante tras el fix
```
apply_keywords() → created[0]
    → _refresh_tree(select_node_id=created[0])
        → tree_vm.reload_structure(select_node_id=created[0])
            → _pending_select_after_reload = created[0]
            → structureChanged.emit(pid)
                → _on_structure_changed()
                    → refresh_tree(select_node_id=created[0])
                        → árbol reconstruido con nodo seleccionado
                            → currentItemChanged emitido
                                → on_tree_selection()
                                    → request_node_params(created[0])
                                        → tabla de parámetros actualizada ✓
```

---

## Independencia plugin ↔ ficheros UI

El plugin `parts_array` **no importa ni conoce** `tree_view.py` ni `tree_view_model.py`.
Solo conoce el protocolo `KeywordInjectionHost` de `core/tools/keyword_contract.py`.
El cableado real ocurre en `main.py`:

```python
window.keyword_host = AppKeywordHost(project_vm, tree_vm)
```

Los cambios de Bug 2 son completamente transparentes para el plugin.

---

## Ficheros modificados

| Fichero original | Copia de backup |
|---|---|
| `plugins/parts_array/dialog.py` | `resources/update_files/dialog.py` |
| `core/tools/plugin_host.py` | `resources/update_files/plugin_host.py` |
| `view_models/tree_view_model.py` | `resources/update_files/tree_view_model.py` |
| `ui/tree_view.py` | `resources/update_files/tree_view.py` |
