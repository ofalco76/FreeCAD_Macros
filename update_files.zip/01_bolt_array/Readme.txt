$********************************************************************************$
$              ITP/LS-PrePost PROJECT & USER MATERIAL LIBRARY                    $
$                 Intellectual Property ITP Aero S.A.U.                          $
$                       All Rights Reserved ©                                    $
$                                                                                $
$         Automated deck file generated using PyDeckGen v0.9.1-rc1               $
$                                                                                $
$                  (DEFAULT UNITS : MM, TON, SEC, N)                             $
$********************************************************************************$

================================================================================
                         PROJECT DOCUMENTATION
================================================================================

This file contains notes and documentation for this LS-DYNA project.
You can edit this file directly in the File Viewer to add your own notes.

Created: 2026-05-26 17:39
Project: 01_bolt_array

--------------------------------------------------------------------------------
                              PROJECT NOTES
--------------------------------------------------------------------------------

[Add your project notes, simulation parameters, material descriptions, 
boundary conditions, or any relevant information here]


--------------------------------------------------------------------------------
                           SIMULATION DETAILS
--------------------------------------------------------------------------------

Simulation Type: 
Analysis Duration: 
Time Step: 
Contact Type:
Material Models Used: 
Boundary Conditions: 


--------------------------------------------------------------------------------
                             CHANGE LOG
--------------------------------------------------------------------------------

2026-05-26 17:39 - Project created


================================================================================
